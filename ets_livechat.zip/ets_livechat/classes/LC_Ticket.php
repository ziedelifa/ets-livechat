<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) { exit; }

class LC_Ticket extends ObjectModel
{
    protected static $instance;
    public static $employeesHaveAccess = array();
    public $id_form;
    public $id_shop;
    public $id_departments;
    public $status;
    public $priority;
    public $rate;
    public $readed;
    public $customer_readed;
    public $id_customer;
    public $id_lang;
    public $employee;
    public $id_product;
    public $id_order;
    public $subject;
    public $date_add;
    public $date_customer_update;
    public $date_admin_update;
    public $id_employee;
    public $send_email_customer;
    public $send_email_admin;
    public $replied;
    public $customer_name;
    public $customer_email;

    public static $definition = array(
        'table' => 'ets_livechat_ticket_form_message',
        'primary' => 'id_message',
        'fields' => array(
            'id_form' => array('type' => self::TYPE_INT),
            'id_shop' => array('type' => self::TYPE_INT),
            'id_lang' => array('type' => self::TYPE_INT),
            'id_departments' => array('type' => self::TYPE_INT),
            'status' => array('type' => self::TYPE_STRING),
            'priority' => array('type' => self::TYPE_INT),
            'rate' => array('type' => self::TYPE_INT),
            'readed' => array('type' => self::TYPE_INT),
            'replied' => array('type' => self::TYPE_BOOL),
            'id_employee' => array('type' => self::TYPE_INT),
            'employee' => array('type' => self::TYPE_BOOL),
            'customer_readed' => array('type' => self::TYPE_INT),
            'id_customer' => array('type' => self::TYPE_INT),
            'id_product' => array('type' => self::TYPE_INT),
            'id_order' => array('type' => self::TYPE_INT),
            'subject' => array('type' => self::TYPE_STRING),
            'date_add' => array('type' => self::TYPE_STRING),
            'date_customer_update' => array('type' => self::TYPE_STRING),
            'date_admin_update' => array('type' => self::TYPE_STRING),
            'send_email_customer' => array('type' => self::TYPE_STRING),
            'send_email_admin' => array('type' => self::TYPE_STRING),
        )
    );

    public function __construct($id_item = null, $id_lang = null, $id_shop = null)
    {
        parent::__construct($id_item, $id_lang, $id_shop);
        if($this->id && $this->id_customer)
        {
            $customer = new Customer($this->id_customer);
            $this->customer_name = $customer->firstname. ' '.$customer->lastname;
        }
        else
        {
            $fields = LC_Ticket::getFieldTicket($this->id);
            if($fields)
            {
                foreach($fields as $field)
                {
                    if($field['is_contact_name'] && $field['type']=='text')
                    {
                        $this->customer_name = $field['value'];
                    }
                }
            }
        }
    }
    public function l($string, $source = null)
    {
        return Translate::getModuleTranslation('ets_livechat', $string, $source ?: pathinfo(__FILE__, PATHINFO_FILENAME));
    }
    public function delete()
    {
        if (parent::delete()) {
            $file_fields = Db::getInstance()->executeS('SELECT id_download FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_field` WHERE id_message =' . (int)$this->id . ' AND id_download!=0');
            if ($file_fields) {
                foreach ($file_fields as $file) {
                    $download = new LC_Download($file['id_download']);
                    $download->delete();
                }

            }
            Db::getInstance()->execute('DELETE FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_field` WHERE id_message =' . (int)$this->id);
            $notes = Db::getInstance()->executeS('SELECT id_note FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note` WHERE id_message =' . (int)$this->id);
            if ($notes) {
                foreach ($notes as $note) {
                    $note_class = new LC_Note($note['id_note']);
                    $note_class->delete();
                }
            }
            return true;
        }
    }

    public function add($auto_date = true, $null_values = false)
    {
        if (!$this->id_lang){
            if (defined('_PS_ADMIN_DIR_') && isset($this->context->employee) && $this->id_customer){
                $customer = new Customer($this->id_customer);
                $this->id_lang = $customer->id_lang;
            }
            else{
                $this->id_lang = Context::getContext()->language->id;
            }
        }
        return parent::add($auto_date, $null_values);
    }

    /**
     * @param $data
     * @param $form LC_Ticket_form
     * @param null $id_customer
     * @return array
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public function addTicket($data, $form, $id_customer = null)
    {
        $errors = array();
        $warnings = array();
        $context = Context::getContext();
        $department = isset($data['id_departments']) ? (int)$data['id_departments'] : 0;
        $orderRef = isset($data['order_ref']) ? $data['order_ref'] : false;
        $id_product = isset($data['id_product']) ? (int)$data['id_product'] : 0;
        $id_employee = Ets_livechat::isAdmin() && isset($data['id_employee']) ? (int)$data['id_employee'] : 0;
        if(!$id_employee && Ets_livechat::isAdmin())
            $id_employee = $context->employee->id;
        $status = isset($data['status']) && $data['status'] ? $data['status'] : 'open';
        $priority = isset($data['priority']) && (int)$data['priority'] ? (int)$data['priority'] : (int)$form->default_priority;
        $fieldValues = isset($data) && $data['fields'] && is_array($data['fields']) ? $data['fields'] : array();
        if (!$id_customer)
            $id_customer = isset($context->customer) && $context->customer->isLogged() ? (int)$context->customer->id : 0;
        $isAdmin = Ets_livechat::isAdmin();
        $customer = new Customer($id_customer);
        if ($customer->id) {
            $customerName = trim($customer->firstname . ' ' . $customer->lastname);
            $customerEmail = $customer->email;
        }
        if (!$form->id)
            $errors[] = $this->l('Ticket form is not valid');
        if ($orderRef && !preg_match('/^[a-zA-Z0-9]{4,10}$/', $orderRef))
            $errors[] = $this->l('Order reference is not valid');
        elseif ($orderRef && !$id_customer)
            $errors[] = $this->l('You are required to login to view order');
        elseif ($orderRef && !($order = LC_Ticket_Form::getOrderByRef($orderRef, (int)$context->customer->id)))
            $errors[] = $this->l('Order does not exist');
        if ($id_product && ($product = new Product($id_product, $context->language->id)) && !$product->id)
            $errors[] = $this->l('Product does not exist');
        if ($id_employee && ($employee = new Employee($id_employee)) && !$employee->id)
            $errors[] = $this->l('Employee does not exist');
        if ($form->getDepartments() && !$department)
            $errors[] = $this->l('Department is required');
        elseif ($department && ($departmentObj = new LC_Departments($department, $context->language->id)) && !$departmentObj->id)
            $errors[] = $this->l('Department does not exist');
        if (!$errors && ($errors = $this->validateSubmitFields($form, $fieldValues)) === true) {
            $is_manager_ticket = LC_Ticket::managerTicket($customer->email);
            $errors = array();
            $attachments = array();
            $ticket = new LC_Ticket();
            $ticket->id_form = $form->id;
            $ticket->id_shop = $context->shop->id;
            $ticket->id_customer = $id_customer;
            $ticket->id_product = $id_product;
            $ticket->id_employee = $id_employee;
            $ticket->id_order = isset($order) ? $order->id : 0;
            $ticket->id_departments = $department;
            $ticket->status = $status;
            $ticket->priority = (int)$priority;
            $ticket->date_admin_update = date('Y-m-d H:i:s');
            $ticket->date_customer_update = date('Y-m-d H:i:s');
            $ticket->customer_name = isset($customerName) ? $customerName : '';
            $ticket->customer_email = isset($customerEmail) ? $customerEmail : '';
            $ticket->customer_readed = $isAdmin || $is_manager_ticket ? 0 : 1;
            $ticket->readed = !$ticket->customer_readed;
            $ticket->replied = 0;
            $ticket->add(true, true);
            if ($ticket->id && ($fields = $form->getFormFields())) {
                $this->id = $ticket->id;
                foreach ($fields as $field) {
                    if ($field['type'] == 'file')
                        continue;
                    $id_field = $field['id_field'];
                    $value = isset($fieldValues[$id_field]) ? ($field['type']=='checkbox') ? implode(', ',$fieldValues[$id_field]) :$fieldValues[$id_field] : '';
                    $field_class = new LC_Ticket_Field($id_field, $context->language->id);
                    if ($field_class->type == 'text' && $field_class->is_contact_name) {
                        if ($ticket->customer_name)
                            $value = $ticket->customer_name;
                        elseif ($value) {
                            $ticket->customer_name = $value;
                            if (!$ticket->update()) {
                                $errors[] = sprintf($this->l('Could not save customer name: %s'), $value);
                                break;
                            }
                        }
                    }
                    if ($field_class->type == 'email' && $field_class->is_contact_mail) {
                        if ($ticket->customer_email)
                            $value = $ticket->customer_email;
                        elseif ($value) {
                            $ticket->customer_email = $value;
                            if (!$ticket->update()) {
                                $errors[] = sprintf($this->l('Could not save customer email: %s'), $value);
                                break;
                            }
                        }
                    }
                    if ($field_class->is_subject) {
                        $ticket->subject = $value;
                        if (!$ticket->update()) {
                            $errors[] = sprintf($this->l('Could not save subject: %s'), $field['label']);
                            break;
                        }
                    }
                    if (!$this->addFormFieldValue($id_field, $value)) {
                        $errors[] = sprintf($this->l('Could not save: %s'), $field['label']);
                        break;
                    }
                }
                if (!$errors && isset($_FILES['fields']['name']) && ($fileNames = $_FILES['fields']['name']) && isset($_FILES['fields']['type']) && ($fileTypes = $_FILES['fields']['type'])
                    && isset($_FILES['fields']['size']) && ($fileSizes = $_FILES['fields']['size']) && isset($_FILES['fields']['tmp_name']) && ($fileTempNames = $_FILES['fields']['tmp_name'])) {
                    $uploadedFiles = array();
                    foreach ($fields as $field) {
                        $id_field = $field['id_field'];
                        if ($field['type'] != 'file' || !isset($fileNames[$id_field]) || !$fileNames[$id_field] || !isset($fileTypes[$id_field]) || !$fileTypes[$id_field] || !isset($fileSizes[$id_field]) || !$fileSizes[$id_field] || !isset($fileTempNames[$id_field]) || !$fileTempNames[$id_field])
                            continue;
                        $realFileName = $fileNames[$id_field];
                        $tempFileName = $fileTempNames[$id_field];
                        $size = (float)$fileSizes[$id_field];
                        $attachments[] = array(
                            'rename' => uniqid() . Tools::strtolower(Tools::substr($realFileName, -5)),
                            'content' => Tools::file_get_contents($tempFileName),
                            'tmp_name' => $tempFileName,
                            'name' => $realFileName,
                            'mime' => $fileTypes[$id_field],
                            'error' => isset($_FILES['fields']['error'][$id_field]) ? $_FILES['fields']['error'][$id_field] : '',
                            'size' => $size,
                        );
                        $download = new LC_Download();
                        $download->filename = $realFileName;
                        $download->file_type = $fileTypes[$id_field];
                        $download->file_size = (float)$size / 1024;
                        $download->id_customer = $id_customer;
                        if ($form->save_customer_file) {
                            $newFileName = Tools::passwdGen(20);
                            while (file_exists(_PS_ETS_LIVE_CHAT_UPLOAD_DIR_ . $newFileName))
                                $newFileName = Tools::passwdGen(20);
                            $uploadedFiles[] = _PS_ETS_LIVE_CHAT_UPLOAD_DIR_ . $newFileName;
                            $download->name = $newFileName;
                            if (!move_uploaded_file($tempFileName, _PS_ETS_LIVE_CHAT_UPLOAD_DIR_ . $newFileName)) {
                                $errors[] = sprintf($this->l('Could not upload file: %s'), $realFileName);
                                break;
                            }
                        } else
                            $download->name = '';
                        if (!$errors && $download->add())
                            $this->addFormFieldValue($id_field, $realFileName, $download->id);
                        elseif (!$errors) {
                            $errors[] = sprintf($this->l('Could not add file: %s'), $realFileName);
                            break;
                        }
                    }
                }
            } else
                $errors[] = $this->l('Could not add ticket');
            if ($errors) {
                if (isset($uploadedFiles) && $uploadedFiles)
                    foreach ($uploadedFiles as $file)
                        if (file_exists(_PS_ETS_LIVE_CHAT_UPLOAD_DIR_ . $file))
                            @unlink(_PS_ETS_LIVE_CHAT_UPLOAD_DIR_ . $file);

                if ($ticket->id)
                    $ticket->delete();
            }
            if (!$errors) {
                if ($form->mail_new_ticket) {
                    $email_info = $form->getEmailAdminInfo($department);
                    if ($email_info && $mails_to = $email_info['mails_to']) {
                        $names_to = $email_info['names_to'];
                        $mailContent = LC_Mail::displayFieldValues($ticket->id);
                        $link_admin = Ets_livechat::getInstance()->getAdminLink(false, false);
                        $template_vars = array(
                            '{mail_content}' => $mailContent,
                            '{mail_content_txt}' => nl2br(strip_tags($mailContent)),
                            '{link_reply}' => $link_admin,
                            '{admin_url}' => $link_admin,
                            '{customer}' => $ticket->customer_name,
                        );
                        $ticket->send_email_admin = 'success';
                        foreach ($mails_to as $key => $mail) {
                            if (!LC_Mail::send(
                                null,
                                $isAdmin ? 'admin_new_ticket_admin' : 'new_ticket_admin',
                                array(
                                    'origin' => 'A new ticket has been submitted',
                                    'translation' => $this->l('A new ticket has been submitted'),
                                    'specific' => 'lc_ticket',
                                ),
                                $template_vars,
                                array(
                                    'employee' => $mail
                                ),
                                $names_to[$key],
                                $form->send_from_email ?: null,
                                $form->send_from_name ?: null,
                                !$form->save_customer_file ? $attachments : null,
                                null,
                                dirname(__FILE__) . '/../../mails/',
                                true,
                                $context->shop->id,
                                null,
                                $ticket->customer_email ? $ticket->customer_email : null,
                                $ticket->customer_name ? $ticket->customer_name : null
                            ))
                                $ticket->send_email_admin = 'error';;
                        }
                    }
                }
                if (($form->send_mail_to_customer || $isAdmin) && $ticket->customer_name && $ticket->customer_email) {
                    $template_vars = array(
                        '{mail_content}' => LC_Mail::displayFieldValues($ticket->id),
                        '{mail_content_txt}' => strip_tags(LC_Mail::displayFieldValues($ticket->id)),
                        '{customer_name}' => $ticket->customer_name,
                        '{subject}' => $ticket->subject,
                        '{staff}'=> isset($employee) ? $employee->firstname.' '.$employee->lastname:'',
                        '{view_ticket}' => $customer->logged ? Module::getInstanceByName('ets_livechat')->displayText($this->l('View ticket'), 'a', 'button_link button_view_ticket', array('href' => $context->link->getModuleLink(Ets_livechat::getInstance()->name, 'ticket', array('viewticket' => 1, 'id_ticket' => $ticket->id)))) : '',
                        '{link_ticket}' => $context->link->getModuleLink(Ets_livechat::getInstance()->name, 'ticket', array('viewticket' => 1, 'id_ticket' => $ticket->id,'token' => md5(_COOKIE_KEY_.$ticket->id.$ticket->date_add))),
                    );
                    if (LC_Mail::send(
                        null,
                        $isAdmin ? 'admin_new_ticket_customer': 'new_ticket_customer',
                        $isAdmin ? array(
                            'origin' => 'A new ticket is created for you',
                            'translation' => $this->l('A new ticket is created for you'),
                            'specific' => 'lc_ticket',
                        ): array(
                            'origin' => 'Your ticket has been submitted',
                            'translation' => $this->l('Your ticket has been submitted'),
                            'specific' => 'lc_ticket',
                        ),
                        $template_vars,
                        array(
                            'customer' => $ticket->customer_email
                        ),
                        $ticket->customer_name,
                        Configuration::get('PS_SHOP_EMAIl'),
                        Configuration::get('PS_SHOP_NAME'),
                        !$form->save_customer_file || !$customer->logged ? $attachments : null,
                        null,
                        dirname(__FILE__) . '/../../mails/',
                        false
                    ))
                        $ticket->send_email_customer = 'success';
                    else
                        $ticket->send_email_customer = 'error';
                }
                if ($ticket->send_email_admin || $ticket->send_email_customer)
                    $ticket->update();
            }
        }
        return array(
            'success' => !$errors ? $this->l('Ticket added successfully'):false,
            'errors' => $errors ?: false,
            'warnings' => $warnings ?: false,
            'ticket' => isset($ticket) && $ticket->id ? $ticket : null,
        );
    }

    /**
     * @param LC_Ticket_form $form
     * @param $fieldValues
     * @return array|bool
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public function validateSubmitFields($form, $fieldValues)
    {
        $errors = array();
        $context = Context::getContext();
        if (!($fields = $form->getFormFields()))
            $errors[] = $this->l('No data field available');
        if (!is_array($fieldValues) || !$fieldValues)
            $errors[] = $this->l('No data submitted');
        if ($errors)
            return $errors;
        foreach ($fields as $field) {
            if ($field['type'] == 'file')
                continue;
            $id_field = (int)$field['id_field'];
            $fieldValue = isset($fieldValues[$id_field]) ? $fieldValues[$id_field] : '';
            $field_class = new LC_Ticket_Field($id_field, $context->language->id);
            if ($field_class->required && !$fieldValue)
                $errors[] = sprintf($this->l('%s is required'), $field_class->label);
            elseif($field['type']=='checkbox')
            {
                if ($fieldValue && !LC_Tools::validateArray($fieldValue))
                    $errors[] = sprintf($this->l('%s is not valid'), $field_class->label);
            }
            elseif ($fieldValue && (!Validate::isCleanHtml($fieldValue) || $field_class->type == 'email' && !Validate::isEmail($fieldValue) || $field_class->type == 'phone_number' && !Validate::isPhoneNumber($fieldValue)))
                $errors[] = sprintf($this->l('%s is not valid'), $field_class->label);
        }
        $max_size = (float)Configuration::get('ETS_LC_MAX_FILE_MS');
        $name_files = isset($_FILES['fields']['name']) ? str_replace(array(' ','(',')','!','@','#','+'), '_', $_FILES['fields']['name']) : array();
        $size_files = isset($_FILES['fields']['size']) ? $_FILES['fields']['size'] : array();
        $temp_files = isset($_FILES['fields']['tmp_name']) ? $_FILES['fields']['tmp_name'] : array();
        foreach ($fields as $field) {
            if ($field['type'] != 'file')
                continue;
            $id_field = (int)$field['id_field'];
            $name_file = isset($name_files[$id_field]) ? trim($name_files[$id_field]) : false;
            $field_class = new LC_Ticket_Field($id_field, $context->language->id);
            if ($field_class->required && !$name_file)
                $errors[] = $field_class->label . ' ' . $this->l('is required');
            elseif ($name_file && !Validate::isFileName($name_file))
                $errors[] = sprintf($this->l('%s is not a valid file name. Try to rename your file without space or special characters then upload again.'), $name_file);
            elseif ($name_file && ($fileType = Tools::strtolower(pathinfo($name_file, PATHINFO_EXTENSION))) && !in_array($fileType, Ets_livechat::getInstance()->file_types) || !isset($size_files[$id_field]))
                $errors[] = sprintf($this->l('%s is not a valid file format'), $field_class->label);
            elseif ($name_file && (!isset($size_files[$id_field]) || !isset($temp_files[$id_field])))
                $errors[] = sprintf($this->l('%s may have been broken'), $name_file);
            elseif (($file_size = Tools::ps_round($size_files[$id_field] / 1048576, 2)) && $max_size > 0 && $file_size > $max_size)
                $errors[] = sprintf($this->l('%s size exceeds the allowable limit'), $field_class->label);
        }
        if ($form->allow_captcha && (!(isset($context->customer) && isset($context->customer->logged) && $context->customer->logged) || !$form->customer_no_captcha) && !(isset($context->employee) && isset($context->employee) && $context->employee->id)) {
            if ($form->captcha_type == 'image') {
                $captchaCode = isset($fieldValues['field_captcha']) ? $fieldValues['field_captcha']:'';
                if (!$captchaCode)
                    $errors[] = $this->l('Captcha code is required');
                elseif (Context::getContext()->cookie->ets_lc_ticket_captcha_code) {
                    $ets_lc_ticket_captcha_code = json_decode(Context::getContext()->cookie->ets_lc_ticket_captcha_code, true);
                    if (isset($ets_lc_ticket_captcha_code[$form->id]) && $ets_lc_ticket_captcha_code[$form->id] != $captchaCode)
                        $errors[] = $this->l('Captcha code is not valid');
                }
            } else {
                if ($form->captcha_type == 'google-v2' || $form->captcha_type == 'google-v3') {
                    $gresponse = isset($fieldValues['g_recaptcha_response']) ? $fieldValues['g_recaptcha_response']:'';
                    if (!$gresponse) {
                        $errors[] = $this->l('reCAPTCHA is invalid');
                    } else {
                        $recaptcha = $gresponse ?: '';
                        $secret = $form->captcha_type == 'google-v2' ? $form->google2_secret_key : $form->google3_secret_key;
                        $link_capcha = "https://www.google.com/recaptcha/api/siteverify?secret=" . $secret . "&response=" . $recaptcha . "&remoteip=" . Tools::getRemoteAddr();
                        if ($recaptcha) {
                            $response = json_decode(Tools::file_get_contents($link_capcha), true);
                            if ($response['success'] == false) {
                                $errors[] = $this->l('reCAPTCHA is invalid');
                            }
                        }
                    }
                }
            }
        }
        return $errors ? $errors : true;
    }

    public function addFormFieldValue($id_field, $value, $id_download = 0)
    {
        if (!$this->id)
            return false;
        return Db::getInstance()->execute('
            INSERT INTO `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_field`(`id_message`,`id_field`,`id_download`,`value`) 
            VALUES(' . (int)$this->id . ',' . (int)$id_field . ',' . (int)$id_download . ',"' . pSQL($value) . '")'
        );
    }

    public function getFieldValues()
    {
        if (!$this->id)
            return false;
        $context = Context::getContext();
        if ($fieldValues = Db::getInstance()->executeS("
            SELECT fmf.*, ffl.label, ff.type, ff.is_contact_name, d.file_type,d.file_size,d.filename,d.name as saved_filename
            FROM `" . _DB_PREFIX_ . "ets_livechat_ticket_form_message_field` fmf
            LEFT JOIN `" . _DB_PREFIX_ . "ets_livechat_ticket_form_field` ff ON fmf.id_field=ff.id_field
            LEFT JOIN `" . _DB_PREFIX_ . "ets_livechat_ticket_form_field_lang` ffl ON ff.id_field=ffl.id_field AND ffl.id_lang=" . (int)$context->language->id . "
            LEFT JOIN `" . _DB_PREFIX_ . "ets_livechat_download` d ON fmf.id_download=d.id_download
            WHERE fmf.id_message = " . (int)$this->id . "
            ORDER BY ff.position ASC
        ")) {
            foreach ($fieldValues as &$value) {
                $value['value'] = Ets_livechat::replace_link(nl2br($value['value']));
                $value['link_download'] = $value['saved_filename'] ? $context->link->getModuleLink(Ets_livechat::getInstance()->name, 'download', array('downloadfile' => $value['saved_filename'])) : null;
                $value['display_file_size'] = $value['file_size'] ? ($value['file_size'] > 1024 ? Tools::ps_round($value['file_size'] / 1024) . ' MB' : Tools::ps_round($value['file_size']) . ' KB') : null;
            }
        }
        return $fieldValues;
    }

    public static function getInstance()
    {
        if (!isset(self::$instance)) {
            self::$instance = new LC_Ticket();
        }
        return self::$instance;
    }

    // New code:
    public static function getListTickets($count = false, $filter = false, $sort = false, $sort_type = false, $limit = false, $start = 0, Context $context = null)
    {
        if (!$context) {
            $context = Context::getContext();
        }
        // admin:
        $sql = 'SELECT ' . ($count ? 'COUNT(DISTINCT fm.id_message)' : 'fm.*,c.id_lang,fl.title,c.firstname,c.lastname,c.email,f.default_priority ,fmf1.value as email_customer, fmf2.value as name_customer,o.reference') . ' 
            FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message` fm
            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form` f ON (fm.id_form=f.id_form)
            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_lang` fl ON (f.id_form=fl.id_form AND fl.id_lang="' . (int)$context->language->id . '")
            LEFT JOIN `' . _DB_PREFIX_ . 'customer` c ON (fm.id_customer=c.id_customer)
            '
            . ($context->employee->id_profile != 1 ?
                '
                    LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_departments` d ON (fm.id_departments = d.id_departments)
                    LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_departments_employee` de ON (d.id_departments=de.id_departments)
                ' : ''
            )
            . '
            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_field` ff1 ON (ff1.id_form =f.id_form AND ff1.is_contact_mail=1)
            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_field` ff2 ON (ff2.id_form =f.id_form AND ff2.is_contact_name=1)
            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_field` fmf1 ON (fmf1.id_message= fm.id_message AND fmf1.id_field=ff1.id_field)
            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_field` fmf2 ON (fmf2.id_message= fm.id_message AND fmf2.id_field=ff2.id_field)
            LEFT JOIN `' . _DB_PREFIX_ . 'orders` o ON (o.id_order=fm.id_order)
            WHERE 1 '
            . ($context->employee->id_profile != 1 ? ' AND (fm.id_departments <=0  OR de.id_employee="' . (int)$context->employee->id . '" OR d.all_employees=1) AND (fm.id_employee<=0 OR fm.id_employee="' . (int)$context->employee->id . '")' : '')
            . (!LC_Tools::allShop() ? ' AND fm.id_shop="' . (int)$context->shop->id . '"' : '')
            . ($filter ? (string)$filter : '');

        if ($count) {
            return Db::getInstance()->getValue($sql);
        }

        $sql .= ($sort ? ' ORDER BY ' . pSQL($sort) : '') . ' '
            . ($sort_type && $sort ? pSQL($sort_type) : '')
            . ($limit ? ' LIMIT ' . (int)$start . ',' . (int)$limit : '');
        $tickets = Db::getInstance()->executeS($sql);
        return $tickets;
    }
    /**
     * @param $id_ticket
     * @param int $is_manager_ticket
     * @return bool
     */
    public static function makeReadTicket($id_ticket, $is_manager_ticket = 0)
    {
        if (!$id_ticket ||
            !Validate::isUnsignedInt($id_ticket)
        ) {
            return false;
        }
        return Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message` SET ' . ($is_manager_ticket ? '' : 'customer_') . 'readed = 1 WHERE id_message=' . (int)$id_ticket);
    }

    public static function getCountOrder($id_customer)
    {
        if(Module::isEnabled('ets_shoplicense'))
        {
            return Hook::exec('actionCheckLicenseByIdCustomer',array('id_customer'=>$id_customer));
        }
        return Db::getInstance()->getValue('SELECT COUNT(id_order) FROM `' . _DB_PREFIX_ . 'orders` WHERE id_customer=' . (int)$id_customer);
    }

    /**
     * @param $email
     * @return bool
     */
    public static function managerTicket($email)
    {
        $manager = trim(Configuration::get('ETS_LC_NUMBER_TICKET_MANAGER'));
        $mails = trim($manager) !== '' ? explode(',', $manager) : [];
        if (is_array($mails)
            && count($mails) > 0
        ) {
            foreach ($mails as $mail) {
                if (trim($mail) == trim($email)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static function getContentTicket($ticket)
    {
        $fields = Db::getInstance()->executeS('
            SELECT `value` 
            FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_field` tfmf
                INNER JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_field` tff ON (tff.id_field = tfmf.id_field)
            WHERE tfmf.id_message = ' . (int)$ticket['id_message'] . '
                AND (tff.type="text_editor" OR tff.type="text") 
                AND tff.is_contact_mail = 0 
                AND tff.is_contact_name = 0 
                AND tff.is_subject = 0 
                AND tff.is_customer_phone_number = 0
        ');
        $txt = '';
        if ($fields) {
            foreach ($fields as $field)
                $txt .= ' ' . $field['value'];
        }
        return $txt;
    }
    public static function getLastStaff($id_message)
    {
        $LastEmployee = LC_Ticket::getLastStaffReplyMessage($id_message);
        $lastManager = LC_Ticket::getLastManagerReplyMessage($id_message);
        if($lastManager && $LastEmployee)
        {
            if($lastManager['id_note'] > $LastEmployee['id_note'])
                return LC_Departments::getStaffByCustomer($lastManager['id_customer']);
            else
                return LC_Departments::getStaffByEmployee($LastEmployee['id_employee']);

        }elseif($LastEmployee)
             return LC_Departments::getStaffByEmployee($LastEmployee['id_employee']);
        elseif($lastManager)
            return LC_Departments::getStaffByCustomer($lastManager['id_customer']);
        return false;
    }
    public static function getLastStaffReplyMessage($id_message)
    {
        return Db::getInstance()->getRow('SELECT n.id_employee,n.id_note 
        FROM `'._DB_PREFIX_.'ets_livechat_ticket_form_message_note` n
        INNER JOIN `'._DB_PREFIX_.'employee` e ON (e.id_employee=n.id_employee AND e.active=1) 
        WHERE n.id_message='.(int)$id_message.' AND n.id_employee >0 ORDER BY n.id_note DESC');
    }
    public static function getLastManagerReplyMessage($id_message)
    {
        if(($managerMail = Configuration::get('ETS_LC_NUMBER_TICKET_MANAGER')) && ($managerMail = explode(',',$managerMail)))
        {
            return Db::getInstance()->getRow('SELECT n.id_customer,n.id_note FROM `'._DB_PREFIX_.'ets_livechat_ticket_form_message_note` n
            INNER JOIN `'._DB_PREFIX_.'customer` c ON (c.id_customer=n.id_customer AND c.active=1) 
            WHERE c.email IN ("'.implode('","',array_map('pSQL',$managerMail)).'") AND n.id_message='.(int)$id_message.' AND n.id_customer >0 ORDER BY n.id_note DESC');
        }
    }
    public static function getCountTicketNoReaded($id_customer)
    {
        Db::getInstance()->getValue('SELECT COUNT(DISTINCT m.id_message) FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message` m
        INNER JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note` n ON (m.id_message = n.id_message)
        WHERE m.id_customer = "' . (int)$id_customer . '" AND n.readed=0 AND n.id_employee!=0');
    }
    public static function getEmailCustomer($ticket)
    {
        if (!is_array($ticket)) {
            $sql = 'SELECT fm.*,fl.title,c.firstname,c.lastname,c.email,f.default_priority,c.id_lang,c.id_customer 
            FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message` fm
            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form` f ON (fm.id_form=f.id_form)
            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_lang` fl ON (f.id_form=fl.id_form AND fl.id_lang="' . (int)Context::getContext()->language->id . '")
            LEFT JOIN `' . _DB_PREFIX_ . 'customer` c ON (fm.id_customer=c.id_customer)
            WHERE fm.id_message="' . (int)$ticket . '"';
            $ticket = Db::getInstance()->getRow($sql);
        }
        $form = new LC_Ticket_form($ticket['id_form']);
        if ($ticket['email']) {
            return array(
                'email' => $ticket['email'],
                'name' => $ticket['firstname'] . ' ' . $ticket['lastname'],
                'id_lang' => isset($ticket['id_lang']) ? $ticket['id_lang'] : null,
                'id_customer' => isset($ticket['id_customer']) ? $ticket['id_customer'] : 0,
            );
        }
        if ($form->send_mail_to_customer || $form->send_mail_reply_customer) {
            $is_contact_email = false;
            $is_contact_name = false;
            $fields = Db::getInstance()->executeS(
                'SELECT ff.*,fmf.value FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_field` ff
                LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_field` fmf ON (ff.id_field = fmf.id_field)
                WHERE fmf.id_message="' . (int)$ticket['id_message'] . '"');
            if ($fields) {
                foreach ($fields as $field) {
                    if ($field['value'] && $field['is_contact_mail'] && !$is_contact_email && $field['type'] == 'email') {
                        $customer_email = $field['value'];
                        $is_contact_email = true;
                    }
                    if ($field['value'] && $field['is_contact_name'] && !$is_contact_name && $field['type'] == 'text') {
                        $customer_name = $field['value'];
                        $is_contact_name = true;
                    }
                }
            }
            if ($is_contact_email) {
                return array(
                    'email' => isset($customer_email) ? $customer_email : '',
                    'name' => isset($customer_name) ? $customer_name : '',
                    'id_lang' => Configuration::get('PS_LANG_DEFAULT'),
                    'id_customer' => 0,
                );
            }
        }
        return false;
    }
    public static function getAttachmentsTickets($count = false, $filter = false)
    {
        $sql = 'SELECT f.id_message, f.id_field,f.id_download,f.value FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_field` f
        INNER JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message` t ON (f.id_message= t.id_message)
        WHERE f.id_download!=0 ' . ($filter ? (string)$filter : '') . (!LC_Tools::allShop() ? ' AND t.id_shop="' . (int)Context::getContext()->shop->id . '"' : '');
        $attachments = Db::getInstance()->executeS($sql);
        if ($count) {
            $total = 0;
            if ($attachments) {
                foreach ($attachments as $attachment) {
                    $download = new LC_Download($attachment['id_download']);
                    $total += $download->file_size;
                }
            }
            return array(
                'count' => count($attachments),
                'size' => $total
            );
        } else {
            if ($attachments) {
                foreach ($attachments as $attachment) {
                    $download = new LC_Download($attachment['id_download']);
                    $download->delete();
                    Db::getInstance()->execute('DELETE FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_field` WHERE id_download="' . (int)$download->id . '"');
                }
                return true;
            }
        }
        return true;
    }
    public static function getTicketExpriedSupport($days)
    {
        $sql = 'SELECT m.id_message,m.id_customer,m.subject,m.id_form,m.id_shop FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message` m
            LEFT JOIN (
                SELECT id_message,MAX(id_note) as id_note_max FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note` GROUP BY id_message
            ) note_max ON (note_max.id_message = m.id_message)
            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note` n ON (n.id_note=note_max.id_note_max)
            WHERE m.status="open" AND n.id_note is not null AND n.id_employee!=0 AND n.date_add < "' . pSQL(date('Y-m-d H:i:s', strtotime("- $days days"))) . '"';
        return Db::getInstance()->executeS($sql);
    }
    public static function getFieldTicket($id_ticket)
    {
        $query = 'SELECT mf.value,fl.label,f.type,mf.id_download,f.is_contact_name 
                FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_field` mf
                LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_field` f ON (f.id_field = mf.id_field)
                LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_field_lang` fl ON (mf.id_field = fl.id_field)
                WHERE mf.id_message=' . (int)$id_ticket . ' AND fl.id_lang=' . (int)Context::getContext()->language->id;
        return Db::getInstance()->executeS($query);
    }
    public static function getTickets($count = false, $filter = false, $sort = false, $sort_type = false, $limit = false, $start = 0)
    {
        $isManger = LC_Ticket_process::getInstance()->setContext(Context::getContext())->isManagerTicket();
        $sql = '
            SELECT '.($count ? ' distinct fm.id_message':'fm.*,fl.title,c.firstname,c.lastname,c.email,f.default_priority,n.date_add as date_add_note ').' 
            FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message` fm
            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form` f ON (fm.id_form=f.id_form)
            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_lang` fl ON (f.id_form=fl.id_form AND fl.id_lang="' . (int)Context::getContext()->language->id . '")
            LEFT JOIN `' . _DB_PREFIX_ . 'customer` c ON (fm.id_customer=c.id_customer)
            LEFT JOIN (
                SELECT id_message, MAX(id_note) as id_note_max 
                FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note` 
                GROUP BY id_message
            ) note_max ON (note_max.id_message = fm.id_message)
            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note` n ON (n.id_note=note_max.id_note_max)            
            WHERE 1 '
            . (!$isManger ? 'AND fm.id_customer="' . (int)Context::getContext()->customer->id . '"' : '')
            .(($context = Context::getContext()) && isset($context->customer) && isset($context->customer->email) && LC_Ticket::managerTicket($context->customer->email) && Configuration::get('ETS_LC_ONLY_DISPLAY_TICKET_OPEN') ? ' AND fm.status="open"':'')
            . (!LC_Tools::allShop() ? ' AND fm.id_shop="'.(int)Context::getContext()->shop->id.'"':'')
            . ($filter ? (string)$filter : '');
        if ($count)
            return Db::getInstance()->getValue($sql);
        $sql .= ' GROUP BY fm.id_message'
                . ($sort ? ' ORDER BY ' . pSQL($sort) : '') . ' ' . ($sort_type && $sort ? pSQL($sort_type) : '')
                . ($limit ? ' LIMIT ' . (int)$start . ',' . (int)$limit : '');
        $tickets = Db::getInstance()->executeS($sql);
        if ($tickets) {
            foreach ($tickets as &$ticket) {
                $ticket['link_view'] = Context::getContext()->link->getModuleLink('ets_livechat', 'ticket', array('viewticket' => 1, 'id_ticket' => $ticket['id_message']));
                $ticket['link_delete'] = Context::getContext()->link->getModuleLink('ets_livechat', 'ticket', array('deleteticket' => 1, 'id_ticket' => $ticket['id_message']));
                if($isManger)
                {
                    $ticket['has_order'] = LC_Ticket::getCountOrder((int)$ticket['id_customer']);
                    $ticket['has_product_expried'] = Hook::exec('actionCheckLicenseExpried',array('id_customer'=>$ticket['id_customer']));
                }
                if ($isManger && (int)$ticket['readed'] <= 0 || !$isManger && (int)$ticket['customer_readed'] <= 0) {
                    $ticket['no_readed'] = 1;
                } else {
                    $ticket['no_readed'] = 0;
                }
                $id_note_max = Db::getInstance()->getValue('SELECT MAX(id_note) FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note` WHERE id_message=' . (int)$ticket['id_message']);
                if ($id_note_max) {
                    $ticket['note'] = Db::getInstance()->getRow(
                        'SELECT note.note,note.file_name,note.id_download,d.file_size,note.send_email_customer,note.send_email_admin FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note` note
                        LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_download` d ON (note.id_download = d.id_download)
                        WHERE note.id_note =' . (int)$id_note_max
                    );
                    $ticket['note']['link_download'] = Context::getContext()->link->getModuleLink('ets_livechat', 'download', array('downloadfile' => md5(_COOKIE_KEY_ . $ticket['note']['id_download'])));
                } else
                    $ticket['content'] = LC_Ticket::getContentTicket($ticket);
            }
        }
        return $tickets;
    }
    public static function getMinYear()
    {
        return (int)Db::getInstance()->getValue('SELECT MIN(YEAR(date_add)) FROM `'._DB_PREFIX_.'ets_livechat_ticket_form_message`');
    }
    public static function getRecentlyTicket()
    {
        return Db::getInstance()->executeS('SELECT * FROM `'._DB_PREFIX_.'ets_livechat_ticket_form_message` WHERE 1 '.(!LC_Tools::allShop() ? ' AND id_shop="'.(int)Context::getContext()->shop->id.'"':'').' ORDER BY id_message DESC LIMIT 0,5');
    }
    public static function getCountTicket($filter=false)
    {
        $sql ='SELECT COUNT(t.id_message) FROM `'._DB_PREFIX_.'ets_livechat_ticket_form_message` t WHERE 1'.(!LC_Tools::allShop() ? ' AND id_shop='.(int)Context::getContext()->shop->id:'').($filter ? (string)$filter:'');
        return Db::getInstance()->getValue($sql);
    }
    public static function markAsRead($id_tickets)
    {
        if($id_tickets && is_array($id_tickets))
            return Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message` SET readed="1" WHERE id_message IN (' . implode(',', array_map('intval', $id_tickets)) . ')');
        return false;
    }
    public static function markAsUnread($id_tickets)
    {
        if($id_tickets && is_array($id_tickets))
            return Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message` SET readed="0" WHERE id_message IN (' . implode(',', array_map('intval', $id_tickets)) . ')');
        return false;
    }
    public static function markAsDelete($id_tickets)
    {
        if($id_tickets && is_array($id_tickets))
        {
            return Db::getInstance()->execute('DELETE FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message` WHERE id_message IN (' . implode(',', array_map('intval', $id_tickets)) . ')');
        }
        return false;
    }
}