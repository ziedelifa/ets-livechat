<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) { exit; }

class LC_Tools
{
    static $all_shop=false;

    /**
     * @return int
     */
    public static function allShop()
    {
        if (self::$all_shop===false) {
            self::$all_shop = Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE') && Shop::getContext() == Shop::CONTEXT_ALL ? 1 : 0;
        }
        return self::$all_shop;
    }

    /**
     * @param $type
     * @return string
     */
    public static function getFormattedName($type)
    {
        return version_compare(_PS_VERSION_, '1.7', '>=') ? ImageType::getFormattedName($type) : ImageType::getFormatedName($type);
    }

    public static function getNameHide($name)
    {
        $name = trim($name);
        for ($i = 0; $i < Tools::strlen($name) - 1; $i++) {
            if ($name[$i] != ' ' && $name[$i + 1] == ' ')
                return $name[0] . '.' . Tools::substr($name, $i + 2);
        }
        return $name;
    }

    public static function validateArray($array, $validate = 'isCleanHtml')
    {
        if (!is_array($array))
            return false;
        if (method_exists('Validate', $validate)) {
            if ($array && is_array($array)) {
                $ok = true;
                foreach ($array as $val) {
                    if (!is_array($val)) {
                        if ($val && !Validate::$validate($val)) {
                            $ok = false;
                            break;
                        }
                    } else
                        $ok = self::validateArray($val, $validate);
                }
                return $ok;
            }
        }
        return true;
    }
    public static function checkCreatedColumn($table, $column)
    {
        $fieldsCustomers = Db::getInstance()->ExecuteS('DESCRIBE ' . _DB_PREFIX_ . bqSQL($table));
        $check_add = false;
        foreach ($fieldsCustomers as $field) {
            if ($field['Field'] == $column) {
                $check_add = true;
                break;
            }
        }
        return $check_add;
    }
    public static function getMatchingUrlShopId()
    {
        $urlShopId ='';
        $host = Tools::getHttpHost();
        $request_uri = rawurldecode($_SERVER['REQUEST_URI']);
        $sql = 'SELECT s.id_shop, CONCAT(su.physical_uri, su.virtual_uri) AS uri, su.domain, su.main
                FROM `' . _DB_PREFIX_ . 'shop_url` su
                LEFT JOIN `' . _DB_PREFIX_ . 'shop` s ON (s.id_shop = su.id_shop)
                WHERE (su.domain = \'' . pSQL($host) . '\' OR su.domain_ssl = \'' . pSQL($host) . '\')
                    AND s.active = 1
                    AND s.deleted = 0
                ORDER BY LENGTH(CONCAT(su.physical_uri, su.virtual_uri)) DESC';
        try {
            $result = Db::getInstance()->executeS($sql);
        } catch (PrestaShopDatabaseException $e) {
            return null;
        }
        foreach ($result as $row) {
            // A shop matching current URL was found
            if (preg_match('#^' . preg_quote($row['uri'], '#') . '#i', $request_uri)) {
                $urlShopId = $row['id_shop'];

                break;
            }
        }
        return $urlShopId;
    }
    public static function checkIsLinkRewrite($link)
    {
        if (Configuration::get('PS_ALLOW_ACCENTED_CHARS_URL')) {
            return preg_match(Tools::cleanNonUnicodeSupport('/^[_a-zA-Z\x{0600}-\x{06FF}\pL\pS-]{1}[_a-zA-Z0-9\x{0600}-\x{06FF}\pL\pS-]+$/u'), $link);
        }
        return preg_match('/^[_a-zA-Z\-]{1}[_a-zA-Z0-9\-]+$/', $link);
    }
}