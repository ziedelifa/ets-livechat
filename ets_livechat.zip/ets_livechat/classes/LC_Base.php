<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) { exit; }
class LC_Base
{
    protected static $instance;
    protected static $configs;
    public function l($string, $source = null)
    {
        return Translate::getModuleTranslation('ets_livechat', $string, $source ?: pathinfo(__FILE__, PATHINFO_FILENAME));
    }
    public static function getInstance()
    {
        if (!isset(self::$instance)) {
            self::$instance = new LC_Base();
        }
        return self::$instance;
    }
    public function setConfig()
    {
        if (isset(self::$configs)) {
            return self::$configs;
        }
        if (LC_Base::checkVesionModule()) {
            $ticket_forms = LC_Ticket_form::getForms(false);
        } else
            $ticket_forms = array();
        $admin_dir = basename(getcwd());
        $groups = Group::getGroups(Context::getContext()->language->id);
        $customerGroups = array(
            array(
                'id_option' => 'all',
                'name' => $this->l('All'),
            )
        );
        if ($groups) {
            foreach ($groups as $group) {
                $customerGroups[] = array(
                    'id_option' => $group['id_group'],
                    'name' => $group['name'],
                );
            }
        }
        self::$configs = array(
            'ETS_LC_TEXT_HEADING_ONLINE' => array(
                'label' => $this->l('Chat box heading text'),
                'type' => 'text',
                'default' => $this->l('Chat with us'),
                'default_lang' => 'Chat with us',
                'tab' => 'status',
                'required' => true,
                'form_group_class' => 'status lc_online change_form',
                'lang' => true,
                'validate' => 'isCleanHtml',
            ),
            'ETS_LC_HEADING_COLOR_ONLINE' => array(
                'label' => $this->l('Heading background color'),
                'tab' => 'status',
                'type' => 'color',
                'default' => '#76a600',
                'validate' => 'isColor',
                'form_group_class' => 'status lc_online change_form',
                'required' => true,
            ),
            'ETS_LC_TEXT_ONLINE' => array(
                'label' => $this->l('Welcome message'),
                'type' => 'textarea',
                'tab' => 'status',
                'default' => $this->l('Hi there we\'re online! Can we help you?'),
                'default_lang' => 'Hi there we\'re online! Can we help you?',
                'required' => true,
                'form_group_class' => 'status lc_online change_form',
                'lang' => true,
                'validate' => 'isCleanHtml',
            ),
            'ETS_LC_FORCED_ONLINE_DAY' => array(
                'label' => $this->l('Forced online day(s)'),
                'type' => 'checkbox',
                'tab' => 'status',
                'form_group_class' => 'status lc_online change_form online_days',
                'all' => true,
                'default' => 'all',
                'desc' => $this->l('Select days of the week to set the live chat service\'s active status to "Online". These days, whether the site manager and staff are online or not, the front end live chat service\'s status will always be "Online".'),
                'values' => array(
                    'query' => array(
                        array(
                            'id' => '1',
                            'label' => $this->l('Mon'),
                        ),
                        array(
                            'id' => '2',
                            'label' => $this->l('Tue'),
                        ),
                        array(
                            'id' => '3',
                            'label' => $this->l('Web'),
                        ),
                        array(
                            'id' => '4',
                            'label' => $this->l('Thu'),
                        ),
                        array(
                            'id' => '5',
                            'label' => $this->l('Fri'),
                        ),
                        array(
                            'id' => '6',
                            'label' => $this->l('Sat'),
                        ),
                        array(
                            'id' => '7',
                            'label' => $this->l('Sun'),
                        )
                    ),
                    'id' => 'id',
                    'name' => 'label',
                    'validate' => 'isInt',
                ),
            ),
            'ETS_LC_FORCED_ONLINE_HOURS' => array(
                'label' => $this->l('Forced online hour(s)'),
                'type' => 'checkbox',
                'tab' => 'status',
                'form_group_class' => 'status lc_online change_form online_hours',
                'all' => true,
                'default' => 'all',
                'desc' => $this->l('Select a time of day to set the live chat service\'s active status to "Online". During this time, whether the site manager and staff are online or not, the front end live chat service\'s status will always be "Online".'),
                'values' => array(
                    'query' => array(
                        array(
                            'id' => '00',
                            'label' => $this->l('0h'),
                        ),
                        array(
                            'id' => '01',
                            'label' => $this->l('1h'),
                        ),
                        array(
                            'id' => '02',
                            'label' => $this->l('2h'),
                        ),
                        array(
                            'id' => '03',
                            'label' => $this->l('3h'),
                        ),
                        array(
                            'id' => '04',
                            'label' => $this->l('4h'),
                        ),
                        array(
                            'id' => '05',
                            'label' => $this->l('5h'),
                        ),
                        array(
                            'id' => '06',
                            'label' => $this->l('6h'),
                        ),
                        array(
                            'id' => '07',
                            'label' => $this->l('7h'),
                        ),
                        array(
                            'id' => '08',
                            'label' => $this->l('8h'),
                        ),
                        array(
                            'id' => '09',
                            'label' => $this->l('9h'),
                        ),
                        array(
                            'id' => '10',
                            'label' => $this->l('10h'),
                        ),
                        array(
                            'id' => '11',
                            'label' => $this->l('11h'),
                        ),
                        array(
                            'id' => '12',
                            'label' => $this->l('12h'),
                        ),
                        array(
                            'id' => '13',
                            'label' => $this->l('13h'),
                        ),
                        array(
                            'id' => '14',
                            'label' => $this->l('14h'),
                        ),
                        array(
                            'id' => '15',
                            'label' => $this->l('15h'),
                        ),
                        array(
                            'id' => '16',
                            'label' => $this->l('16h'),
                        ),
                        array(
                            'id' => '17',
                            'label' => $this->l('17h'),
                        ),
                        array(
                            'id' => '18',
                            'label' => $this->l('18h'),
                        ),
                        array(
                            'id' => '19',
                            'label' => $this->l('19h'),
                        ),
                        array(
                            'id' => '20',
                            'label' => $this->l('20h'),
                        ),
                        array(
                            'id' => '21',
                            'label' => $this->l('21h'),
                        ),
                        array(
                            'id' => '22',
                            'label' => $this->l('22h'),
                        ),
                        array(
                            'id' => '23',
                            'label' => $this->l('23h'),
                        ),
                    ),
                    'id' => 'id',
                    'name' => 'label',
                    'validate' => 'isCleanHtml',
                ),
            ),
            'ETS_LC_TEXT_HEADING_BUSY' => array(
                'label' => $this->l('Chat box heading'),
                'type' => 'text',
                'default' => $this->l('I\'m busy'),
                'default_lang' => 'I\'m busy',
                'tab' => 'status',
                'form_group_class' => 'status lc_busy change_form',
                'required' => true,
                'lang' => true,
                'validate' => 'isCleanHtml',
            ),
            'ETS_LC_HEADING_COLOR_BUSY' => array(
                'label' => $this->l('Heading background color'),
                'type' => 'color',
                'default' => '#920013',
                'tab' => 'status',
                'form_group_class' => 'status lc_busy change_form',
                'validate' => 'iscolor',
                'required' => true,
            ),
            'ETS_LC_TEXT_DO_NOT_DISTURB' => array(
                'label' => $this->l('Welcome message'),
                'type' => 'textarea',
                'tab' => 'status',
                'form_group_class' => 'status lc_busy change_form',
                'default' => $this->l('Hello. I\'m busy at the moment. Please leave me a chat message, I\'ll get back to you later'),
                'default_lang' => 'Hello. I\'m busy at the moment. Please leave me a chat message, I\'ll get back to you later',
                'required' => true,
                'lang' => true,
                'validate' => 'isCleanHtml',
            ),
            'ETS_LC_TEXT_HEADING_INVISIBLE' => array(
                'label' => $this->l('Chat box heading text'),
                'type' => 'text',
                'default' => $this->l('Chat with us'),
                'default_lang' => 'Chat with us',
                'tab' => 'status',
                'form_group_class' => 'status lc_invisible change_form',
                'required' => true,
                'lang' => true,
                'validate' => 'isCleanHtml',
            ),
            'ETS_LC_HEADING_COLOR_INVISIBLE' => array(
                'label' => $this->l('Heading background color'),
                'type' => 'color',
                'default' => '#505050',
                'tab' => 'status',
                'form_group_class' => 'status lc_invisible change_form',
                'validate' => 'iscolor',
                'required' => true,
            ),
            'ETS_LC_TEXT_INVISIBLE' => array(
                'label' => $this->l('Welcome message'),
                'type' => 'textarea',
                'tab' => 'status',
                'form_group_class' => 'status lc_invisible change_form',
                'default' => $this->l('Hi there I\'m not online at the moment, however you can leave me a message. I\'ll call you back later'),
                'default_lang' => 'Hi there I\'m not online at the moment, however you can leave me a message. I\'ll call you back later',
                'required' => true,
                'lang' => true,
                'validate' => 'isCleanHtml',
            ),
            'ETS_LC_TEXT_HEADING_OFFLINE' => array(
                'label' => $this->l('Chat box heading text'),
                'type' => 'text',
                'default' => $this->l('Chat with us'),
                'default_lang' => 'Chat with us',
                'tab' => 'status',
                'form_group_class' => 'status lc_offline change_form',
                'required' => true,
                'lang' => true,
                'validate' => 'isCleanHtml',
            ),
            'ETS_LC_HEADING_COLOR_OFFLINE' => array(
                'label' => $this->l('Heading background color'),
                'type' => 'color',
                'default' => '#505050',
                'tab' => 'status',
                'form_group_class' => 'status lc_offline change_form',
                'validate' => 'isColor',
                'required' => true,
            ),
            'ETS_LC_TEXT_OFFLINE' => array(
                'label' => $this->l('Welcome message'),
                'type' => 'textarea',
                'tab' => 'status',
                'form_group_class' => 'status lc_offline change_form',
                'default' => $this->l('Hi there I\'m not online at the moment, however you can leave me a message. I\'ll call you back later'),
                'default_lang' => 'Hi there I\'m not online at the moment, however you can leave me a message. I\'ll call you back later',
                'required' => true,
                'lang' => true,
                'validate' => 'isCleanHtml',
            ),
            'ETS_LC_TEXT_OFFLINE_THANKYOU' => array(
                'label' => $this->l('Thank you message'),
                'type' => 'textarea',
                'tab' => 'status',
                'default' => $this->l('We have received your message. We will get back to you soon. Thank you!'),
                'default_lang' => 'We have received your message. We will get back to you soon. Thank you!',
                'lang' => true,
                'form_group_class' => 'status lc_offline change_form',
                'desc' => $this->l('Leave this field blank allows customer to send continuous offline messages (like when they send online messages) without seeing a "thank you" message'),
                'validate' => 'isCleanHtml',
            ),
            'ETS_LC_LIVECHAT_ON' => array(
                'label' => $this->l('Turn on live chat when'),
                'type' => 'radio',
                'tab' => 'chat_box',
                'default' => 'all',
                'js' => 1,
                'validate' => 'isCleanHtml',
                'values' => array(
                    array(
                        'id' => 'ETS_LC_LIVECHAT_ON_all',
                        'value' => 'all',
                        'label' => $this->l('All the time')
                    ),
                    array(
                        'id' => 'ETS_LC_LIVECHAT_ON_online',
                        'value' => 'online',
                        'label' => $this->l('Admin is online only')
                    ),
                    array(
                        'id' => 'ETS_LC_LIVECHAT_ON_never',
                        'value' => 'never',
                        'label' => $this->l('Never (turn off live chat)')
                    )
                ),

            ),
            'ETS_LC_DISPLAY_COMPANY_INFO' => array(
                'label' => $this->l('Supporter info'),
                'type' => 'radio',
                'tab' => 'chat_box',
                'default' => 'staff',
                'js' => 1,
                'validate' => 'isCleanHtml',
                'values' => array(
                    array(
                        'id' => 'ETS_LC_DISPLAY_COMPANY_INFO_staff',
                        'value' => 'staff',
                        'label' => $this->l('Staffs information')
                    ),
                    array(
                        'id' => 'ETS_LC_DISPLAY_COMPANY_INFO_general',
                        'value' => 'general',
                        'label' => $this->l('General information')
                    )
                ),
            ),
            'ETS_LC_COMPANY_LOGO' => array(
                'type' => 'file',
                'tab' => 'chat_box',
                'label' => $this->l('Shop logo'),
                'form_group_class' => 'company_info',
                'default' => 'adminavatar.jpg',
                'desc' => sprintf($this->l('Available image type: jpg, png, gif, jpeg, webp. Limit %dMb'),Configuration::get('PS_ATTACHMENT_MAXIMUM_SIZE')),
            ),
            'ETS_LC_COMPANY_NAME' => array(
                'type' => 'text',
                'tab' => 'chat_box',
                'label' => $this->l('Shop name'),
                'required' => true,
                'default' => 'PrestaHero',
                'form_group_class' => 'company_info change_form',
                'validate' => 'isCleanHtml',
            ),
            'ETS_LC_SUB_TITLE' => array(
                'type' => 'text',
                'tab' => 'chat_box',
                'label' => $this->l('Mood'),
                'default' => $this->l('Ask whatever you want!'),
                'default_lang' => 'Ask whatever you want!',
                'lang' => true,
                'validate' => 'isCleanHtml',
            ),
            'ETS_LC_DISPLAY_AVATA' => array(
                'label' => $this->l('Display avatar in chat box'),
                'type' => 'switch',
                'tab' => 'chat_box',
                'default' => 1,
                'validate' => 'isUnsignedInt',
                'required' => true,
            ),
            'ETS_LC_CUSTOMER_AVATA' => array(
                'label' => $this->l('Default customer avatar'),
                'type' => 'file',
                'tab' => 'chat_box',
                'form_group_class' => 'customer_avata',
                'default' => 'customeravata.jpg',
                'desc' => sprintf($this->l('Available image type: jpg, png, gif, jpeg, webp. Limit %dMb'),Configuration::get('PS_ATTACHMENT_MAXIMUM_SIZE')),
            ),
            'ETS_LC_AVATAR_IMAGE_TYPE' => array(
                'label' => $this->l('Avatar image type on frontend'),
                'type' => 'select',
                'validate' => 'isCleanHtml',
                'options' => array(
                    'query' => array(
                        array(
                            'id_option' => 'rounded',
                            'name' => $this->l('Rounded')
                        ),
                        array(
                            'id_option' => 'square',
                            'name' => $this->l('Square')
                        )
                    ),
                    'id' => 'id_option',
                    'name' => 'name'
                ),
                'default' => 'rounded',
                'tab' => 'chat_box',
                'js' => 1,
                'form_group_class' => 'image_type'
            ),
            'ETS_LC_BOX_WIDTH' => array(
                'label' => $this->l('Frontend chat box width'),
                'type' => 'text',
                'tab' => 'chat_box',
                'default' => 340,
                'required' => true,
                'suffix' => $this->l('px'),
                'validate' => 'isUnsignedInt',
            ),
            'ETS_CLOSE_CHAT_BOX_TYPE' => array(
                'type' => 'select',
                'label' => $this->l('Frontend collapsed chatbox type'),
                'options' => array(
                    'query' => array(
                        array(
                            'id_option' => 'bubble_alert',
                            'name' => $this->l('Bubble circle'),
                        ),
                        array(
                            'id_option' => 'bottom_alert_bar',
                            'name' => $this->l('Bottom bar'),
                        ),
                        array(
                            'id_option' => 'image',
                            'name' => $this->l('Custom image'),
                        ),
                    ),
                    'id' => 'id_option',
                    'name' => 'name'
                ),
                'validate' => 'isCleanHtml',
                'default' => 'bottom_alert_bar',
                'tab' => 'chat_box',
            ),
            'ETS_LC_BUBBLE_IMAGE' => array(
                'label' => $this->l('Chat bubble image'),
                'type' => 'file',
                'tab' => 'chat_box',
                'default' => 'chatbubble.png',
                'form_group_class' => 'lc_bubble_image',
                'desc' => sprintf($this->l('Available image type: jpg, png, gif, jpeg, webp. Limit %dMb'),Configuration::get('PS_ATTACHMENT_MAXIMUM_SIZE')),
            ),
            'ETS_CLOSE_CHAT_BOX_BACKEND_TYPE' => array(
                'type' => 'select',
                'label' => $this->l('Backend collapsed chatbox type'),
                'validate' => 'isCleanHtml',
                'options' => array(
                    'query' => array(
                        array(
                            'id_option' => 'bubble_alert',
                            'name' => $this->l('Floating circle'),
                        ),
                        array(
                            'id_option' => 'small_bubble',
                            'name' => $this->l('Small bubble on top'),
                        ),
                        array(
                            'id_option' => 'bottom_alert_bar',
                            'name' => $this->l('Bottom alert bar'),
                        ),
                    ),
                    'id' => 'id_option',
                    'name' => 'name'
                ),
                'default' => 'bubble_alert',
                'tab' => 'chat_box',
            ),
            'ETS_LC_TEXT_SEND' => array(
                'label' => $this->l('Button label when chatting'),
                'type' => 'text',
                'default' => $this->l('Send'),
                'default_lang' => 'Send',
                'tab' => 'chat_box',
                'js' => 1,
                'required' => true,
                'lang' => true,
                'validate' => 'isCleanHtml',
            ),
            'ETS_LC_TEXT_BUTTON_EDIT' => array(
                'label' => $this->l('Button label when edit'),
                'type' => 'text',
                'default' => $this->l('Edit'),
                'default_lang' => 'Edit',
                'tab' => 'chat_box',
                'js' => 1,
                'required' => true,
                'validate' => 'isCleanHtml',
                'lang' => true,
            ),
            'ETS_LC_TEXT_SEND_OffLINE' => array(
                'label' => $this->l('Button label when offline'),
                'type' => 'text',
                'default' => $this->l('Send offline message'),
                'default_lang' => 'Send offline message',
                'tab' => 'chat_box',
                'js' => 1,
                'required' => true,
                'form_group_class' => 'change_form',
                'lang' => true,
                'validate' => 'isCleanHtml',
            ),
            'ETS_LC_TEXT_SEND_START_CHAT' => array(
                'label' => $this->l('Button label to start chatting when online'),
                'type' => 'text',
                'default' => $this->l('Start chatting!'),
                'default_lang' => 'Start chatting!',
                'tab' => 'chat_box',
                'required' => true,
                'js' => 1,
                'form_group_class' => 'change_form',
                'lang' => true,
                'validate' => 'isCleanHtml',
            ),
            'ETS_DISPLAY_SEND_BUTTON' => array(
                'label' => $this->l('Display SEND button'),
                'type' => 'switch',
                'default' => 1,
                'js' => 1,
                'tab' => 'chat_box',
                'validate' => 'isInt',
            ),
            'LC_BACKGROUD_COLOR_BUTTON' => array(
                'label' => $this->l('Button background color'),
                'type' => 'color',
                'default' => '#00aff0',
                'tab' => 'chat_box',
                'validate' => 'isColor',
            ),
            'LC_BACKGROUD_HOVER_BUTTON' => array(
                'label' => $this->l('Button background color when hover'),
                'type' => 'color',
                'default' => '#00dcfa',
                'tab' => 'chat_box',
                'validate' => 'isColor',
            ),
            'ETS_LC_DISPLAY_REQUIRED_FIELDS' => array(
                'label' => $this->l('Enable 2 steps to start chat'),
                'type' => 'switch',
                'tab' => 'im',
                'default' => 0,
                'validate' => 'isUnsignedInt',
                'required' => true,
                'desc' => $this->l('When customers start chatting, they\'re only required to enter a single message to start the chat'),
                'js' => 1,

            ),
            'ETS_LC_ADDITIONAL_NOTIFICATION' => array(
                'label' => $this->l('Additional notification'),
                'type' => 'textarea',
                'tab' => 'im',
                'default' => $this->l('Sorry for this inconvenience but please enter some additional information to start chatting'),
                'default_lang' => 'Sorry for this inconvenience but please enter some additional information to start chatting',
                'lang' => true,
                'desc' => $this->l('After the first message, customers will see this notification and enter their information to continue chatting as normal'),
                'form_group_class' => 'display_required_fields',
                'validate' => 'isCleanHtml',
            ),
            'ETS_LC_HIDE_ON_MOBILE' => array(
                'label' => $this->l('Hide chatbox on mobile devices'),
                'type' => 'switch',
                'tab' => 'chat_box',
                'default' => 0,
                'validate' => 'isUnsignedInt',
                'required' => true,
            ),
            'ETS_LC_ENABLE_EMOTION_ICON' => array(
                'label' => $this->l('Enable emotion icons'),
                'type' => 'switch',
                'tab' => 'im',
                'default' => 1,
                'validate' => 'isUnsignedInt',
                'required' => true,
            ),
            'ETS_LC_DISPLAY_RATING' => array(
                'label' => $this->l('Allow customer to rate a conversation'),
                'type' => 'switch',
                'default' => 1,
                'tab' => 'im',
                'js' => 1,
                'validate'=> 'isInt',
            ),
            'ETS_LC_DISPLAY_SEND_US_AN_EMAIL' => array(
                'label' => $this->l('Display a support link at chatbox bottom'),
                'type' => 'switch',
                'default' => 1,
                'tab' => 'chat_box',
                'validate' => 'isInt',
            ),
            'ETS_LC_LINK_SUPPORT_TITLE' => array(
                'label' => $this->l('Support link title'),
                'type' => 'text',
                'tab' => 'chat_box',
                'lang' => 1,
                'default' => $this->l('Send us an email'),
                'default_lang' => 'Send us an email',
                'form_group_class' => 'link_support',
                'validate' => 'isCleanHtml',
            ),
            'ETS_LC_LINK_SUPPORT_TYPE' => array(
                'label' => $this->l('Link type'),
                'type' => 'select',
                'options' => array(
                    'query' => array(
                        array(
                            'id_option' => 'contact-form',
                            'name' => $this->l('Contact form')
                        ),
                        array(
                            'id_option' => 'ticket-form',
                            'name' => $this->l('Ticket form')
                        ),
                        array(
                            'id_option' => 'custom-link',
                            'name' => $this->l('Custom link')
                        )
                    ),
                    'id' => 'id_option',
                    'name' => 'name'
                ),
                'default' => 'contact-form',
                'tab' => 'chat_box',
                'validate' => 'isCleanHtml',
                'form_group_class' => 'link_support'
            ),
            'ETS_LC_LINK_SUPPORT_FORM' => array(
                'label' => $this->l('Ticket form'),
                'type' => 'select',
                'options' => array(
                    'query' => $ticket_forms,
                    'id' => 'id_form',
                    'name' => 'title'
                ),
                'default' => 'contact-form',
                'tab' => 'chat_box',
                'validate' => 'isCleanHtml',
                'form_group_class' => 'link_support ticket'
            ),
            'ETS_LC_SUPPORT_LINK' => array(
                'label' => $this->l('Custom link'),
                'type' => 'text',
                'tab' => 'chat_box',
                'lang' => 1,
                'validate' => 'isCleanHtml',
                'form_group_class' => 'link_support custom'
            ),
            'ETS_LC_DISPLAY_TIME' => array(
                'label' => $this->l('Display message time'),
                'type' => 'switch',
                'tab' => 'im',
                'default' => 1,
                'required' => true,
                'js' => 1,
                'validate' => 'isUnsignedInt',
            ),
            'ETS_LC_ENABLE_EDIT_MESSAGE' => array(
                'label' => $this->l('Enable edit message'),
                'type' => 'switch',
                'tab' => 'im',
                'default' => 1,
                'required' => true,
                'js' => 1,
                'validate' => 'isUnsignedInt',
            ),
            'ETS_LC_ENABLE_DELETE_MESSAGE' => array(
                'label' => $this->l('Enable delete message'),
                'type' => 'switch',
                'tab' => 'im',
                'default' => 1,
                'required' => true,
                'js' => 1,
                'validate' => 'isUnsignedInt',
            ),
            'ETS_LC_MSG_COUNT' => array(
                'label' => $this->l('Message count'),
                'type' => 'text',
                'tab' => 'im',
                'default' => 10,
                'required' => true,
                'validate' => 'isUnsignedInt',
                'desc' => $this->l('The number of message displayed per Ajax load'),
                'js' => 1,
            ),
            'ETS_LC_MSG_LENGTH' => array(
                'label' => $this->l('Message length'),
                'type' => 'text',
                'tab' => 'im',
                'default' => 500,
                'required' => true,
                'validate' => 'isUnsignedInt',
                'desc' => $this->l('Maximum message length counted by character'),
            ),
            'ETS_LC_ENTER_TO_SEND' => array(
                'label' => $this->l('Press Enter key to send message'),
                'type' => 'switch',
                'tab' => 'im',
                'default' => 1,
                'validate' => 'isUnsignedInt',
                'required' => true,
                'js' => 1,
            ),
            'ETS_LC_SEND_MESSAGE_TO_MAIL' => array(
                'label' => $this->l('Allow admin to send message to customer via email'),
                'type' => 'switch',
                'default' => 1,
                'tab' => 'im',
                'validate' => 'isUnsignedInt',
            ),
            'ETS_LC_CUSTOMER_OLD' => array(
                'label' => $this->l('Allow customer to see past messages'),
                'type' => 'switch',
                'default' => 1,
                'tab' => 'im',
                'validate' => 'isUnsignedInt',
            ),
            'ETS_LC_STAFF_ACCEPT' => array(
                'label' => $this->l('Staff to accept or decline chat'),
                'type' => 'switch',
                'default' => 1,
                'js' => 1,
                'tab' => 'im',
                'validate' => 'isUnsignedInt',
                'desc' => $this->l('Staffs need to manually accept or decline customer chat session'),
            ),
            'ETS_LC_SEND_FILE' => array(
                'label' => $this->l('Allow customer to upload file'),
                'type' => 'switch',
                'default' => 0,
                'js' => 1,
                'validate' => 'isUnsignedInt',
                'tab' => 'im',
            ),
            'ETS_LC_MAX_FILE_MS' => array(
                'label' => $this->l('Max upload file size'),
                'type' => 'text',
                'default' => Configuration::get('PS_ATTACHMENT_MAXIMUM_SIZE'),
                'js' => 1,
                'tab' => 'im',
                'validate' => 'isUnsignedInt',
                'suffix' => 'MB',
                'desc' => $this->l('Limited to both live chat and ticketing system. Leave this field blank to ignore this limitation'),
            ),
            'ETS_LC_NUMBER_FILE_MS' => array(
                'label' => $this->l('Maximum number of files that customer can upload per conversation'),
                'type' => 'text',
                'default' => 100,
                'js' => 1,
                'validate' => 'isUnsignedInt',
                'tab' => 'im',
                'desc' => $this->l('Leave this field blank to ignore this limitation'),
            ),
            'ETS_LC_UPDATE_CONTACT_INFO' => array(
                'label' => $this->l('Allow customer to update their contact'),
                'type' => 'switch',
                'default' => 1,
                'tab' => 'privacy',
                'validate' => 'isUnsignedInt',
                'required' => true,
                'js' => 1,
                'desc' => $this->l('Allow customer update their name, phone, email when the chat has been started'),
            ),
            'ETS_LC_DISPLAY_MESSAGE_STATUSES' => array(
                'label' => $this->l('Display message statuses'),
                'type' => 'checkbox',
                'tab' => 'privacy',
                'values' => array(
                    'query' => array(
                        array(
                            'id' => 'sent',
                            'label' => $this->l('Sent'),
                        ),
                        array(
                            'id' => 'delevered',
                            'label' => $this->l('Delivered'),
                        ),
                        array(
                            'id' => 'seen',
                            'label' => $this->l('Seen'),
                        ),
                        array(
                            'id' => 'writing',
                            'label' => $this->l('Writting'),
                        )
                    ),
                    'id' => 'id',
                    'name' => 'label',
                ),
                'validate' => 'isCleanHtml',
                'default' => 'sent,delevered,seen,writing'
            ),
            'ETS_LC_ALLOW_CLOSE' => array(
                'label' => $this->l('Allow customer to close chat box'),
                'type' => 'switch',
                'tab' => 'privacy',
                'default' => 0,
                'validate' => 'isUnsignedInt',
                'required' => true,
            ),
            'ETS_LC_ALLOW_MAXIMIZE' => array(
                'label' => $this->l('Allow customer to maximize/minimize chatbox'),
                'type' => 'switch',
                'tab' => 'privacy',
                'default' => 1,
                'validate' => 'isUnsignedInt',
                'required' => true,
            ),

            'ETS_LC_CHAT_FIELDS' => array(
                'label' => $this->l('Chat box fields'),
                'type' => 'checkbox',
                'tab' => 'fields',
                'default' => 'name,email,phone,text,departments',
                'values' => array(
                    'query' => array(
                        array(
                            'id' => 'name',
                            'label' => $this->l('Name'),
                        ),
                        array(
                            'id' => 'email',
                            'label' => $this->l('Email'),
                        ),
                        array(
                            'id' => 'phone',
                            'label' => $this->l('Phone'),
                        ),
                        array(
                            'id' => 'departments',
                            'label' => $this->l('Departments'),
                        ),
                        array(
                            'id' => 'message',
                            'label' => $this->l('Message'),
                        ),
                    ),
                    'id' => 'id',
                    'name' => 'label',
                ),
                'validate' => 'isCleanHtml',
                'desc' => $this->l('Email is always required when offline. Message is required field. Name, email and phone are auto filled in if customer is logged in'),
            ),
            'ETS_LC_CHAT_FIELDS_REQUIRED' => array(
                'label' => $this->l('Required fields'),
                'type' => 'checkbox',
                'tab' => 'fields',
                'default' => 'name,email,phone,text,departments',
                'values' => array(
                    'query' => array(
                        array(
                            'id' => 'name',
                            'label' => $this->l('Name'),
                        ),
                        array(
                            'id' => 'email',
                            'label' => $this->l('Email'),
                        ),
                        array(
                            'id' => 'phone',
                            'label' => $this->l('Phone'),
                        ),
                        array(
                            'id' => 'departments',
                            'label' => $this->l('Departments'),
                        ),
                        array(
                            'id' => 'message',
                            'label' => $this->l('Message'),
                        ),
                    ),
                    'id' => 'id',
                    'name' => 'label',
                ),
                'validate' => 'isCleanHtml',
                'desc' => $this->l('Fields that don\'t accept empty value'),
            ),
            'ETS_LC_SEND_PRODUCT_LINK' => array(
                'label' => $this->l('Send product link'),
                'type' => 'switch',
                'tab' => 'fields',
                'default' => 1,
                'validate' => 'isInt',
                'desc' => $this->l('Allow customers to send product link when customers start chatting at the product detail page')
            ),
            'ETS_LC_PRODUCT_LINK_REQUIRE' => array(
                'label' => $this->l('Require product link'),
                'type' => 'switch',
                'tab' => 'fields',
                'default' => 0,
                'desc' => $this->l('Product link will always be sent when start chatting'),
                'form_group_class' => 'send_product_link',
                'validate' => 'isInt',
            ),
            'ETS_LC_PRODUCT_NAME_COLOR' => array(
                'label' => $this->l('Product name color'),
                'type' => 'color',
                'tab' => 'fields',
                'default' => '#2fb5d2',
                'form_group_class' => 'send_product_link',
                'validate' => 'isColor',
            ),
            'ETS_LC_PRODUCT_PRICE_COLOR' => array(
                'label' => $this->l('Product price color'),
                'type' => 'color',
                'tab' => 'fields',
                'default' => '#f39d72',
                'form_group_class' => 'send_product_link',
                'validate' => 'isColor',
            ),
            'ETS_LC_SEND_MAIL_WHEN_SEND_MG' => array(
                'label' => $this->l('Send email to admin when offline'),
                'type' => 'switch',
                'tab' => 'email',
                'default' => 1,
                'validate' => 'isInt',
            ),
            'ETS_LC_MAIL_TO' => array(
                'label' => $this->l('Mail to'),
                'type' => 'checkbox',
                'tab' => 'email',
                'default' => 'shop,employee',
                'values' => array(
                    'query' => array(
                        array(
                            'id' => 'shop',
                            'label' => $this->l('Shop email'),
                        ),
                        array(
                            'id' => 'employee',
                            'label' => $this->l('All employees'),
                        ),
                        array(
                            'id' => 'custom',
                            'label' => $this->l('Custom emails'),
                        ),
                    ),
                    'id' => 'id',
                    'name' => 'label',
                ),
                'validate' => 'isCleanHtml',
                'form_group_class' => 'lc_send_mail'
            ),
            'ETS_LC_CUSTOM_EMAIL' => array(
                'label' => $this->l('Custom emails'),
                'type' => 'text',
                'tab' => 'email',
                'form_group_class' => 'customer_emails lc_send_mail',
                'desc' => $this->l('Email addresses are separated by a comma'),
                'validate' => 'isCleanHtml',
            ),
            'ETS_LC_SEND_MAIL' => array(
                'label' => 'Mail when',
                'type' => 'checkbox',
                'tab' => 'email',
                'default' => 'first_message',
                'values' => array(
                    'query' => array(
                        array(
                            'id' => 'first_message',
                            'label' => $this->l('Send notification email to admin when customer sends the first message'),
                        ),
                        array(
                            'id' => 'affter_a_centaint_time',
                            'label' => $this->l('Send notification email to admin if customer sends a message after a certain time since admin is offline'),
                        ),
                    ),
                    'id' => 'id',
                    'name' => 'label',
                ),
                'validate' => 'isCleanHtml',
                'form_group_class' => 'lc_send_mail',
            ),
            'ETS_CENTAINT_TIME_SEND_EMAIL' => array(
                'type' => 'text',
                'label' => $this->l('Time'),
                'default' => 1,
                'validate' => 'isUnsignedFloat',
                'js' => 1,
                'suffix' => $this->l('Hours'),
                'tab' => 'email',
                'form_group_class' => 'time_send_email lc_send_mail'
            ),
            'ETS_DIRECTORY_ADMIN_URL' => array(
                'type' => 'text',
                'label' => $this->l('Admin directory'),
                'tab' => 'email',
                'desc' => Tools::getShopDomainSsl(true) . Context::getContext()->shop->getBaseURI() . '[admin-directory]',
                'form_group_class' => 'lc_send_mail',
                'default' => $admin_dir,
                'validate' => 'isCleanHtml',
            ),
            'ETS_LC_CAPTCHA' => array(
                'label' => $this->l('Require CAPTCHA when'),
                'type' => 'checkbox',
                'tab' => 'security',
                'form_group_class' => 'captcha',
                'default' => 'auto',
                'validate' => 'isCleanHtml',
                'values' => array(
                    'query' => array(
                        array(
                            'id' => 'auto',
                            'label' => $this->l('Auto enable Captcha when detect spams'),
                        ),
                        array(
                            'id' => 'first',
                            'label' => $this->l('When customer sends the first message'),
                        ),
                        array(
                            'id' => 'fromsecond',
                            'label' => $this->l('From the second message when no employee is online'),
                        ),
                        array(
                            'id' => 'secondnotlogin',
                            'label' => $this->l('From the second message when customer is not logged in'),
                        ),
                        array(
                            'id' => 'notlog',
                            'label' => $this->l('Always if customer is not logged in'),
                        ),
                        array(
                            'id' => 'always',
                            'label' => $this->l('Always (everytime customer sends a message)'),
                        ),
                    ),
                    'id' => 'id',
                    'name' => 'label',
                ),
                'desc' => $this->l('Avoid spam messages, avoid server overload'),
            ),
            'ETS_LC_CAPTCHA_TYPE' => array(
                'label' => $this->l('Captcha image type'),
                'type' => 'select',
                'tab' => 'security',
                'validate' => 'isCleanHtml',
                'options' => array(
                    'query' => array(
                        array(
                            'id_option' => 'colorful',
                            'name' => $this->l('Colorful'),
                        ),
                        array(
                            'id_option' => 'basic',
                            'name' => $this->l('Basic'),
                        ),
                        array(
                            'id_option' => 'complex',
                            'name' => $this->l('Complex'),
                        ),
                    ),
                    'id' => 'id_option',
                    'name' => 'name'
                ),
                'default' => 'colorful',
            ),
            'ETS_LC_AUTO_OPEN' => array(
                'label' => $this->l('Auto open chat box'),
                'type' => 'switch',
                'tab' => 'timing',
                'default' => 0,
                'validate' => 'isUnsignedInt',
                'required' => true,
                'js' => 1,
            ),
            'ETS_LC_AUTO_OPEN_CHATBOX_DELAY' => array(
                'label' => $this->l('Delay time to open chat box'),
                'type' => 'text',
                'tab' => 'timing',
                'validate' => 'isUnsignedInt',
                'desc' => $this->l('Delay time to automatically open chat box. Leave blank to open chat box immediately when customer lands on website'),
                'js' => 1,
                'suffix' => $this->l('second(s)'),
                'default' => 10,
                'form_group_class' => 'lc_auto_open'
            ),
            'ETS_LC_AUTO_OPEN_ONLINE_ONLY' => array(
                'label' => $this->l('Only auto open chat box when administrator is online'),
                'type' => 'switch',
                'tab' => 'timing',
                'default' => 1,
                'validate' => 'isUnsignedInt',
                'required' => true,
                'js' => 1,
                'form_group_class' => 'lc_auto_open',
            ),
            'ETS_LC_TIME_OUT' => array(
                'label' => $this->l('Refresh speed of frontend'),
                'type' => 'text',
                'tab' => 'timing',
                'default' => 3000,
                'validate' => 'isUnsignedInt',
                'required' => true,
                'js' => 1,
                'suffix' => $this->l('ms'),
                'desc' => $this->l('3000 ms is recommended. Increase this value can reduce your server load but it will slow down the communication speed'),
            ),
            'ETS_LC_AUTO_FRONTEND_SPEED' => array(
                'label' => $this->l('Auto optimize frontend refresh speed'),
                'type' => 'switch',
                'tab' => 'timing',
                'default' => 1,
                'validate' => 'isUnsignedInt',
                'required' => true,
                'js' => 1,
            ),
            'ETS_LC_TIME_OUT_BACK_END' => array(
                'label' => $this->l('Refresh speed of backend'),
                'type' => 'text',
                'tab' => 'timing',
                'default' => 3000,
                'validate' => 'isUnsignedInt',
                'required' => true,
                'js' => 1,
                'suffix' => $this->l('ms'),
                'desc' => $this->l('3000 ms is recommended. Increase this value can reduce your server load but it will slow down the communication speed'),
            ),
            'ETS_LC_AUTO_BACKEND_SPEED' => array(
                'label' => $this->l('Auto optimize backend refresh speed'),
                'type' => 'switch',
                'tab' => 'timing',
                'default' => 1,
                'validate' => 'isUnsignedInt',
                'required' => true,
                'js' => 1,
            ),
            'ETS_LC_ONLINE_TIMEOUT' => array(
                'label' => $this->l('Automatically pause customer chat if they\'re not active in'),
                'type' => 'text',
                'tab' => 'timing',
                'default' => 10,
                'validate' => 'isUnsignedFloat',
                'required' => true,
                'js' => 1,
                'suffix' => $this->l('minute(s)'),
            ),
            'ETS_LC_ENDCHAT_AUTO' => array(
                'label' => $this->l('End chat automatically if there is no new messages in'),
                'type' => 'text',
                'default' => 60,
                'tab' => 'timing',
                'js' => 1,
                'validate' => 'isUnsignedInt',
                'suffix' => $this->l('minute(s)'),
                'desc' => $this->l('You can leave this field blank'),
            ),
            'ETS_LC_TIME_WAIT' => array(
                'label' => $this->l('Estimated waiting time'),
                'type' => 'text',
                'default' => 5,
                'tab' => 'timing',
                'js' => 1,
                'validate' => 'isUnsignedInt',
                'suffix' => $this->l('minute(s)'),
                'desc' => $this->l('You can leave this field blank'),
            ),
            'ETS_LC_MISC' => array(
                'label' => $this->l('Display chatbox on those pages only'),
                'type' => 'select',
                'validate' => 'isCleanHtml',
                'options' => array(
                    'query' => array(
                        array(
                            'id_option' => 'all',
                            'name' => $this->l('All'),
                        ),
                        array(
                            'id_option' => 'index',
                            'name' => $this->l('Home'),
                        ),
                        array(
                            'id_option' => 'category',
                            'name' => $this->l('Category'),
                        ),
                        array(
                            'id_option' => 'product',
                            'name' => $this->l('Product'),
                        ),
                        array(
                            'id_option' => 'cms',
                            'name' => $this->l('CMS'),
                        ),
                        array(
                            'id_option' => 'other',
                            'name' => $this->l('Other pages'),
                        ),
                    ),
                    'id' => 'id_option',
                    'name' => 'name'
                ),
                'default' => 'all',
                'multiple' => true,
                'tab' => 'display',
                'form_group_class' => 'page_display_chatbox'
            ),
            'ETS_LC_CUSTOMER_GROUP' => array(
                'label' => $this->l('Customer group'),
                'type' => 'select',
                'options' => array(
                    'query' => $customerGroups,
                    'id' => 'id_option',
                    'name' => 'name'
                ),
                'default' => 'all',
                'multiple' => true,
                'tab' => 'display',
                'validate' => 'isCleanHtml',
                'desc' => $this->l('Select customer group who can use live chat feature')
            ),
            'ETS_CONVERSATION_LIST_TYPE' => array(
                'type' => 'select',
                'label' => $this->l('Conversation list type'),
                'options' => array(
                    'query' => array(
                        array(
                            'id_option' => 'floating',
                            'name' => $this->l('Fixed'),
                        ),
                        array(
                            'id_option' => 'fixed',
                            'name' => $this->l('Floating'),
                        ),
                    ),
                    'id' => 'id_option',
                    'name' => 'name'
                ),
                'validate' => 'isCleanHtml',
                'default' => 'floating',
                'tab' => 'display',
            ),
            'ETS_DISPLAY_DASHBOARD_ONLY' => array(
                'label' => $this->l('Display chat on backend dashboard only'),
                'type' => 'switch',
                'default' => 0,
                'tab' => 'display',
                'validate' => 'isInt',
            ),
            'ETS_LV_SUPPORT_TICKET' => array(
                'label' => $this->l('Display support links block on'),
                'type' => 'checkbox',
                'tab' => 'display',
                'values' => array(
                    'query' => array(
                        array(
                            'id' => 'left',
                            'label' => $this->l('Left sidebar'),
                        ),
                        array(
                            'id' => 'right',
                            'label' => $this->l('Right sidebar'),
                        ),
                        array(
                            'id' => 'footer',
                            'label' => $this->l('Footer'),
                        ),
                        array(
                            'id' => 'top_nav',
                            'label' => $this->l('Top navigation'),
                        ),
                        array(
                            'id' => 'custom_hook',
                            'label' => $this->l('Custom hook'),
                        )
                    ),
                    'id' => 'id',
                    'name' => 'label',
                ),
                'default' => 'footer',
                'validate' => 'isCleanHtml',
                'desc' => $this->l('To use "custom hook", put') . Module::getInstanceByName('ets_livechat')->displayText('{hook h="customBlockSupport"}', 'span', 'lighhight_hook') . $this->l('on tpl file where you want to display support links block.'),
            ),
            'ETS_BLACK_LIST_IP' => array(
                'type' => 'textarea',
                'label' => $this->l('IP black list'),
                'tab' => 'back_list_ip',
                'validate' => 'isCleanHtml',
                'desc' => $this->l('This is the list of IP addresses you want to block their requests to chat. Please enter each IP in a line'),
            ),
            'ETS_SOUND_WHEN_NEW_MESSAGE' => array(
                'type' => 'select',
                'label' => $this->l('Notification sound type'),
                'options' => array(
                    'query' => array(
                        array(
                            'id_option' => 'sound1',
                            'name' => $this->l('Sound 1'),
                        ),
                        array(
                            'id_option' => 'sound2',
                            'name' => $this->l('Sound 2'),
                        ),
                        array(
                            'id_option' => 'sound3',
                            'name' => $this->l('Sound 3'),
                        ),
                        array(
                            'id_option' => 'sound4',
                            'name' => $this->l('Sound 4'),
                        ),
                        array(
                            'id_option' => 'sound5',
                            'name' => $this->l('Sound 5'),
                        ),
                        array(
                            'id_option' => 'sound6',
                            'name' => $this->l('Sound 6'),
                        ),
                        array(
                            'id_option' => 'sound7',
                            'name' => $this->l('Sound 7'),
                        ),
                        array(
                            'id_option' => 'sound8',
                            'name' => $this->l('Sound 8'),
                        ),
                    ),
                    'id' => 'id_option',
                    'name' => 'name'
                ),
                'validate' => 'isCleanHtml',
                'default' => 'sound1',
                'tab' => 'sound',
            ),
            'ETS_LC_USE_SOUND_BACKEND' => array(
                'label' => $this->l('Enable notification sound on backend'),
                'type' => 'switch',
                'default' => 1,
                'tab' => 'sound',
                'js' => 1,
                'validate' => 'isInt',
            ),
            'ETS_LC_USE_SOUND_FONTEND' => array(
                'label' => $this->l('Enable notification sound on frontend'),
                'type' => 'switch',
                'default' => 1,
                'js' => 1,
                'tab' => 'sound',
                'validate' => 'isInt',
            ),
            'ETS_TAB_CURENT_ACTIVE' => array(
                'label' => '',
                'type' => 'hidden',
                'tab' => 'sound',
                'validate' => 'isCleanHtml',
            ),
            'ETS_ENABLE_PRE_MADE_MESSAGE' => array(
                'label' => $this->l('Enable pre-made message'),
                'type' => 'switch',
                'default' => 0,
                'js' => 1,
                'tab' => 'pre_made_message',
                'validate' => 'isInt',
            ),
            'ETS_LIVECHAT_ADMIN_DE' => array(
                'label' => $this->l('Allow staffs to transfer their conversation to another department'),
                'type' => 'switch',
                'default' => 1,
                'js' => 1,
                'tab' => 'departments',
                'validate' => 'isInt',
            ),
            'ETS_LIVECHAT_ADMIN_OLD' => array(
                'label' => $this->l('Allow staffs to see past messages from customer'),
                'type' => 'switch',
                'default' => 1,
                'js' => 1,
                'tab' => 'departments',
                'validate' => 'isInt',
            ),
            'ETS_ENABLE_AUTO_REPLY' => array(
                'label' => $this->l('Enable auto reply'),
                'type' => 'switch',
                'default' => 0,
                'js' => 1,
                'tab' => 'auto_reply',
                'validate' => 'isInt',
            ),
            'ETS_FORCE_ONLINE_AUTO_REPLY' => array(
                'label' => $this->l('Only send auto message when Force online is enabled'),
                'type' => 'switch',
                'default' => 1,
                'tab' => 'auto_reply',
                'form_group_class' => 'form_auto_reply_stop',
                'validate' => 'isInt',
            ),
            'ETS_STOP_AUTO_REPLY' => array(
                'label' => $this->l('Stop auto replying if admin has manually replied to a customer message'),
                'type' => 'switch',
                'default' => 1,
                'tab' => 'auto_reply',
                'form_group_class' => 'form_auto_reply_stop',
                'validate' => 'isInt',
            ),
            'ETS_LIVECHAT_ENABLE_FACEBOOK' => array(
                'label' => $this->l('Log in with Facebook'),
                'type' => 'switch',
                'default' => 0,
                'tab' => 'sosial',
                'validate' => 'isInt',
            ),
            'ETS_LIVECHAT_FACEBOOK_APP_ID' => array(
                'label' => $this->l('Facebook Application ID'),
                'type' => 'text',
                'tab' => 'sosial',
                'form_group_class' => 'login_facebook',
                'required' => 1,
                'validate' => 'isCleanHtml',
                'desc' => Module::getInstanceByName('ets_livechat')->displayText($this->l('Where do I get this info?'), 'a', '', array('target' => '_blank', 'href' => Module::getInstanceByName('ets_livechat')->getBaseLink() . '/modules/ets_livechat/views/document/How_to_get_Facebook_App_info.pdf')),
            ),
            'ETS_LIVECHAT_FACEBOOK_APP_SECRET' => array(
                'label' => $this->l('Facebook Application Secret'),
                'type' => 'text',
                'tab' => 'sosial',
                'form_group_class' => 'login_facebook',
                'required' => 1,
                'validate' => 'isCleanHtml',
                'desc' => Module::getInstanceByName('ets_livechat')->displayText($this->l('Where do I get this info?'), 'a', '', array('target' => '_blank', 'href' => Module::getInstanceByName('ets_livechat')->getBaseLink() . '/modules/ets_livechat/views/document/How_to_get_Facebook_App_info.pdf')),
            ),
            'ETS_LIVECHAT_ENABLE_GOOGLE' => array(
                'label' => $this->l('Log in with Google'),
                'type' => 'switch',
                'default' => 0,
                'tab' => 'sosial',
                'validate' => 'isInt',
            ),
            'ETS_LIVECHAT_GOOGLE_APP_ID' => array(
                'label' => $this->l('Google Application ID'),
                'type' => 'text',
                'tab' => 'sosial',
                'form_group_class' => 'login_google',
                'required' => 1,
                'validate' => 'isCleanHtml',
                'desc' => Module::getInstanceByName('ets_livechat')->displayText($this->l('Where do I get this info?'), 'a', '', array('target' => '_blank', 'href' => Module::getInstanceByName('ets_livechat')->getBaseLink() . '/modules/ets_livechat/views/document/How_to_get_Google_App_info.pdf')),
            ),
            'ETS_LIVECHAT_GOOGLE_APP_SECRET' => array(
                'label' => $this->l('Google Application Secret'),
                'type' => 'text',
                'tab' => 'sosial',
                'form_group_class' => 'login_google',
                'required' => 1,
                'validate' => 'isCleanHtml',
                'desc' => Module::getInstanceByName('ets_livechat')->displayText($this->l('Where do I get this info?'), 'a', '', array('target' => '_blank', 'href' => Module::getInstanceByName('ets_livechat')->getBaseLink() . '/modules/ets_livechat/views/document/How_to_get_Google_App_info.pdf')),
            ),
            'ETS_LIVECHAT_ENABLE_TWITTER' => array(
                'label' => $this->l('Log in with X'),
                'type' => 'switch',
                'default' => 0,
                'tab' => 'sosial',
                'validate' => 'isInt',
            ),
            'ETS_LIVECHAT_TWITTER_APP_ID' => array(
                'label' => $this->l('X Application ID'),
                'type' => 'text',
                'tab' => 'sosial',
                'form_group_class' => 'login_twitter',
                'required' => 1,
                'validate' => 'isCleanHtml',
                'desc' => Module::getInstanceByName('ets_livechat')->displayText($this->l('Where do I get this info?'), 'a', '', array('target' => '_blank', 'href' => Module::getInstanceByName('ets_livechat')->getBaseLink() . '/modules/ets_livechat/views/document/How_to_get_Twitter_App_info.pdf')),
            ),
            'ETS_LIVECHAT_TWITTER_APP_SECRET' => array(
                'label' => $this->l('X Application Secret'),
                'type' => 'text',
                'tab' => 'sosial',
                'form_group_class' => 'login_twitter',
                'required' => 1,
                'validate' => 'isCleanHtml',
                'desc' => Module::getInstanceByName('ets_livechat')->displayText($this->l('Where do I get this info?'), 'a', '', array('target' => '_blank', 'href' => Module::getInstanceByName('ets_livechat')->getBaseLink() . '/modules/ets_livechat/views/document/How_to_get_Twitter_App_info.pdf')),
            ),
        );
        return self::$configs;
    }
    public static function installDb(){
        $res = Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ets_livechat_auto_msg` (
              `id_auto_msg` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
              `message_order` int(11) NOT NULL,
              `auto_content` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
              INDEX(message_order)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8');
        $res &= Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'ets_livechat_auto_msg_lang` (
            `id_auto_msg` INT(11) NOT NULL , 
            `id_lang` INT(11) NOT NULL , 
            `auto_content` TEXT NOT NULL , 
            PRIMARY KEY (`id_auto_msg`, `id_lang`)) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8');
        $res &= Db::getInstance()->execute("CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "ets_livechat_conversation` (
              `id_conversation` int(10) AUTO_INCREMENT PRIMARY KEY ,
              `id_customer` int(11) NOT NULL DEFAULT '0',
              `id_lang` int(11),
              `id_ticket` int(11) NOT NULL DEFAULT '0',
              `id_shop` INT(11) NOT NULL,
              `blocked` tinyint(4) NOT NULL DEFAULT '0',
              `archive` int(1) NOT NULL,
              `customer_writing` tinyint(1) NOT NULL DEFAULT '0',
              `employee_writing` tinyint(1) NOT NULL DEFAULT '0',
              `date_message_seen_customer` datetime DEFAULT NULL,
              `date_message_seen_employee` datetime DEFAULT NULL,
              `captcha_enabled` tinyint(1) NOT NULL DEFAULT '0',
              `customer_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
              `customer_email` varchar(255) NOT NULL,
              `customer_phone` varchar(255) NOT NULL,
              `latest_online` datetime DEFAULT NULL,
              `latest_ip` varchar(255) DEFAULT NULL,
              `browser_name` varchar(222) NOT NULL,
              `id_departments` int(11) NOT NULL,
              `id_departments_wait` int(11) NOT NULL,
              `id_employee` int(11) NOT NULL,
              `id_employee_wait` int(11) NOT NULL,
              `id_tranfer` int(11) NOT NULL,
              `date_accept` datetime DEFAULT NULL,
              `datetime_added` datetime DEFAULT NULL,
              `date_message_writing_employee` datetime NOT NULL,
              `date_message_writing_customer` datetime NOT NULL,
              `date_message_delivered_employee` datetime NOT NULL,
              `date_message_delivered_customer` datetime NOT NULL,
              `date_message_last` datetime NOT NULL,
              `date_message_last_customer` datetime NOT NULL,
              `date_mail_last` datetime NOT NULL,
              `rating` int(1) NOT NULL,
              `end_chat` INT(11),
              `message_deleted` text,
              `message_edited` text,
              `employee_message_deleted` text,
              `employee_message_edited` text,
              `replied` INT(1), 
              `current_url` VARCHAR(1000) NOT NULL,
              `http_referer` VARCHAR(1000) NOT NULL,
              `enable_sound` int(1) NOT NULL DEFAULT '1',
              `note` text,
              `chatref` INT(11),
              INDEX (`id_customer`),INDEX (`id_ticket`),INDEX (`id_shop`),INDEX (`blocked`),INDEX (`archive`),INDEX (`customer_writing`),INDEX (`employee_writing`),INDEX (`captcha_enabled`),INDEX (`id_departments`),INDEX (`id_departments_wait`)
              ,INDEX (`id_employee`),INDEX (`id_employee_wait`),INDEX (`id_tranfer`),INDEX (`rating`),INDEX (`replied`),INDEX (`enable_sound`),INDEX (`chatref`)
            ) ENGINE=" . _MYSQL_ENGINE_ . " DEFAULT CHARSET=UTF8");
        $res &= Db::getInstance()->execute("CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "ets_livechat_ip_address` (
            `ip_address` varchar(222) NOT NULL,
            `latitude` varchar(222) NOT NULL,
            `longitude` varchar(222) NOT NULL
            ) ENGINE=" . _MYSQL_ENGINE_ . " DEFAULT CHARSET=UTF8");
        $res &= Db::getInstance()->execute("CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "ets_livechat_message` (
          `id_message` int(11) AUTO_INCREMENT PRIMARY KEY ,
          `id_conversation` int(11) unsigned NOT NULL,
          `id_employee` int(10) NOT NULL,
          `id_product` int(10) NOT NULL,
          `message` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
          `type_attachment` VARCHAR(222) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
          `name_attachment` VARCHAR(222) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
          `delivered` tinyint(1) NOT NULL DEFAULT '0',
          `datetime_added` datetime DEFAULT NULL,
          `datetime_edited` datetime DEFAULT NULL,
          INDEX(id_conversation),INDEX(id_employee),INDEX(id_product),INDEX(delivered)
        ) ENGINE=" . _MYSQL_ENGINE_ . " DEFAULT CHARSET=UTF8");
        $res &= Db::getInstance()->execute("CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "ets_livechat_download` (
          `id_download` int(11) AUTO_INCREMENT PRIMARY KEY ,
          `id_message` int(11) unsigned NOT NULL,
          `id_ticket` int(11),
          `id_field` int(11), 
          `id_note` int(11),
          `id_conversation` int(11) unsigned NOT NULL,
          `file_type` VARCHAR(222) NOT NULL,
          `file_size` FLOAT(11,2) NOT NULL,
          `filename` VARCHAR(222) CHARACTER SET utf8 COLLATE utf8_bin,
          `name` VARCHAR(222) CHARACTER SET utf8 COLLATE utf8_bin
          ,INDEX(id_message),INDEX(id_ticket),INDEX(id_field),INDEX(id_note),INDEX(id_conversation)
        ) ENGINE=" . _MYSQL_ENGINE_ . " DEFAULT CHARSET=UTF8");
        $res &= Db::getInstance()->execute("CREATE TABLE IF NOT EXISTS `" . _DB_PREFIX_ . "ets_livechat_pre_made_message` (
          `id_pre_made_message` int(11) AUTO_INCREMENT PRIMARY KEY ,
          `title_message` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
          `message_content` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
          `short_code` varchar(500) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
          `position` int(11) NOT NULL,
          INDEX(position)
        ) ENGINE=" . _MYSQL_ENGINE_ . " DEFAULT CHARSET=UTF8");
        $res &= Db::getInstance()->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ets_livechat_departments` ( 
            `id_departments` INT(11) NOT NULL AUTO_INCREMENT , 
            `name` VARCHAR(222) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL , 
            `description` TEXT CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, 
            `all_employees` INT(11) NOT NULL,
            `sort_order` INT(11),
            `status` INT(1) NOT NULL , PRIMARY KEY (`id_departments`)
             ,INDEX(all_employees) ,INDEX(sort_order) ,INDEX(status)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8');
        $res &= Db::getInstance()->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ets_livechat_departments_employee` ( 
            `id_departments` INT(11) NOT NULL , 
            `id_employee` INT(11) NOT NULL
             ,PRIMARY KEY(id_departments,id_employee) ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8');
        $res &= Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ets_livechat_employee_online`( 
            `id_employee` INT(11) NOT NULL ,
            `id_shop` INT(11) NOT NULL ,
            `date_online` DATETIME NOT NULL
             ,PRIMARY KEY(id_employee,id_shop)) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8');
        $res &= Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ets_livechat_url` (
        `id_conversation` INT(11),
        `url` VARCHAR(1000) NOT NULL , 
        `date_add` DATETIME NOT NULL
        ,PRIMARY KEY(id_conversation) ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8');
        $res &= Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ets_livechat_staff` ( 
        `id_employee` INT(11) NOT NULL , 
        `name` VARCHAR(222) NOT NULL , 
        `avata` VARCHAR(222) NOT NULL , 
        `signature` text NOT NULL , 
        `status` INT(1) NOT NULL
        ,PRIMARY KEY (`id_employee`),INDEX(status)) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8');
        $res &= Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ets_livechat_staff_decline` ( 
        `id_employee` INT(11) NOT NULL , 
        `id_conversation` INT(11) NOT NULL
        ,PRIMARY KEY(id_employee,id_conversation) ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8');
        $res &= Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ets_livechat_employee_status` ( 
            `id_employee` INT(11) NOT NULL ,
            `id_shop` INT(11) NOT NULL ,
            `status` VARCHAR (222) NOT NULL
            ,PRIMARY KEY(id_employee,id_shop) ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8');
        $res &= Db::getInstance()->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ets_livechat_ticket_form` ( 
            `id_form` INT(11) NOT NULL AUTO_INCREMENT ,
            `active` INT(1),
            `id_shop` INT(11),
            `mail_new_ticket` VARCHAR(222),
            `custom_mail` VARCHAR(222),
            `send_mail_to_customer` INT(1),
            `send_mail_reply_customer` INT(1),
            `send_mail_reply_admin` INT(1),
            `send_from_email` VARCHAR(222),
            `send_from_name` VARCHAR(222),
            `customer_reply_upload_file` INT(1),
            `allow_user_submit` INT(1),
            `allow_staff_upload_file` INT(11),
            `send_mail_to_customer_customer_reply` INT(11),
            `send_mail_to_admin_admin_reply` INT(11),
            `save_customer_file` INT(1),
            `save_staff_file` INT(1),
            `require_select_department` INT(1),
            `departments` VARCHAR(222),
            `allow_captcha` INT(11),
            `captcha_type` VARCHAR(222),
            `google2_site_key` VARCHAR(222), 
            `google2_secret_key` VARCHAR(222), 
            `google3_site_key` VARCHAR(222), 
            `google3_secret_key` VARCHAR(222),     
            `customer_no_captcha` INT(1),
            `deleted` INT(11), 
            `sort_order` INT(11),
            `default_priority` INT(2),
            `display_input_product` INT(1),
            `display_input_order` INT(1),
            PRIMARY KEY (`id_form`)
            ,INDEX(active),INDEX(id_shop),INDEX(send_mail_to_customer),INDEX(send_mail_reply_customer),INDEX(send_mail_reply_admin),INDEX(customer_reply_upload_file),INDEX(allow_user_submit),INDEX(save_customer_file),INDEX(save_staff_file),INDEX(require_select_department)
            ,INDEX(allow_captcha),INDEX(customer_no_captcha),INDEX(deleted),INDEX(sort_order),INDEX(default_priority)) ENGINE = ' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8
        ');

        $res &= Db::getInstance()->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_field` ( 
            `id_field` INT(11) NOT NULL AUTO_INCREMENT ,
            `id_form` INT(11), 
            `type` VARCHAR(222),
            `is_contact_mail` INT(1),
            `is_contact_name` INT (1),  
            `is_subject` INT(1),
            `is_customer_phone_number` INT(1),
            `required` INT (1),
            `deleted` INT (1),
            `position` INT (11),     
            PRIMARY KEY (`id_field`)
            ,INDEX(id_form),INDEX(is_contact_mail),INDEX(is_customer_phone_number),INDEX(is_contact_name),INDEX(is_subject),INDEX(required),INDEX(deleted),INDEX(position)) ENGINE = ' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8
        ');

        $res &= Db::getInstance()->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_lang` ( 
            `id_form` INT(11),
            `id_lang` INT (11),
            `title` VARCHAR(222) NOT NULL , 
            `button_submit_label` VARCHAR(222) NOT NULL , 
            `button_link_contact_label` VARCHAR(222) NULL ,
            `button_link_contact_label_on_order_page` VARCHAR(255) NULL ,
            `description` TEXT NOT NULL , 
            `friendly_url` VARCHAR(222) NOT NULL , 
            `meta_title` VARCHAR(222) NOT NULL , 
            `meta_description` TEXT NOT NULL , 
            `meta_keywords` TEXT NOT NULL,
            PRIMARY KEY (`id_form`,`id_lang`)) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8
        ');
        $res &= Db::getInstance()->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_field_lang` ( 
            `id_field` INT(11),
            `id_lang` INT (11),
            `label` VARCHAR (222),
            `placeholder` TEXT NOT NULL,
            `description` TEXT NOT NULL,
            `options` VARCHAR(222) NOT NULL,
            PRIMARY KEY (`id_field`,`id_lang`)) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8
        ');
        $res &= Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS`' . _DB_PREFIX_ . 'ets_livechat_customer_info` ( 
            `id_customer` INT(11) NOT NULL , 
            `avata` VARCHAR(222) NOT NULL ,
            `signature` text NOT NULL ,
            PRIMARY KEY (`id_customer`)) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8');
        $res &= Db::getInstance()->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message` ( 
                `id_message` INT(11) NOT NULL AUTO_INCREMENT , 
                `id_form` INT(11) NOT NULL , 
                `id_shop` INT(11) NOT NULL ,
                `id_lang` INT(11) DEFAULT 0 ,
                `id_departments` INT(11),
                `id_customer` INT(11) NOT NULL , 
                `employee` tinyint(1) NOT NULL DEFAULT \'0\',
                `id_product` INT(11) NOT NULL ,
                `id_order` INT(11),
                `status` VARCHAR(22),
                `send_email_customer` VARCHAR(22),
                `send_email_admin` VARCHAR(22),
                `priority` INT(2),
                `rate` INT(11),
                `readed` INT(1),
                `replied` INT(1),
                `id_employee` INT(11),
                `customer_readed` INT(1),
                `subject` text,
                `date_customer_update` DATETIME NOT NULL ,
                `date_admin_update` DATETIME NOT NULL,
                `date_add` DATETIME NOT NULL, 
                PRIMARY KEY (`id_message`),INDEX(id_form),INDEX(id_shop),INDEX(id_departments),INDEX(id_customer),INDEX(id_product),INDEX(id_order),INDEX(priority),INDEX(readed),INDEX(replied),INDEX(id_employee),INDEX(customer_readed)
            ) ENGINE = ' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8
        ');

        $res &= Db::getInstance()->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_field` ( 
            `id_message` INT(11) NOT NULL , 
            `id_field` INT(11) NOT NULL , 
            `id_download` INT(11),
            `value` TEXT NOT NULL ,
             PRIMARY KEY (`id_message`,id_field,id_download)
            ) ENGINE = ' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8
        ');

        $res &= Db::getInstance()->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note` ( 
                `id_note` INT(11) NOT NULL AUTO_INCREMENT , 
                `id_message` INT(11) NOT NULL , 
                `id_employee` INT(11) NOT NULL,
                `id_customer` INT(11) NOT NULL,
                `employee` tinyint(1) NOT NULL DEFAULT \'0\',
                `id_download` INT(11),
                `note` text,
                `note_origin` text,
                `send_email_customer` VARCHAR(22),
                `send_email_admin` VARCHAR(22),
                `readed` INT(1),
                `file_name` text,
                `date_add` DATETIME NOT NULL, 
                PRIMARY KEY (`id_note`),INDEX(id_message),INDEX(id_employee),INDEX(id_customer),INDEX(readed),INDEX(id_download)
            ) ENGINE = ' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8
        ');

        $res &= Db::getInstance()->execute('
            CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'ets_livechat_social_login` ( 
                `id_social_login` INT(11) NOT NULL AUTO_INCREMENT , 
                `id_customer` INT(11) NOT NULL , 
                `social` VARCHAR(22) NOT NULL,
                `date_login` DATETIME NOT NULL , 
                PRIMARY KEY (`id_social_login`),INDEX(id_customer)
            ) ENGINE = ' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8
        ');
        $res &= Db::getInstance()->execute('CREATE TABLE IF NOT EXISTS`' . _DB_PREFIX_ . 'ets_livechat_social_customer`( 
        `identifier` VARCHAR(222) NOT NULL , 
        `email` VARCHAR(222) NOT NULL,
        PRIMARY KEY ( `identifier`, `email`) ) ENGINE = ' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=UTF8');
        $shops = Db::getInstance()->executeS("SELECT * FROM `" . _DB_PREFIX_ . "shop`");
        $employees = Db::getInstance()->executeS('SELECT * FROM `' . _DB_PREFIX_ . 'employee`');
        if ($shops) {
            foreach ($shops as $shop) {
                if ($employees) {
                    foreach ($employees as $employee) {
                        if (!Db::getInstance()->getRow('SELECT * FROM  `' . _DB_PREFIX_ . 'ets_livechat_employee_status` WHERE id_employee=' . (int)$employee['id_employee'] . ' AND id_shop=' . (int)$shop['id_shop']))
                            Db::getInstance()->execute('INSERT INTO `' . _DB_PREFIX_ . 'ets_livechat_employee_status`(id_employee,id_shop,status) VALUES("' . (int)$employee['id_employee'] . '","' . (int)$shop['id_shop'] . '","online")');
                    }
                }
            }
        }
        return $res;
    }
    public static function dropTable()
    {
        $res = Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_auto_msg`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_conversation`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_ip_address`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_message`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_pre_made_message`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_download`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_url`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_departments`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_departments_employee`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_staff`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_employee_online`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_employee_status`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_staff_decline`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_ticket_form`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_lang`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_field`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_field_lang`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_customer_info`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_field`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_social_login`');
        $res &= Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'ets_livechat_social_customer`');
        return $res;
    }
    public static function getMetaByUrlRewrite($url_rewrite)
    {
        return Db::getInstance()->getValue('SELECT id_meta FROM `' . _DB_PREFIX_ . 'meta_lang` WHERE url_rewrite ="' . pSQL($url_rewrite) . '"');
    }
    public static function getMetaByController($controller)
    {
        return Db::getInstance()->getValue('SELECT id_meta FROM `' . _DB_PREFIX_ . 'meta` WHERE page ="module-ets_livechat-' . pSQL($controller) . '"');
    }
    public static function addSocialAddCustomer($identifier,$email)
    {
        if (!Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'ets_livechat_social_customer` WHERE identifier="' . pSQL($identifier) . '" AND email="' . pSQL($email) . '"'))
            Db::getInstance()->execute('INSERT INTO `' . _DB_PREFIX_ . 'ets_livechat_social_customer` (identifier,email) values("' . pSQL($identifier) . '","' . pSQL($email) . '")');
    }
    public static function trackingLoginSocial($customer, $network)
    {
        if ((int)Db::getInstance()->getValue('SELECT id_social_login FROM `' . _DB_PREFIX_ . 'ets_livechat_social_login` WHERE id_customer=' . (int)$customer->id)) {
            return Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . 'ets_livechat_social_login` SET social="' . pSQL($network) . '",date_login="' . pSQL(date('Y-m-d H:i:s')) . '" WHERE id_customer=' . (int)$customer->id);
        } else
            return Db::getInstance()->execute('INSERT INTO `' . _DB_PREFIX_ . 'ets_livechat_social_login`(id_customer,social,date_login) VALUES("' . (int)$customer->id . '","' . pSQL($network) . '","' . pSQL(date('Y-m-d H:i:s')) . '")');
    }
    public static function checkVesionModule()
    {
        $cache_key = 'LC_Base::checkVesionModule';
        if(!Cache::isStored($cache_key))
        {
            $version = Db::getInstance()->getValue('SELECT version FROM `' . _DB_PREFIX_ . 'module` WHERE name ="ets_livechat"');
            if ($version && version_compare($version, '2.0', '>=')) {
                $result = true;
            }
            else
                $result = false;
            Cache::store($cache_key,$result);
            return $result;
        }
        return Cache::retrieve($cache_key);

    }
    public static function hasIndex($table, $index)
    {
        return (int)Db::getInstance()->getValue('SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA = "' . _DB_NAME_ . '" AND TABLE_NAME = "' . _DB_PREFIX_ . bqSQL($table) . '" AND INDEX_NAME = "' . pSQL($index) . '"') > 0 ? true : false;
    }
    public static function createIndexDataBase()
    {
        $sqls = array();
        if (self::hasIndex('ets_livechat_conversation', 'index_conversation'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_conversation` DROP INDEX index_conversation';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_conversation` ADD INDEX( `id_ticket`), ADD INDEX(`blocked`), ADD INDEX(`archive`),ADD INDEX(`customer_writing`), ADD INDEX(`employee_writing`), ADD INDEX(`captcha_enabled`), ADD INDEX(`id_departments_wait`), ADD INDEX(`id_employee_wait`), ADD INDEX(`id_tranfer`), ADD INDEX(`rating`), ADD INDEX(`replied`), ADD INDEX(`enable_sound`), ADD INDEX(`chatref`)';
        if (self::hasIndex('ets_livechat_conversation', 'idx_id_customer'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_conversation` DROP INDEX idx_id_customer';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_conversation` ADD INDEX `idx_id_customer` (`id_customer`)';
        if (self::hasIndex('ets_livechat_conversation', 'idx_id_departments'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_conversation` DROP INDEX idx_id_departments';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_conversation` ADD INDEX `idx_id_departments` (`id_departments`)';
        if (self::hasIndex('ets_livechat_conversation', 'idx_id_employee'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_conversation` DROP INDEX idx_id_employee';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_conversation` ADD INDEX `idx_id_employee` (`id_employee`)';
        if (self::hasIndex('ets_livechat_conversation', 'idx_id_shop'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_conversation` DROP INDEX idx_id_shop';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_conversation` ADD INDEX `idx_id_shop` (`id_shop`)';
        if (self::hasIndex('ets_livechat_departments', 'index_departments'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_departments` DROP INDEX index_departments';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_departments` ADD INDEX(`sort_order`),ADD INDEX(`status`)';

        if (self::hasIndex('ets_livechat_download', 'index_download'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_download` DROP INDEX index_download';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_download` ADD INDEX(`id_message`), ADD INDEX(`id_ticket`),ADD INDEX(`id_field`), ADD INDEX(`id_note`), ADD INDEX(`id_conversation`)';

        if (self::hasIndex('ets_livechat_employee_online', 'index_employee'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_employee_online` DROP INDEX index_employee';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_employee_online` ADD PRIMARY KEY IF NOT EXISTS ( `id_employee`, `id_shop`)';

        if (self::hasIndex('ets_livechat_employee_status', 'index_employee_status'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_employee_status` DROP INDEX index_employee_status';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_employee_status` ADD PRIMARY KEY IF NOT EXISTS ( `id_employee`, `id_shop`)';

        if (self::hasIndex('ets_livechat_message', 'index_message'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_message` DROP INDEX index_message';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_message` ADD INDEX(`id_conversation`), ADD INDEX(`id_employee`), ADD INDEX(`id_product`), ADD INDEX(`delivered`)';

        if (self::hasIndex('ets_livechat_ticket_form', 'index_ticket_form'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form` DROP INDEX index_ticket_form';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form` ADD INDEX(`active`), ADD INDEX(`id_shop`), ADD INDEX(`send_mail_to_customer`), ADD INDEX(`send_mail_reply_customer`), ADD INDEX(`send_mail_reply_admin`),ADD INDEX(`customer_reply_upload_file`),ADD INDEX(`allow_user_submit`),ADD INDEX(`save_customer_file`),ADD INDEX(`save_staff_file`),ADD INDEX(`require_select_department`),ADD INDEX(`allow_captcha`),ADD INDEX(`customer_no_captcha`),ADD INDEX(`deleted`),ADD INDEX(`sort_order`),ADD INDEX(`default_priority`)';

        if (self::hasIndex('ets_livechat_ticket_form_field', 'index_ticket_form_field'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_field` DROP INDEX index_ticket_form_field';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_field` ADD INDEX(`id_form`),ADD INDEX(`is_contact_mail`), ADD INDEX(`is_contact_name`), ADD INDEX(`is_subject`), ADD INDEX(`is_customer_phone_number`), ADD INDEX(`required`), ADD INDEX(`deleted`), ADD INDEX(`position`)';

        if (self::hasIndex('ets_livechat_ticket_form_field_lang', 'index_ticket_form_field_lang'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_field_lang` DROP INDEX index_ticket_form_field_lang';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_field_lang` ADD PRIMARY KEY IF NOT EXISTS( `id_field`, `id_lang`)';

        if (self::hasIndex('ets_livechat_ticket_form_lang', 'index_ticket_form_lang'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_lang` DROP INDEX index_ticket_form_lang';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_lang` ADD PRIMARY KEY IF NOT EXISTS( `id_form`, `id_lang`)';

        if (self::hasIndex('ets_livechat_ticket_form_message', 'index_ticket_form_message'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message` DROP INDEX index_ticket_form_message';
    $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message` ADD INDEX(`id_form`), ADD INDEX(`id_shop`), ADD INDEX(`id_departments`), ADD INDEX(`id_customer`), ADD INDEX(`id_product`), ADD INDEX(`priority`), ADD INDEX(`readed`), ADD INDEX(`replied`), ADD INDEX(`id_employee`),ADD INDEX(`customer_readed`)';

        if (self::hasIndex('ets_livechat_ticket_form_message_field', 'ticket_form_message_field'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_field` DROP INDEX ticket_form_message_field';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_field` ADD PRIMARY KEY IF NOT EXISTS( `id_message`, `id_field`, `id_download`)';

        if (self::hasIndex('ets_livechat_ticket_form_message_note', 'ticket_form_message_note'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note` DROP INDEX ticket_form_message_note';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note` ADD INDEX(`id_message`),ADD INDEX(`id_employee`), ADD INDEX(`id_download`), ADD INDEX(`readed`)';

        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_customer_info` ADD PRIMARY KEY IF NOT EXISTS ( `id_customer`)';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_departments_employee` ADD PRIMARY KEY IF NOT EXISTS( `id_departments`, `id_employee`)';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_ip_address` ADD PRIMARY KEY IF NOT EXISTS( `ip_address`)';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_social_customer` ADD PRIMARY KEY IF NOT EXISTS ( `identifier`, `email`)';

        if (self::hasIndex('ets_livechat_social_login', 'index_social_login'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_social_login` DROP INDEX index_social_login';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_social_login` ADD UNIQUE `index_social_login` (`id_social_login`, `id_customer`)';

        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_staff` ADD PRIMARY KEY IF NOT EXISTS (`id_employee`)';

        if (self::hasIndex('ets_livechat_staff', 'index_staff'))
            $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_staff` DROP INDEX index_staff';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_staff` ADD UNIQUE `index_staff` (`id_employee`, `status`)';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_staff_decline` ADD PRIMARY KEY IF NOT EXISTS( `id_employee`, `id_conversation`)';
        $sqls[] = 'ALTER TABLE `' . _DB_PREFIX_ . 'ets_livechat_url` ADD PRIMARY KEY IF NOT EXISTS( `id_conversation`)';
        foreach ($sqls as $sql)
            Db::getInstance()->execute($sql);
        return true;
    }
    public static function getCountProductOrder($id_customer,$id_order)
    {
        return Db::getInstance()->getValue('SELECT count(od.product_id) FROM `' . _DB_PREFIX_ . 'order_detail` od
        INNER JOIN `' . _DB_PREFIX_ . 'orders` o ON (o.id_order=od.id_order)
        WHERE  o.id_customer="' . (int)$id_customer . '"' . ($id_order ? ' AND o.id_order="' . (int)$id_order . '"':''));
    }
    public static function getListProductOrders($id_customer,$id_order, $page = 1, $limit = 50)
    {
        $start = ($page - 1) * $limit;
        $products = Db::getInstance()->executeS('SELECT o.id_order,o.reference,o.date_add,o.current_state,od.product_name,od.product_id,od.product_attribute_id,od.product_quantity FROM `' . _DB_PREFIX_ . 'order_detail` od
        INNER JOIN `' . _DB_PREFIX_ . 'orders` o ON (o.id_order=od.id_order)
        WHERE  o.id_customer="' . (int)$id_customer . '"' . ($id_order ? ' AND o.id_order="' . (int)$id_order . '"':'').'
        ORDER BY o.date_add desc
        LIMIT ' . (int)$start . ',' . (int)$limit);
        return $products;
    }
    public static function getEmailSocialByIdentifier($identifier)
    {
        return Db::getInstance()->getValue('SELECT email FROM `'._DB_PREFIX_.'ets_livechat_social_customer` WHERE identifier="'.pSQL($identifier).'"');
    }
    public static function convertDate($date)
    {
        if (date('Y-m-d') == date('Y-m-d', strtotime($date))) {
            $date = date('h:i A', strtotime($date));
        } else {
            if (date('Y') == date('Y', strtotime($date))) {
                $date = date('d-m h:i A', strtotime($date));
            } else
                $date = date('d-m-Y h:i A', strtotime($date));
        }
        return $date;
    }
    public static function getCustomerLoginSocial($count=false,$filter=false,$start=0,$limit=0)
    {
        $sql = 'SELECT '.($count? 'count(*)':'*').' FROM `'._DB_PREFIX_.'ets_livechat_social_login` s
            LEFT JOIN `'._DB_PREFIX_.'customer` c ON (s.id_customer=c.id_customer)
            WHERE 1 '.(!LC_Tools::allShop() ? ' AND c.id_shop="'.(int)Context::getContext()->shop->id.'"':'').($filter ? (string)$filter :'').' ORDER BY date_login desc'.($limit ? ' LIMIT '.(int)$start.','.(int)$limit:'');
        if($count)
            return Db::getInstance()->getValue($sql);
        else
        {
            $customers = Db::getInstance()->executeS($sql);
            if($customers)
            {
                foreach($customers as &$customer)
                {
                    $customer['date_login'] = self::convertDate($customer['date_login']);
                    $customer['social'] = Tools::strtolower($customer['social']);
                }
            }
            return $customers;
        }
    }
    public static function checkCustomerISVerified($id_customer)
    {
        return $id_customer && Module::isInstalled('ets_free_downloads') && Module::isEnabled('ets_free_downloads') ? Db::getInstance()->getValue('SELECT is_verified FROM `' . _DB_PREFIX_ . 'ets_fd_verification` WHERE id_customer=' . (int)$id_customer) : false;
    }
    public static function duplicateRowsFromDefaultShopLang($tableName, $shopId,$identifier)
    {
        $shopDefaultLangId = Configuration::get('PS_LANG_DEFAULT');
        $fields = array();
        $shop_field_exists = $primary_key_exists = false;
        $columns = Db::getInstance()->executeS('SHOW COLUMNS FROM `' . $tableName . '`');
        foreach ($columns as $column) {
            $fields[] = '`' . $column['Field'] . '`';
            if ($column['Field'] == 'id_shop') {
                $shop_field_exists = true;
            }
            if ($column['Field'] == $identifier) {
                $primary_key_exists = true;
            }
        }
        if (!$primary_key_exists) {
            return true;
        }

        $sql = 'INSERT IGNORE INTO `' . pSQL($tableName) . '` (' . implode(',', array_map('pSQL',$fields)) . ') (SELECT ';

        // For each column, copy data from default language
        reset($columns);
        $selectQueries = array();
        foreach ($columns as $column) {
            if ($identifier != $column['Field'] && $column['Field'] != 'id_lang') {
                $selectQueries[] = '(
							SELECT `' . bqSQL($column['Field']) . '`
							FROM `' . bqSQL($tableName) . '` tl
							WHERE tl.`id_lang` = ' . (int) $shopDefaultLangId . '
							' . ($shop_field_exists ? ' AND tl.`id_shop` = ' . (int) $shopId : '') . '
							AND tl.`' . bqSQL($identifier) . '` = `' . bqSQL(str_replace('_lang', '', $tableName)) . '`.`' . bqSQL($identifier) . '`
						)';
            } else {
                $selectQueries[] = '`' . bqSQL($column['Field']) . '`';
            }
        }
        $sql .= implode(',', $selectQueries);
        $sql .= ' FROM `' . _DB_PREFIX_ . 'lang` CROSS JOIN `' . bqSQL(str_replace('_lang', '', $tableName)) . '` ';

        // prevent insert with where initial data exists
        $sql .= ' WHERE `' . bqSQL($identifier) . '` IN (SELECT `' . bqSQL($identifier) . '` FROM `' . bqSQL($tableName) . '`) )';
        return Db::getInstance()->execute($sql);
    }
}