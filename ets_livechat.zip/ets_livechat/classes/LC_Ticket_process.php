<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) { exit; }


class LC_Ticket_process
{
    static $_INSTANCE;
    /** @var Module */
    private $module;
    /** @var Context */
    private $context;
    private $_errors;
    static $initialize;

    /**
     * LC_Ticket_process constructor.
     * @param null $module Module
     * @param null $context Context
     */
    public function __construct($module = null, $context = null)
    {
        $this->module = $module;
        $this->context = $context;
    }

    public static function getInstance()
    {
        if (!self::$_INSTANCE) {
            self::$_INSTANCE = new LC_Ticket_process();
        }

        return self::$_INSTANCE;
    }

    /**
     * @param null $module Module
     * @return LC_Ticket_process
     */
    public function setModule($module)
    {
        $this->module = $module;

        return $this;
    }

    /**
     * @param null $context Context
     * @return LC_Ticket_process
     */
    public function setContext($context)
    {
        $this->context = $context;

        return $this;
    }

    /**
     * @param $string
     * @param null $source
     * @return mixed|string
     */
    public function l($string, $source = null)
    {
        return Translate::getModuleTranslation('ets_livechat', $string, $source ?: pathinfo(__FILE__, PATHINFO_FILENAME));
    }

    public function init()
    {
        if (!self::$initialize) {
            if (!$this->context || !$this->context instanceof Context) {
                $this->setContext(Context::getContext());
            }
            if (!$this->module || !$this->module instanceof Module) {
                $this->setModule(Module::getInstanceByName('ets_livechat'));
            }
            self::$initialize = true;
        }
    }

    /**
     * @return mixed
     */
    public function isManagerTicket()
    {
        return isset($this->context->employee->id) && $this->context->employee->id > 0 && $this->context->employee->isLoggedBack() ? 1 : (isset($this->context->customer->id) && $this->context->customer->id > 0 && $this->context->customer->isLogged() ? LC_Ticket::managerTicket($this->context->customer->email) : 0);
    }

    public function isAdmin()
    {
        return defined('_PS_ADMIN_DIR_') && isset($this->context->employee) && (int)$this->context->employee->id > 0 && $this->context->employee->isLoggedBack() ? 1 : 0;
    }

    public function redirectLink($controller, $params)
    {
        $ssl = Configuration::get('PS_SSL_ENABLED') && Configuration::get('PS_SSL_ENABLED_EVERYWHERE');
        if ($this->isAdmin()) {
            Tools::redirectAdmin($this->context->link->getAdminLink($controller, true, [], $params));
        }
        Tools::redirectLink($this->context->link->getModuleLink($this->module->name, $controller, $params, $ssl));
    }
    /**
     * @param $id_ticket
     * @return array|bool|object|null
     */
    public function checkAccessTicket($id_ticket)
    {

        if (!$id_ticket || !Validate::isUnsignedInt($id_ticket) || !(($ticketObj = new LC_Ticket($id_ticket)) && Validate::isLoadedObject($ticketObj))) {
            return false;
        }
        $manager_ticket = $this->isAdmin() && (int)$this->context->employee->id_profile !== (int)_PS_ADMIN_PROFILE_ || $this->isManagerTicket() ? 1 : 0;
        if(!$manager_ticket && isset($ticketObj) && !$ticketObj->id_customer && !(($token = Ets_livechat::getToken()) && $token == md5(_COOKIE_KEY_.$ticketObj->id.$ticketObj->date_add)))
        {
            return false;
        }
        $dq = new DbQuery();
        $dq
            ->select('fm.*, fl.title, c.firstname, c.lastname, c.email, f.default_priority, c.id_lang')
            ->from('ets_livechat_ticket_form_message', 'fm')
            ->leftJoin('ets_livechat_ticket_form', 'f', 'fm.id_form = f.id_form')
            ->leftJoin('ets_livechat_ticket_form_lang', 'fl', 'f.id_form = fl.id_form AND fl.id_lang = ' . (int)$this->context->language->id)
            ->leftJoin('customer', 'c', 'fm.id_customer = c.id_customer');
        if ($manager_ticket) {
            $dq
                ->leftJoin('ets_livechat_departments', 'd', 'fm.id_departments = d.id_departments')
                ->leftJoin('ets_livechat_departments_employee', 'de', 'd.id_departments = de.id_departments');
            if ($this->isAdmin() && (int)$this->context->employee->id_profile !== (int)_PS_ADMIN_PROFILE_) {
                $dq
                    ->where('fm.id_departments <= 0 OR de.id_employee = ' . (int)$this->context->employee->id . ' OR d.all_employees = 1')
                    ->where('fm.id_employee <= 0 OR fm.id_employee = ' . (int)$this->context->employee->id);
            }
            if(($context = Context::getContext()) && isset($context->customer) && isset($context->customer->email) && LC_Ticket::managerTicket($context->customer->email) && Configuration::get('ETS_LC_ONLY_DISPLAY_TICKET_OPEN'))
            {
                $dq->where('fm.status="open"');
            }
        } else {
            $dq
                ->where('fm.id_customer=' . (int)$this->context->customer->id);
        }
        $dq
            ->where('fm.id_message=' . (int)$id_ticket);
        if (!LC_Tools::allShop() || !$this->isAdmin()) {
            $dq
                ->where('fm.id_shop=' . (int)$this->context->shop->id);
        }
        $dq->groupBy('fm.id_message');
        if ($ticket = Db::getInstance()->getRow($dq)) {

            // Department name:
            if (isset($ticket['id_departments'])
                && (int)$ticket['id_departments'] > 0
            ) {
                $department = new LC_Departments((int)$ticket['id_departments']);
                $ticket['dertpartment_name'] = $department->name;
            } else {
                $ticket['dertpartment_name'] = $this->l('All departments');
            }
            // Employee name:
            if (isset($ticket['id_employee'])
                && $ticket['id_employee'] > 0
            ) {
                $employee = new Employee((int)$ticket['id_employee']);
                if(Validate::isLoadedObject($employee))
                {
                    $staff = LC_Departments::getStaffByEmployee($employee->id);
                    $ticket['employee_name'] = $staff && $staff['name'] ? $staff['name']: $employee->firstname . ' ' . $employee->lastname;
                }
                    
                else
                    $ticket['employee_name'] = $this->l('Staff deleted');
            } else {
                $ticket['employee_name'] = false;
            }
        }

        return $ticket;
    }

    /**
     * @param $ticket
     * @param bool $orderBy
     * @param bool $limit
     * @param int $start
     * @param bool $total
     * @param null $last_note
     * @return array|false|mysqli_result|PDOStatement|resource|string|null
     * @throws PrestaShopDatabaseException
     */
    public function getMessagesTicket($ticket, $orderBy = false, $limit = false, $start = 0, $total = false, $last_note = null)
    {
        if (!is_array($ticket)) {
            $ticket = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message` WHERE id_message=' . (int)$ticket);
        }
        $query = '
            FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note` mn
                LEFT JOIN `' . _DB_PREFIX_ . 'customer` c ON (c.id_customer = mn.id_customer)
                LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_customer_info` ci ON (ci.id_customer = c.id_customer)
                LEFT JOIN `' . _DB_PREFIX_ . 'employee` e ON (e.id_employee = mn.id_employee)
                LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_staff` s ON (s.id_employee = e.id_employee)
            WHERE id_message=' . (int)$ticket['id_message'];
        if ($total) {
            return Db::getInstance()->getValue('SELECT COUNT(*) ' . $query);
        }
        $query = '
            SELECT mn.* 
                , CONCAT(c.firstname, " ", c.lastname) customer_name
                , ci.avata as customer_avata
                , CONCAT(e.firstname, " ", e.lastname) employee_name
                , s.avata as employee_avata
                , s.signature
                ,ci.signature as manager_signature
        ' . $query . ' ORDER BY date_add ' . ($orderBy ? pSQL($orderBy) : 'ASC') . ($limit ? ' LIMIT ' . ($start ? (int)$start : 0) . ',' . (int)$limit : '');

        $messages = Db::getInstance()->executeS($query);
        if ($messages) {
            $id_tmp = 0;
            if (count($messages) < 2
                && is_array($last_note)
                && count($last_note) > 0
            ) {
                $id_tmp = isset($last_note['id_employee']) && $last_note['id_employee'] > 0 ? (int)$last_note['id_employee'] : (isset($last_note['id_customer']) && $last_note['id_customer'] > 0 ? (int)$last_note['id_customer'] : 0);
            }
            $avatar = Configuration::get('ETS_LC_DISPLAY_AVATA') ? 1 : 0;
            foreach ($messages as &$message) {
                if (isset($message['id_employee']) && $message['id_employee'] > 0) {
                    // User name:
                    if (Configuration::get('ETS_LC_DISPLAY_COMPANY_INFO') == 'general') {
                        $message['employee_name'] = Configuration::get('ETS_LC_COMPANY_NAME');
                        $message['employee_name_hide'] = LC_Tools::getNameHide(Configuration::get('ETS_LC_COMPANY_NAME'));
                    } else {
                        $message['employee_name_hide'] = LC_Tools::getNameHide($message['employee_name']);
                    }
                    // Avatar:
                    if ($avatar && (!$id_tmp || $id_tmp !== (int)$message['id_employee'])) {
                        if (Configuration::get('ETS_LC_DISPLAY_COMPANY_INFO') == 'general') {
                            if (Configuration::get('ETS_LC_COMPANY_LOGO')) {
                                $message['employee_avata'] = $this->context->link->getMediaLink(_PS_ETS_LIVE_CHAT_IMG_ . Configuration::get('ETS_LC_COMPANY_LOGO'));
                            } else {
                                $message['employee_avata'] = $this->context->link->getMediaLink(_PS_ETS_LIVE_CHAT_IMG_ . 'adminavatar.jpg');
                            }
                        } else if (!empty($message['employee_avata'])) {
                            $message['employee_avata'] = $this->context->link->getMediaLink(_PS_ETS_LIVE_CHAT_IMG_ . $message['employee_avata']);
                        } else {
                            $message['employee_avata'] = $this->context->link->getMediaLink(_PS_ETS_LIVE_CHAT_IMG_ . 'adminavatar.jpg');
                        }
                        $id_tmp = (int)$message['id_employee'];
                    } else
                        $message['employee_avata'] = '';
                } else {
                    // User name:
                    if (!empty($message['customer_name'])) {
                        $message['customer_name_hide'] = LC_Tools::getNameHide($message['customer_name']);
                    }
                    elseif(($ticketObj = new LC_Ticket($ticket['id_message'])) && $ticketObj->customer_name)
                    {
                        $message['customer_name'] = $message['customer_name_hide'] = $ticketObj->customer_name;
                    }
                    else {
                        $message['customer_name'] = 'Ticket ID #' . $ticket['id_message'];
                        $message['customer_name_hide'] = 'Ticket ID #' . $ticket['id_message'];
                    }
                    // Avatar:
                    if ($avatar && (!$id_tmp || $id_tmp !== (int)$message['id_customer'])) {
                        if (!empty($message['customer_avata'])) {
                            $message['customer_avata'] = $this->context->link->getMediaLink(_PS_ETS_LIVE_CHAT_IMG_ . $message['customer_avata']);
                        } elseif (Configuration::get('ETS_LC_CUSTOMER_AVATA')) {
                            $message['customer_avata'] = $this->context->link->getMediaLink(_PS_ETS_LIVE_CHAT_IMG_ . Configuration::get('ETS_LC_CUSTOMER_AVATA'));
                        } else {
                            $message['customer_avata'] = $this->context->link->getMediaLink(_PS_ETS_LIVE_CHAT_IMG_ . 'customeravata.jpg');
                        }
                        $id_tmp = (int)$message['id_customer'];
                    } else
                        $message['customer_avata'] = '';
                }
                $message['note'] = Ets_livechat::replace_link($message['note']);
                if ($message['file_name'] && $message['id_download']) {
                    if ($message['id_download'] != -1 && $attachment = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'ets_livechat_download` WHERE id_download="' . (int)$message['id_download'] . '"')) {
                        if($this->module->isBackOffice())
                            $link_download = $this->context->link->getAdminLink('AdminLiveChatTickets').'&downloadfile='.md5(_COOKIE_KEY_ . $message['id_download']);
                        else
                            $link_download = $this->context->link->getModuleLink($this->module->name, 'download', array('downloadfile' => md5(_COOKIE_KEY_ . $message['id_download'])));
                        $message['note'] .= ($message['note'] ? $this->module->displayText('', 'br', '') : '') . $this->module->displayText($this->module->displayText($message['file_name'], 'a', '', array('href' => $link_download)) . ($attachment['file_size'] ? $this->module->displayText('(' . ($attachment['file_size'] >= 1024 ? Tools::ps_round($attachment['file_size'] / 1024, 2) : $attachment['file_size']) . ' ' . ($attachment['file_size'] >= 1024 ? 'MB' : 'KB') . ')', 'span', 'file_size', array('' => '')) : ''), 'span', 'message_file');
                    } else {
                        if ($this->isManagerTicket()) {
                            $message['note'] .= ($message['note'] ? $this->module->displayText('', 'br', '') : '') . $this->module->displayText($message['file_name'] . ' ' . ($message['send_email_admin'] == 'success' ? '(' . $this->l('File was sent via email') . ')' : '(' . $this->l('File did not be sent via email') . ')'), 'b');
                        } else {
                            $message['note'] .= ($message['note'] ? $this->module->displayText('', 'br', '') : '') . $this->module->displayText($message['file_name'] . ' ' . ($message['send_email_customer'] == 'success' ? '(' . $this->l('File was sent via email') . ')' : '(' . $this->l('File did not be sent via email') . ')'), 'b');
                        }
                    }
                }
                if ($message['id_employee'] && $message['signature']) {
                    $message['note'] .= $this->module->displayText('', 'br', '') . '----- ' . $this->module->displayText('', 'br', '') . $this->module->displayText(Tools::nl2br(strip_tags($message['signature'])), 'span', 'employee_signature');
                }
                elseif($message['id_customer'] && ($manager = new Customer($message['id_customer'])) && Lc_ticket::managerTicket($manager->email)  && $message['manager_signature'])
                {
                    $message['note'] .= $this->module->displayText('', 'br', '') . '----- ' . $this->module->displayText('', 'br', '') . $this->module->displayText(Tools::nl2br(strip_tags($message['manager_signature'])), 'span', 'employee_signature');
                }
                if (date('Y-m-d', strtotime($message['date_add'])) == date('Y-m-d')) {
                    $message['date_add'] = sprintf($this->l('Today, %s'), date('h:i A'));
                } elseif (date('Y-m-d', strtotime($message['date_add'])) == date('Y-m-d', strtotime('-1 days'))) {
                    $message['date_add'] = sprintf($this->l('Yesterday, %s'), date('h:i A'));
                }
                $message['your_ticket'] = $this->isAdmin() && isset($message['id_employee']) && $message['id_employee'] > 0 && $this->context->employee->id == (int)$message['id_employee'] || isset($message['id_customer']) && $message['id_customer'] > 0 && isset($this->context->customer->id) && $this->context->customer->id > 0 && $this->context->customer->id == (int)$message['id_customer'] || (!$message['id_customer'] && !$message['id_employee'] && Tools::isSubmit('token')) ? 1 : 0;
            }
        }

        return $messages;
    }


    public function downloadFile($downloadfile)
    {
        if (!$downloadfile ||
            !Validate::isCleanHtml($downloadfile)
        ) {
            return false;
        }

        $file = Db::getInstance()->getRow('
            SELECT filename, id_message, id_ticket, id_field, id_note, `name` 
            FROM `' . _DB_PREFIX_ . 'ets_livechat_download` 
            WHERE md5(concat("' . _COOKIE_KEY_ . '",id_download))="' . pSQL($downloadfile) . '"
        ');
        $filename = isset($file['name']) && trim($file['name']) !== '' ? $file['name'] : $file['filename'];
        if (isset($file['id_message'])
            && $file['id_message'] > 0
            && ($message = new LC_Message((int)$file['id_message']))
            && $message->id > 0
        ) {
            $name_attachment = $message->name_attachment;
            if (isset($this->context->employee->id)
                && $this->context->employee->id > 0
                && $this->context->employee->isLoggedBack()
                && !LC_Conversation::checkConversationEmployee($message->id_conversation, $this->context->employee->id)
            ) {
                die($this->l('You do not have permission to download this file.') . (isset($this->context->customer) && !$this->context->customer->isLogged() ? $this->l('You may try to log into your account in order to download the file.') : ''));
            }
        } elseif (isset($file['id_ticket'])
            && $file['id_ticket'] > 0
            && isset($file['id_field'])
            && $file['id_field'] > 0
        ) {
            $name_attachment = Db::getInstance()->getValue('SELECT `value` FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_field` WHERE id_message=' . (int)$file['id_ticket'] . ' AND id_field=' . (int)$file['id_field']);
            $ticket = new LC_Ticket($file['id_ticket']);
            if (!$this->checkAccessTicket($ticket->id)) {
                die($this->l('You do not have permission to download this file.') . (isset($this->context->customer) && !$this->context->customer->isLogged() ? $this->l('You may try to log into your account in order to download the file.') : ''));
            }
        } elseif (isset($file['id_note'])
            && $file['id_note'] > 0
            && ($note = new LC_Note($file['id_note']))
            && $note->id > 0
        ) {
            $ticket = new LC_Ticket($note->id_message);
            if (!$this->checkAccessTicket($ticket->id)) {
                die($this->l('You do not have permission to download this file.') . (isset($this->context->customer) && !$this->context->customer->isLogged() ? $this->l('You may try to log into your account in order to download the file.') : ''));
            }
            $name_attachment = $note->file_name;
        } else {
            $name_attachment = isset($file['filename']) && $file['filename'] ? $file['filename'] : $filename;
        }
        if ($filename && (file_exists(_PS_ETS_LIVE_CHAT_UPLOAD_DIR_ . $filename) || isset($file['filename']) && file_exists(_PS_ETS_LIVE_CHAT_UPLOAD_DIR_ . $file['filename']))) {
            $ext = Tools::strtolower(Tools::substr(strrchr($filename, '.'), 1));
            if (trim($ext) == ''
                && isset($file['filename'])
                && trim($file['filename']) !== ''
            ) {
                $ext = Tools::strtolower(Tools::substr(strrchr($file['filename'], '.'), 1));
            }
            switch ($ext) {
                case "pdf":
                    $ctype = "application/pdf";
                    break;
                case "exe":
                    $ctype = "application/octet-stream";
                    break;
                case "zip":
                    $ctype = "application/zip";
                    break;
                case "doc":
                case "docx":
                    $ctype = "application/msword";
                    break;
                case "xls":
                    $ctype = "application/vnd.ms-excel";
                    break;
                case "ppt":
                    $ctype = "application/vnd.ms-powerpoint";
                    break;
                case "gif":
                    $ctype = "image/gif";
                    break;
                case "png":
                    $ctype = "image/png";
                    break;
                case "jpeg":
                case "jpg":
                    $ctype = "image/jpg";
                    break;
                case 'webp':
                    $ctype = 'image/webp';
                    break;
                default:
                    $ctype = "application/force-download";
            }
            header("Pragma: public");
            header("Expires: 0");
            header("X-Robots-Tag: noindex, nofollow", true);
            header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
            header("Cache-Control: private", false);
            header("Content-Type: $ctype");
            header("Content-Disposition: attachment; filename=\"" . $name_attachment . (trim(Tools::strtolower(Tools::substr(strrchr($name_attachment, '.'), 1))) == '' ? '.' . $ext : '') . "\";");
            header("Content-Transfer-Encoding: Binary");
            $file_url = _PS_ETS_LIVE_CHAT_UPLOAD_DIR_ . $filename;
            if ($fsize = @filesize($file_url)) {
                header("Content-Length: " . $fsize);
            }
            ob_clean();
            flush();
            readfile($file_url);
            exit();
        } else {
            die($this->l('File Not Found'));
        }
    }

    const DEFAULT_MAX_SIZE = 104857600;

    public function validateUpload($key, &$errors)
    {
        $file_dest = _PS_ETS_LIVE_CHAT_UPLOAD_DIR_;
        $post_content_size = $this->getServerVars('CONTENT_LENGTH');

        if (($post_max_size = $this->getPostMaxSizeBytes()) && ($post_content_size > $post_max_size)) {
            $errors[] = sprintf($this->l('The uploaded file(s) exceeds the post_max_size directive in php.ini (%s > %s)'), $post_content_size, $post_max_size);
        } elseif (!@is_writable($file_dest) && !empty($_FILES[$key]['name'])) {
            $errors[] = sprintf($this->l('The directory "%s" is not able to write.'), $file_dest);
        } elseif (isset($_FILES[$key]) && !empty($_FILES[$key]['name'])) {
            for ($ik = 1; $ik <= (int)Configuration::get('ETS_PC_MAX_UPLOAD_PHOTO'); $ik++) {
                if (!isset($_FILES[$key]['name'][$ik]) || !$_FILES[$key]['name'][$ik] || isset($_FILES[$key]['error'][$ik]) && (int)$_FILES[$key]['error'][$ik] === 4)
                    continue;
                if ($uploadError = $this->checkUploadError($_FILES[$key]['error'][$ik], $_FILES[$key]['name'][$ik])) {
                    $errors[] = $ik . '. ' . $uploadError;
                } elseif ($_FILES[$key]['size'][$ik] > (int)Configuration::get('PS_ATTACHMENT_MAXIMUM_SIZE') * 1024 * 1024) {
                    $errors[] = $ik . '. ' . sprintf($this->l('File is too large. Maximum size allowed: %s MB'), (int)Configuration::get('PS_ATTACHMENT_MAXIMUM_SIZE'));
                } elseif ($_FILES[$key]['size'][$ik] > self::DEFAULT_MAX_SIZE) {
                    $errors[] = $ik . '. ' . sprintf($this->l('File is too large. Current size is %1s, maximum size is %2s.'), $_FILES[$key]['size'][$ik], self::DEFAULT_MAX_SIZE);
                } elseif (isset($_FILES[$key]['name'][$ik]) && $_FILES[$key]['name'][$ik]) {
                    $_FILES[$key]['name'][$ik] = str_replace(array(' ','(',')','!','@','#','+'),'_',$_FILES[$key]['name'][$ik]);
                    if (!Validate::isFileName($_FILES[$key]['name'][$ik])) {
                        $errors[] = $ik . '. ' . sprintf($this->l('File name "%s" is invalid'), $_FILES[$key]['name'][$ik]);
                    } else {
                        $type = Tools::strtolower(Tools::substr(strrchr($_FILES[$key]['name'][$ik], '.'), 1));
                        if (!in_array($type, array('jpg', 'gif', 'jpeg', 'png','webp'))) {
                            $errors[] = $ik . '. ' . sprintf($this->l('File "%s" type not allowed'), $_FILES[$key]['name'][$ik]);
                        }
                    }
                }
            }
        }

        return is_array($errors) && count($errors) > 0 ? false : true;
    }

    public function getServerVars($var)
    {
        return isset($_SERVER[$var]) ? $_SERVER[$var] : '';
    }

    public function getPostMaxSizeBytes()
    {
        $postMaxSize = min(@ini_get('post_max_size'), @ini_get('upload_max_filesize'));
        $bytes = (int)trim($postMaxSize);
        $last = Tools::strtolower($postMaxSize[Tools::strlen($postMaxSize) - 1]);
        switch ($last) {
            case 'g':
                $bytes *= 1024;
            case 'm':
                $bytes *= 1024;
            case 'k':
                $bytes *= 1024;
        }
        if ($bytes == '')
            $bytes = null;
        return $bytes;
    }

    public function checkUploadError($error_code, $file_name)
    {
        $error = 0;
        switch ($error_code) {
            case 1:
                $error = sprintf($this->l('The size of uploaded file "%1s" exceeds %2s'), $file_name, ini_get('upload_max_filesize'));
                break;
            case 2:
                $error = sprintf($this->l('The size of uploaded file exceeds %s'), ini_get('post_max_size'));
                break;
            case 3:
                $error = sprintf($this->l('The file "%s" was only partially uploaded'), $file_name);
                break;
            case 6:
                $error = $this->l('Missing temporary folder');
                break;
            case 7:
                $error = sprintf($this->l('Failed to write file "%s" to disk'), $file_name);
                break;
            case 8:
                $error = sprintf($this->l('A PHP extension stopped the file "%s" to upload'), $file_name);
                break;
            default:
                break;
        }
        return $error;
    }

    public function ajaxRender($data)
    {
        die(json_encode($data));
    }

    public function display($template)
    {
        if (!$this->module)
            return false;
        return $this->module->display($this->module->getLocalPath(), $template);
    }
    public static function ajaxProcessSearchProduct($query)
    {
        $excludeIds ='';
        $excludePackItself = false;
        if ($excludeIds && $excludeIds != 'NaN') {
            $excludeIds = implode(',', array_map('intval', explode(',', $excludeIds)));
        }
        $excludeVirtuals = false;
        $exclude_packs = false;
        $imageType = version_compare(_PS_VERSION_, '1.7', '>=') ? ImageType::getFormattedName('home') : ImageType::getFormatedName('home');
        if ($items = self::findProducts($query, $excludeIds, $excludePackItself, $excludeVirtuals, $exclude_packs)) {
            foreach ($items as $item) {
                $image_logo='';
                $product = array(
                    'id' => (int)($item['id_product']),
                    'name' => $item['name'],
                    'ref' => (!empty($item['reference']) ? $item['reference'] : ''),
                    'image' => $image_logo ? : ($item['id_image'] ? str_replace('http://', Tools::getShopProtocol(), Context::getContext()->link->getImageLink($item['link_rewrite'], $item['id_image'], $imageType)) :self::getNoImageDefault($imageType)),
                );
                echo implode('|', $product) . "\r\n";
            }
        }
        die($query);
    }
    public static function findProducts($query, $excludeIds, $excludePackItself = false, $excludeVirtuals = 0, $exclude_packs = 0, Context $context = null)
    {
        if ($excludeIds && !Validate::isArrayWithIds($excludeIds)) {
            return false;
        }
        if ($context == null) {
            $context = Context::getContext();
        }
        if (!$query or $query == '' or Tools::strlen($query) < 1) {
            die();
        }
        if ($pos = strpos($query, ' (ref:')) {
            $query = Tools::substr($query, 0, $pos);
        }
        $sql = '
            SELECT p.`id_product`, pl.`link_rewrite`, p.`reference`, pl.`name`, image_shop.`id_image` id_image, il.`legend`, p.`cache_default_attribute`
            FROM `' . _DB_PREFIX_ . 'product` p
            ' . Shop::addSqlAssociation('product', 'p') . '
            LEFT JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON (pl.id_product = p.id_product AND pl.id_lang = ' . (int)$context->language->id . Shop::addSqlRestrictionOnLang('pl') . ')
            LEFT JOIN `' . _DB_PREFIX_ . 'image` `i` ON (i.`id_product` = p.`id_product`)
            LEFT JOIN `' . _DB_PREFIX_ . 'image_lang` il ON (i.`id_image` = il.`id_image` AND il.`id_lang` = ' . (int)$context->language->id . ')
            LEFT JOIN `' . _DB_PREFIX_ . 'image_shop` image_shop ON (image_shop.`id_image` = i.`id_image` AND image_shop.cover=1 AND image_shop.id_shop=' . (int)$context->shop->id . ')
            WHERE p.active=1 AND (pl.name LIKE \'%' . pSQL($query) . '%\' OR p.reference LIKE \'%' . pSQL($query) . '%\')' .
            (!empty($excludeIds) ? ' AND p.id_product NOT IN (' . implode(',',array_map('intval',explode(',',$excludeIds))) . ') ' : ' ') .
            (!empty($excludePackItself) ? ' AND p.id_product <> ' . (int)$excludePackItself . ' ' : ' ') .
            ($excludeVirtuals ? 'AND NOT EXISTS (SELECT 1 FROM `' . _DB_PREFIX_ . 'product_download` pd WHERE (pd.id_product = p.id_product))' : '') .
            ($exclude_packs ? 'AND (p.cache_is_pack IS NULL OR p.cache_is_pack = 0)' : '') .
            ' GROUP BY p.id_product
        ';
        return Db::getInstance()->executeS($sql);
    }
    public static function getNoImageDefault($type_image)
    {
        $context = Context::getContext();
        if(file_exists(_PS_PROD_IMG_DIR_.$context->language->iso_code.'-default-'.$type_image.'.jpg'))
            return $context->link->getMediaLink(_PS_PROD_IMG_.$context->language->iso_code.'-default-'.$type_image.'.jpg');
        else
        {
            $langDefault = new Language(Configuration::get('PS_LANG_DEFAULT'));
            if(file_exists(_PS_PROD_IMG_DIR_.$langDefault->iso_code.'-default-'.$type_image.'.jpg'))
                return $context->link->getMediaLink(_PS_PROD_IMG_.$langDefault->iso_code.'-default-'.$type_image.'.jpg');
        }
    }
}