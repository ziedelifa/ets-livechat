<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) { exit; }

class LC_Ticket_form extends ObjectModel
{
    protected static $instance;
    public $active;
    public $id_shop;
    public $mail_new_ticket;
    public $custom_mail;
    public $send_mail_to_customer;
    public $send_mail_reply_customer;
    public $send_mail_to_customer_customer_reply;
    public $send_mail_reply_admin;
    public $send_mail_to_admin_admin_reply;
    public $send_from_email;
    public $send_from_name;
    public $customer_reply_upload_file;
    public $allow_user_submit;
    public $save_customer_file;
    public $allow_staff_upload_file;
    public $save_staff_file;
    public $require_select_department;
    public $departments;
    public $allow_captcha;
    public $captcha_type;
    public $customer_no_captcha;
    public $default_priority;
    public $title;
    public $description;
    public $friendly_url;
    public $meta_title;
    public $meta_description;
    public $meta_keywords;
    public $deleted;
    public $sort_order;
    public $button_submit_label;
    public $button_link_contact_label;
    public $button_link_contact_label_on_order_page;
    public $google2_site_key;
    public $google2_secret_key;
    public $google3_site_key;
    public $google3_secret_key;
    public $display_input_product;
    public $display_input_order;
    public static $definition = array(
        'table' => 'ets_livechat_ticket_form',
        'primary' => 'id_form',
        'multilang' => true,
        'fields' => array(
            'active' => array('type' => self::TYPE_INT),
            'id_shop' => array('type' => self::TYPE_INT),
            'mail_new_ticket' => array('type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'size' => 500),
            'custom_mail' => array('type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'size' => 500),
            'send_mail_to_customer' => array('type' => self::TYPE_INT),
            'send_mail_reply_customer' => array('type' => self::TYPE_INT),
            'send_mail_reply_admin' => array('type' => self::TYPE_INT),
            'send_mail_to_customer_customer_reply' => array('type' => self::TYPE_INT),
            'send_mail_to_admin_admin_reply' => array('type' => self::TYPE_INT),
            'send_from_email' => array('type' => self::TYPE_STRING),
            'send_from_name' => array('type' => self::TYPE_STRING),
            'customer_reply_upload_file' => array('type' => self::TYPE_INT),
            'allow_user_submit' => array('type' => self::TYPE_INT),
            'save_customer_file' => array('type' => self::TYPE_INT),
            'save_staff_file' => array('type' => self::TYPE_INT),
            'allow_staff_upload_file' => array('type' => self::TYPE_INT),
            'require_select_department' => array('type' => self::TYPE_INT),
            'departments' => array('type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'size' => 500),
            'allow_captcha' => array('type' => self::TYPE_INT),
            'customer_no_captcha' => array('type' => self::TYPE_INT),
            'default_priority' => array('type' => self::TYPE_INT),
            'deleted' => array('type' => self::TYPE_INT),
            'sort_order' => array('type' => self::TYPE_INT),
            'captcha_type' => array('type' => self::TYPE_STRING),
            'google2_site_key' => array('type' => self::TYPE_STRING),
            'google2_secret_key' => array('type' => self::TYPE_STRING),
            'google3_site_key' => array('type' => self::TYPE_STRING),
            'google3_secret_key' => array('type' => self::TYPE_STRING),
            'display_input_product' => array('type' => self::TYPE_INT),
            'display_input_order' => array('type' => self::TYPE_INT),
            // Lang fields
            'title' => array('type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isCleanHtml', 'size' => 500),
            'button_submit_label' => array('type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isCleanHtml', 'size' => 500),
            'button_link_contact_label' => array('type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isCleanHtml', 'size' => 500),
            'button_link_contact_label_on_order_page' => array('type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isCleanHtml', 'size' => 500),
            'description' => array('type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isCleanHtml', 'size' => 7000),
            'friendly_url' => array('type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isCleanHtml', 'size' => 7000),
            'meta_title' => array('type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isCleanHtml', 'size' => 700),
            'meta_description' => array('type' => self::TYPE_STRING, 'lang' => true, 'validate' => 'isCleanHtml', 'size' => 700),
            'meta_keywords' => array('type' => self::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml', 'size' => 900000),
        )
    );

    public function __construct($id_item = null, $id_lang = null, $id_shop = null)
    {
        parent::__construct($id_item, $id_lang, $id_shop);
    }
    public static function getInstance()
    {
        if (!isset(self::$instance)) {
            self::$instance = new LC_Ticket_form();
        }
        return self::$instance;
    }
    public function l($string)
    {
        return Translate::getModuleTranslation('ets_livechat', $string, pathinfo(__FILE__, PATHINFO_FILENAME));
    }
    public function add($autodate = true, $null_values = false)
    {
        $context = Context::getContext();
        $this->sort_order = 1 + Db::getInstance()->getValue('SELECT MAX(sort_order) FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form` WHERE id_shop=' . (int)$context->shop->id);
        return parent::add($autodate, $null_values);
    }

    public function delete()
    {
        $fileds = Db::getInstance()->executeS('SELECT id_field FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_field` WHERE id_form=' . (int)$this->id);
        if ($fileds) {
            foreach ($fileds as $filed) {
                $field_class = new LC_Ticket_field($filed['id_field']);
                $field_class->delete();
            }
        }
        return parent::delete();
    }

    public function duplicate()
    {
        $this->id = null;
        if ($this->add()) {
            return $this->id;
        }
        return false;
    }

    public function getEmailAdminInfo($id_departments)
    {
        if ($form_mails = explode(',', $this->mail_new_ticket)) {
            $mails_to = array();
            $names_to = array();
            if ($form_mails) {
                foreach ($form_mails as $form_mail) {

                    $employees = array();
                    if ($form_mail == 'all_employees') {
                        $employees = Db::getInstance()->executeS('SELECT * FROM `' . _DB_PREFIX_ . 'employee` WHERE active=1');

                    } elseif ($form_mail == 'supper_admins' && !in_array('all_employee', $form_mails)) {
                        $employees = Db::getInstance()->executeS('SELECT * FROM `' . _DB_PREFIX_ . 'employee` WHERE active=1 AND id_profile=1');
                    } elseif ($form_mail == 'department' && $id_departments && !in_array('all_employee', $form_mails)) {
                        $department = new LC_Departments($id_departments);
                        if ($department->all_employees) {
                            $employees = Db::getInstance()->executeS('SELECT * FROM `' . _DB_PREFIX_ . 'employee` WHERE active=1');
                        }
                        $employees = Db::getInstance()->executeS('
                            SELECT e.* FROM `' . _DB_PREFIX_ . 'employee` e
                            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_departments_employee` de ON (e.id_employee AND de.id_employee)
                            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_departments` d ON (d.id_departments=de.id_departments)
                            WHERE e.active=1 AND (d.id_departments ="' . (int)$id_departments . '" OR e.id_profile=1)
                        ');
                    } elseif ($form_mail == 'custom_emails' && $this->custom_mail && $custom_mails = explode(',', $this->custom_mail)) {
                        foreach ($custom_mails as $custom_mail) {
                            if (!in_array($custom_mail, $mails_to)) {
                                $mails_to[] = $custom_mail;
                                $names_to[] = Configuration::get('PS_SHOP_NAME');
                            }
                        }
                    }
                    if ($employees) {
                        foreach ($employees as $employee) {
                            if (!in_array($employee['email'], $mails_to)) {
                                $mails_to[] = $employee['email'];
                                $names_to[] = $employee['firstname'] . ' ' . $employee['lastname'];
                            }

                        }
                    }
                }
            }
            if ($mails_to) {
                return array(
                    'mails_to' => $mails_to,
                    'names_to' => $names_to
                );
            }

        }
        return false;
    }

    public function getDepartments()
    {
        if ($this->require_select_department && $this->departments && $form_departments = explode(',', $this->departments)) {
            if (in_array('all', $form_departments)) {
                $departments = Db::getInstance()->executeS('SELECT * FROM `' . _DB_PREFIX_ . 'ets_livechat_departments` WHERE status=1');
            } else
                $departments = Db::getInstance()->executeS('SELECT * FROM `' . _DB_PREFIX_ . 'ets_livechat_departments` WHERE id_departments IN (' . implode(',', array_map('intval', $form_departments)) . ') AND status=1');
            return $departments;
        }
        return false;
    }

    public function getFormFields()
    {
        if (!$this->id)
            return false;
        return Db::getInstance()->executeS("
            SELECT f.*, fl.label, fl.placeholder, fl.description, fl.options
            FROM `" . _DB_PREFIX_ . "ets_livechat_ticket_form_field` f 
            LEFT JOIN `" . _DB_PREFIX_ . "ets_livechat_ticket_form_field_lang` fl ON f.id_field=fl.id_field AND fl.id_lang=" . (int)Context::getContext()->language->id . "
            WHERE f.id_form=" . (int)$this->id . " AND f.deleted=0
            ORDER BY f.position ASC
        ");
    }

    public static function getForm($id_form = null, $alias = null)
    {
        if (!$id_form && !$alias)
            return false;
        return Db::getInstance()->getRow("
            SELECT f.*, fl.title,fl.description,fl.button_submit_label,fl.friendly_url,fl.meta_title,fl.meta_description,fl.meta_keywords
            FROM `" . _DB_PREFIX_ . "ets_livechat_ticket_form` f 
            LEFT JOIN `" . _DB_PREFIX_ . "ets_livechat_ticket_form_lang` fl ON f.id_form=fl.id_form AND fl.id_lang=" . (int)Context::getContext()->language->id . "
            WHERE f.deleted=0 AND f.id_shop=" . (int)Context::getContext()->shop->id . ($id_form ? " AND f.id_form=" . (int)$id_form : "") . ($alias ? " AND fl.friendly_url='" . pSQL($alias) . "'" : "") . "
        ");
    }

    public static function getForms($active = true, $count = false, $start = null, $limit = null, $excludedLiveChatForm = true,$checkLogin=false)
    {
        $context = Context::getContext();
        if ($count) {
            return (int)Db::getInstance()->getValue("
                SELECT count(*)
                FROM `" . _DB_PREFIX_ . "ets_livechat_ticket_form` 
                WHERE deleted=0 AND id_shop=" . (int)$context->shop->id . ($active ? " active=1" : "") . "
            ");
        }
        if ($start && $start < 0)
            $start = 0;
        if ($limit && $limit < 1)
            $limit = 10;
        $forms= Db::getInstance()->executeS("
            SELECT f.*, fl.title,fl.description,fl.button_submit_label,fl.friendly_url,fl.meta_title,fl.meta_description,fl.meta_keywords
            FROM `" . _DB_PREFIX_ . "ets_livechat_ticket_form` f 
            LEFT JOIN `" . _DB_PREFIX_ . "ets_livechat_ticket_form_lang` fl ON f.id_form=fl.id_form AND fl.id_lang=" . (int)Context::getContext()->language->id . "
            WHERE f.deleted=0 AND f.id_shop=" . (int)$context->shop->id . ($active ? " AND f.active=1" : "") . ($excludedLiveChatForm ? " AND f.id_form!=1" : "").($checkLogin ? ' AND allow_user_submit=1':''). (!is_null($start) && $limit ? " LIMIT " . (int)$start . "," . (int)$limit : "").' ORDER BY f.sort_order asc'
        );
        if($active  && $forms)
        {
            foreach ($forms as $key=> $form)
            {
                if(!Db::getInstance()->getRow('SELECT * FROM `'._DB_PREFIX_.'ets_livechat_ticket_form_field` WHERE id_form='.(int)$form['id_form'].' AND deleted=0'))
                    unset($forms[$key]);
            }
        }
        return $forms;
    }

    public static function getOrderByRef($orderRef, $id_customer = null)
    {
        if (($id_order = Db::getInstance()->getValue('
            SELECT id_order
            FROM `' . _DB_PREFIX_ . 'orders` 
            WHERE 1 ' . ($id_customer ? ' AND id_customer=' . (int)$id_customer : '') . ' AND reference="' . pSQL($orderRef) . '" AND id_shop=' . (int)Context::getContext()->shop->id))
            && ($order = new Order($id_order)) && $order->id
        )
            return $order;
        return false;
    }

    public function renderHtmlForm($id_conversation = 0, $admin = false,$post_fields=array())
    {
        if (!$this->id)
            return '';
        $context = Context::getContext();
        $fields = $this->getFormFields();
        $is_customer_email = false;
        $is_customer_name = false;
        $is_customer_phone_number = false;
        $search_customer = false;
        if (isset($post_fields['id_customer']) && ($idCustomer = (int)$post_fields['id_customer'])) {
            $customerObj = new Customer($idCustomer);
        } else
            $customerObj = false;
        if ($fields) {
            foreach ($fields as &$field) {
                if ($field['options']) {
                    $options = explode("\n", $field['options']);
                    $field['options'] = array();
                    if ($options) {
                        foreach ($options as $option) {
                            $options_values = explode('|', $option);
                            if ($options_values) {
                                if (isset($options_values[1])) {
                                    $label = trim($options_values[0]);
                                    $values = explode(':', trim($options_values[1]));
                                    if (isset($values[1]) && trim($values[1]) == 'default') {
                                        $value = $values[0];
                                        $is_default = true;
                                    } else {
                                        $value = $options_values[1];
                                        $is_default = false;
                                    }
                                } else {
                                    $values = explode(':', trim($options_values[0]));
                                    if (isset($values[1]) && trim($values[1]) == 'default') {
                                        $value = $values[0];
                                        $is_default = true;
                                    } else {
                                        $value = $options_values[0];
                                        $is_default = false;
                                    }
                                    $label = $value;
                                }
                            }
                            if($field['type']=='checkbox')
                            {
                                if ($is_default)
                                {
                                    if(!Tools::isSubmit('submit_send_ticket'))
                                    {
                                        if(!isset($post_fields[$field['id_field']]))
                                        {
                                            $post_fields[$field['id_field']] = array();
                                        }
                                        $post_fields[$field['id_field']][] = $value;
                                    }

                                }
                            }
                            else
                            {
                                if ($is_default && !isset($post_fields[$field['id_field']]))
                                    $post_fields[$field['id_field']] = $value;
                            }

                            $field['options'][] = array(
                                'is_default' => $is_default,
                                'label' => $label,
                                'value' => $value,
                            );
                        }
                    }
                }
                if (isset($context->customer) && $context->customer->isLogged()) {
                    if ($field['is_contact_mail'] && !$is_customer_email) {
                        $field['value'] = $context->customer->email;
                        $is_customer_email = true;
                    }
                    if ($field['is_contact_name'] && !$is_customer_name) {
                        $field['value'] = $context->customer->firstname . ' ' . $context->customer->lastname;
                        $is_customer_name = true;
                    }
                    if ($field['is_customer_phone_number'] && !$is_customer_phone_number) {
                        $addresses = $context->customer->getAddresses($context->language->id);
                        if ($addresses) {
                            $field['value'] = $addresses[0]['phone'] ? $addresses[0]['phone'] : $addresses[0]['phone_mobile'];
                            $is_customer_phone_number = true;
                        }
                    }
                } elseif ($id_conversation) {
                    $conversation = new LC_Conversation($id_conversation);
                    if ($conversation->id_customer) {
                        $customer = new Customer($conversation->id_customer);
                        $customer_email = $customer->email;
                        $customer_name = $customer->firstname . ' ' . $customer->lastname;
                    } else {
                        $customer_email = $conversation->customer_email;
                        $customer_name = $conversation->customer_name;
                    }
                    if ($field['is_contact_mail'] && !$is_customer_email) {
                        $field['value'] = $customer_email;
                        $is_customer_email = true;
                    }
                    if ($field['is_contact_name'] && !$is_customer_name) {
                        $field['value'] = $customer_name;
                        $is_customer_name = true;
                    }
                } elseif ($admin) {

                    if (!$this->allow_user_submit) {
                        if ($field['is_contact_mail'] && !$is_customer_email) {
                            $field['readonly'] = true;
                            $is_customer_email = true;
                        }

                        if ($field['is_contact_name'] && !$is_customer_name) {
                            $field['readonly'] = true;
                            $is_customer_name = true;
                        }
                        if ($field['is_customer_phone_number'] && !$is_customer_phone_number) {
                            $field['readonly'] = true;
                            $is_customer_phone_number = true;
                        }
                        $search_customer = true;
                    } elseif (isset($post_fields['id_customer_ticket']) && $id_customer = $post_fields['id_customer_ticket']) {
                        $customer = new Customer($id_customer);
                        if ($field['is_contact_mail'] && !$is_customer_email && $customer->email) {
                            $field['readonly'] = true;
                            $is_customer_email = true;
                            if ($customerObj)
                                $field['value'] = $customerObj->email;
                        }
                        if ($field['is_contact_name'] && !$is_customer_name && $customer->firstname) {
                            $field['readonly'] = true;
                            $is_customer_name = true;
                            if ($customerObj)
                                $field['value'] = $customerObj->firstname . ' ' . $customer->lastname;
                        }
                        if ($field['is_customer_phone_number'] && !$is_customer_phone_number) {
                            $addresses = $customer->getAddresses($context->language->id);
                            if ($addresses) {
                                $field['readonly'] = true;
                                $is_customer_phone_number = true;
                                if ($customerObj)
                                    $field['value'] = $addresses[0]['phone'] ? $addresses[0]['phone'] : $addresses[0]['phone_mobile'];
                            }
                        }
                    }
                    if ($field['is_contact_mail'] || $field['is_contact_name'] || $field['is_customer_phone_number']) {
                        $search_customer = true;
                    }
                }
            }
        }
        if ($this->allow_captcha && ((!$admin && isset($context->customer) && !$context->customer->logged) || !$this->customer_no_captcha)) {
            $allow_captcha = true;
            if ($this->captcha_type == 'image') {
                $captchaUrl = $context->link->getModuleLink('ets_livechat', 'captcha', array('rand' => time(), 'id_form' => $this->id));
                $captcha = $context->link->getModuleLink('ets_livechat', 'captcha', array('init' => 'ok', 'id_form' => $this->id));
            }
        }
        if ($admin) {
            $forms = LC_Ticket_Form::getForms();
            if ($forms) {
                foreach ($forms as &$item) {
                    $item['link'] = $context->link->getAdminLink('AdminLiveChatTickets') . '&addticket&id_form=' . $item['id_form'];
                }
            }
        }
        $employees = Db::getInstance()->executeS(
            'SELECT e.*,d.id_departments,s.name,s.avata,IFNULL(s.status,1) as status
            FROM `' . _DB_PREFIX_ . 'employee` e
            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_departments_employee` de ON (de.id_employee=e.id_employee)
            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_departments` d ON (d.id_departments = de.id_departments)
            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_staff` s ON (s.id_employee=e.id_employee)
            WHERE e.active=1 AND (s.status is null OR s.status=1) GROUP BY e.id_employee');
        if ($employees) {
            foreach ($employees as &$employee) {
                $employe_departments = Db::getInstance()->executeS('SELECT * FROM `' . _DB_PREFIX_ . 'ets_livechat_departments_employee` WHERE id_employee=' . (int)$employee['id_employee']);
                $employee['departments'] = $employe_departments;
            }
        }
        if (isset($post_fields['order_ref']) &&  ($orderRef = $post_fields['order_ref']) && preg_match('/^[a-zA-Z0-9]{4,10}$/', $orderRef) && isset($context->customer) && $context->customer->isLogged())
            $order = LC_Ticket_Form::getOrderByRef($orderRef, (int)$context->customer->id);
        $product_ref = isset($post_fields['id_product_ref']) &&  ($id_product = (int)$post_fields['id_product_ref']) && ($product = new Product($id_product, false, $context->language->id)) && Validate::isLoadedObject($product) ? $product : null;
        $logged = isset($context->customer) && $context->customer->isLogged();
        $context->smarty->assign(
            array(
                'fields' => $fields,
                'post_fields' => $post_fields,
                'id_form' => $this->id,
                'form' => $this,
                'admin' => $admin,
                'forms' => $admin && isset($forms) && $forms ? $forms : false,
                'new_ticket_link' => $admin && isset($forms) && Count($forms) == 1 ? $forms[0]['link'] : false,
                'search_customer' => $search_customer || $admin,
                'backend' => $id_conversation ? true : false,
                'conversation' => $id_conversation ? new LC_Conversation($id_conversation) : false,
                'captchaUrl' => isset($captchaUrl) ? $captchaUrl : false,
                'captcha' => isset($captcha) ? $captcha : false,
                'allow_captcha' => isset($allow_captcha) ? $allow_captcha : false,
                'departments' => $this->getDepartments(),
                'employees' => $employees,
                'logged' => $logged,
                'link_action' => $context->link->getModuleLink(Ets_livechat::getInstance()->name, 'form', array('id_form' => $this->id)),
                'product_ref' => $product_ref,
                'product_image' => $product_ref ? $this->getProductImage($product_ref->id) : '',
                'order_ref' => isset($order) && $order ? $order->reference : null,
                'customer_orders' => $this->display_input_order && $logged ? $this->getListOrders():false,
                'order_link' => isset($order) && $order ? $context->link->getPageLink('order-detail', true, $context->language->id, array('id_order' => $order->id)) : null,
                'moduleID' => Module::getInstanceByName('ets_livechat')->id,
            )
        );
        return $context->smarty->fetch(_PS_MODULE_DIR_ . Ets_livechat::getInstance()->name . '/views/templates/hook/form_html.tpl');
    }
    public function getListOrders()
    {
        return Db::getInstance()->executeS('SELECT reference FROM `'._DB_PREFIX_.'orders` WHERE id_customer='.(int)Context::getContext()->customer->id);
    }
    public static function getListFormInProductPage()
    {
        $sql = 'SELECT f.id_form,fl.title,fl.button_link_contact_label as button_label FROM `'._DB_PREFIX_.'ets_livechat_ticket_form` f
        LEFT JOIN `'._DB_PREFIX_.'ets_livechat_ticket_form_lang` fl ON (f.id_form=fl.id_form AND fl.id_lang="'.(int)Context::getContext()->language->id.'")
        WHERE f.id_form > 1 AND f.id_shop="'.(int)Context::getContext()->shop->id.'" AND f.display_input_product=1';
        return Db::getInstance()->executeS($sql);
    }
    public static function getListFormInOrderPage()
    {
        $sql = 'SELECT f.id_form,fl.title,fl.button_link_contact_label_on_order_page as button_label FROM `'._DB_PREFIX_.'ets_livechat_ticket_form` f
        LEFT JOIN `'._DB_PREFIX_.'ets_livechat_ticket_form_lang` fl ON (f.id_form=fl.id_form AND fl.id_lang="'.(int)Context::getContext()->language->id.'")
        WHERE f.id_form > 1 AND f.id_shop="'.(int)Context::getContext()->shop->id.'" AND f.display_input_order=1';
        return Db::getInstance()->executeS($sql);
    }
    public function getProductImage($id_product)
    {
        $image = false;
        $context = Context::getContext();
        if (Module::isEnabled('ets_customfields')) {
            if (($czfProduct = self::getCzfProductByProductId($id_product, $context->language->id)) && $czfProduct['logo']) {
                $image = $context->link->getMediaLink(_PS_IMG_ . '../' . $czfProduct['logo']);;
                return $image;
            }
        }
        if (version_compare(_PS_VERSION_, '1.7', '>='))
            $type_image = ImageType::getFormattedName('small');
        else
            $type_image = ImageType::getFormatedName('small');
        if (!$image) {
            $sql = 'SELECT i.id_image FROM `' . _DB_PREFIX_ . 'image` i';
            $sql .= ' WHERE i.id_product="' . (int)$id_product . '"';
            if (!$image = Db::getInstance()->getRow($sql . ' AND i.cover=1')) {
                $image = Db::getInstance()->getRow($sql);
            }
            if ($image) {
                $product_class = new Product($id_product, false, Context::getContext()->language->id);

                return $context->link->getImageLink($product_class->link_rewrite, $image['id_image'], $type_image);
            }
        }
        if (file_exists(_PS_PROD_IMG_DIR_ . $context->language->iso_code . '-default-' . $type_image . '.jpg'))
            return $context->link->getMediaLink(_PS_PROD_IMG_ . $context->language->iso_code . '-default-' . $type_image . '.jpg');
        else {
            $langDefault = new Language(Configuration::get('PS_LANG_DEFAULT'));
            if (file_exists(_PS_PROD_IMG_DIR_ . $langDefault->iso_code . '-default-' . $type_image . '.jpg'))
                return $context->link->getMediaLink(_PS_PROD_IMG_ . $langDefault->iso_code . '-default-' . $type_image . '.jpg');
        }
        return '';
    }

    public static function getCzfProductByProductId($idProduct, $idLang = null)
    {
        $sql = "SELECT cp.logo
                FROM `" . _DB_PREFIX_ . "ets_czf_product` cp 
                WHERE cp.id_product =" . (int)$idProduct;
        if ($idLang) {
            return Db::getInstance()->getRow($sql);
        }
        return false;
    }

    public static function getIdFormByFriendlyUrl($friendly_url,$all_lang = false)
    {
        return (int)Db::getInstance()->getValue('SELECT id_form FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_lang` WHERE friendly_url ="' . pSQL($friendly_url).'"' . (!$all_lang ? ' AND id_lang="' . (int)Context::getContext()->language->id . '"':''));
    }
    public static function getListFields($id_form)
    {
        $sql = 'SELECT * FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_field` f
                LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_field_lang` fl ON (f.id_field = fl.id_field AND fl.id_lang="' . (int)Context::getContext()->language->id . '")
                WHERE f.id_form=' . (int)$id_form . ' AND f.deleted=0 ORDER BY f.position ASC';
        return Db::getInstance()->executeS($sql);
    }
    public function setConfigForm($id_form=0)
    {
        $deparments = array(
            array(
                'id' => 'all',
                'label' => $this->l('All'),
            ),
        );
        if (LC_Base::checkVesionModule()) {
            $list_departments = LC_Departments::getAllDepartments(false);
            if ($list_departments) {
                foreach ($list_departments as $value) {
                    $deparments[] = array(
                        'id' => $value['id_departments'],
                        'label' => $value['name'],
                    );
                }
            }
        }
        return array(
            array(
                'type' => 'text',
                'label' => $this->l('Form title'),
                'name' => 'title',
                'lang' => true,
                'required' => true,
                'hint' => $this->l('Invalid characters:') . '[^<>;=#{}]',
                'validate' => 'isCatalogName',
                'form_group_class' => 'ticket info change_form',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Friendly URL'),
                'name' => 'friendly_url',
                'lang' => true,
                'form_group_class' => 'ticket info change_form',
                'validate' => 'isLinkRewrite',
                'desc' => $id_form ? Module::getInstanceByName('ets_livechat')->getAllLinkContactForm($id_form) : Module::getInstanceByName('ets_livechat')->displayText('', 'a', 'link_form_support', array('target' => '_blank', 'href' => '#')),
            ),
            array(
                'type' => 'textarea',
                'label' => $this->l('Description'),
                'name' => 'description',
                'lang' => true,
                'validate' => 'isCleanHtml',
                'form_group_class' => 'ticket info change_form',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Meta title'),
                'name' => 'meta_title',
                'lang' => true,
                'validate' => 'isCleanHtml',
                'form_group_class' => 'ticket info change_form',
            ),
            array(
                'type' => 'textarea',
                'label' => $this->l('Meta description'),
                'name' => 'meta_description',
                'lang' => true,
                'cols' => 20,
                'validate' => 'isCleanHtml',
                'form_group_class' => 'ticket info change_form',
            ),
            array(
                'type' => 'tags',
                'label' => $this->l('Meta keywords'),
                'name' => 'meta_keywords',
                'lang' => true,
                'validate' => 'isCleanHtml',
                'form_group_class' => 'ticket info change_form',
            ),
            array(
                'type' => 'switch',
                'label' => $this->l('Active'),
                'name' => 'active',
                'values' => array(
                    array(
                        'id' => 'active_on',
                        'value' => 1,
                        'label' => $this->l('Yes')
                    ),
                    array(
                        'id' => 'active_off',
                        'value' => 0,
                        'label' => $this->l('No')
                    )
                ),
                'default' => 1,
                'validate' => 'isInt',
                'form_group_class' => 'ticket info change_form field-private',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Send from email'),
                'name' => 'send_from_email',
                'form_group_class' => 'ticket email change_form',
                'validate' => 'isEmail',
                'desc' => Configuration::get('PS_MAIL_USER') && Configuration::get('PS_MAIL_METHOD') == 2 ? $this->l('*Note: custom "From email" doesn\'t support Gmail smtp service as Gmail forces "From email" to your SMTP username ') . '(' . Configuration::get('PS_MAIL_USER') . ')' : '',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Send from name'),
                'name' => 'send_from_name',
                'validate' => 'isCleanHtml',
                'form_group_class' => 'ticket email change_form',
            ),
            array(
                'type' => 'checkbox',
                'label' => $this->l('Who to send email notification when a new ticket arrived?'),
                'name' => 'mail_new_ticket',
                'validate' => 'isCleanHtml',
                'values' => array(
                    'query' => array(
                        array(
                            'id' => 'supper_admins',
                            'label' => $this->l('Super admins'),
                        ),
                        array(
                            'id' => 'all_employees',
                            'label' => $this->l('All employees'),
                        ),
                        array(
                            'id' => 'department',
                            'label' => $this->l('All employees in the associated department'),
                        ),
                        array(
                            'id' => 'custom_emails',
                            'label' => $this->l('Custom emails'),
                        )
                    ),
                    'id' => 'id',
                    'name' => 'label',
                ),
                'default' => 'supper_admins',
                'form_group_class' => 'ticket email change_form',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Custom emails'),
                'name' => 'custom_mail',
                'form_group_class' => 'ticket email change_form custom_email',
                'validate' => 'isCleanHtml',
                'desc' => $this->l('Enter email separated by a comma (,)'),
            ),
            array(
                'type' => 'switch',
                'label' => $this->l('Send a confirmation email to customer when ticket is submitted?'),
                'name' => 'send_mail_to_customer',
                'values' => array(
                    array(
                        'id' => 'active_on',
                        'value' => 1,
                        'label' => $this->l('Yes')
                    ),
                    array(
                        'id' => 'active_off',
                        'value' => 0,
                        'label' => $this->l('No')
                    )
                ),
                'default' => 1,
                'validate' => 'isInt',
                'form_group_class' => 'ticket email change_form',
            ),
            array(
                'type' => 'switch',
                'label' => $this->l('Send email to customer when admin reply to their ticket?'),
                'name' => 'send_mail_reply_customer',
                'values' => array(
                    array(
                        'id' => 'active_on',
                        'value' => 1,
                        'label' => $this->l('Yes')
                    ),
                    array(
                        'id' => 'active_off',
                        'value' => 0,
                        'label' => $this->l('No')
                    )
                ),
                'form_group_class' => 'ticket email change_form',
                'validate' => 'isInt',
                'default' => 1,
            ),
            array(
                'type' => 'switch',
                'label' => $this->l('Send email to customer when they successfully replied?'),
                'name' => 'send_mail_to_customer_customer_reply',
                'values' => array(
                    array(
                        'id' => 'active_on',
                        'value' => 1,
                        'label' => $this->l('Yes')
                    ),
                    array(
                        'id' => 'active_off',
                        'value' => 0,
                        'label' => $this->l('No')
                    )
                ),
                'form_group_class' => 'ticket email change_form',
                'validate' => 'isInt',
                'default' => 1,
            ),
            array(
                'type' => 'switch',
                'label' => $this->l('Send email to admin when customer reply to a ticket?'),
                'name' => 'send_mail_reply_admin',
                'values' => array(
                    array(
                        'id' => 'active_on',
                        'value' => 1,
                        'label' => $this->l('Yes')
                    ),
                    array(
                        'id' => 'active_off',
                        'value' => 0,
                        'label' => $this->l('No')
                    )
                ),
                'default' => 1,
                'validate' => 'isInt',
                'form_group_class' => 'ticket email change_form',
            ),
            array(
                'type' => 'switch',
                'label' => $this->l('Send email to admin when they successfully replied?'),
                'name' => 'send_mail_to_admin_admin_reply',
                'values' => array(
                    array(
                        'id' => 'active_on',
                        'value' => 1,
                        'label' => $this->l('Yes')
                    ),
                    array(
                        'id' => 'active_off',
                        'value' => 0,
                        'label' => $this->l('No')
                    )
                ),
                'default' => 1,
                'validate' => 'isInt',
                'form_group_class' => 'ticket email change_form',
            ),
            array(
                'type' => 'switch',
                'label' => $this->l('Allow unregistered users to submit ticket?'),
                'name' => 'allow_user_submit',
                'values' => array(
                    array(
                        'id' => 'active_on',
                        'value' => 1,
                        'label' => $this->l('Yes')
                    ),
                    array(
                        'id' => 'active_off',
                        'value' => 0,
                        'label' => $this->l('No')
                    )
                ),
                'default' => 1,
                'validate' => 'isInt',
                'form_group_class' => 'ticket general change_form',
            ),
            array(
                'type' => 'switch',
                'label' => $this->l('Allow staff to upload file?'),
                'name' => 'allow_staff_upload_file',
                'validate' => 'isInt',
                'values' => array(
                    array(
                        'id' => 'active_on',
                        'value' => 1,
                        'label' => $this->l('Yes')
                    ),
                    array(
                        'id' => 'active_off',
                        'value' => 0,
                        'label' => $this->l('No')
                    )
                ),
                'default' => 1,
                'form_group_class' => 'ticket general change_form',
            ),
            array(
                'type' => 'switch',
                'label' => $this->l('Save staff\'s upload file?'),
                'name' => 'save_staff_file',
                'values' => array(
                    array(
                        'id' => 'active_on',
                        'value' => 1,
                        'label' => $this->l('Yes')
                    ),
                    array(
                        'id' => 'active_off',
                        'value' => 0,
                        'label' => $this->l('No')
                    )
                ),
                'default' => 1,
                'form_group_class' => 'ticket general change_form',
                'validate' => 'isInt',
                'desc' => $this->l('Enable this to save staff\'s upload file on the server. Otherwise the upload file will only be sent to customer via email.'),
            ),
            array(
                'type' => 'switch',
                'label' => $this->l('Save customer\'s upload file?'),
                'name' => 'save_customer_file',
                'values' => array(
                    array(
                        'id' => 'active_on',
                        'value' => 1,
                        'label' => $this->l('Yes')
                    ),
                    array(
                        'id' => 'active_off',
                        'value' => 0,
                        'label' => $this->l('No')
                    )
                ),
                'default' => 1,
                'form_group_class' => 'ticket general change_form',
                'validate' => 'isInt',
                'desc' => $this->l('Enable this to save customer\'s upload file on the server. Otherwise the upload file will only be sent to admin via email.'),
            ),
            array(
                'type' => 'switch',
                'label' => $this->l('Allow customer to attach file when reply to a ticket'),
                'name' => 'customer_reply_upload_file',
                'values' => array(
                    array(
                        'id' => 'active_on',
                        'value' => 1,
                        'label' => $this->l('Yes')
                    ),
                    array(
                        'id' => 'active_off',
                        'value' => 0,
                        'label' => $this->l('No')
                    )
                ),
                'default' => 1,
                'validate' => 'isInt',
                'form_group_class' => 'ticket general change_form',
            ),
            array(
                'type' => 'switch',
                'label' => $this->l('Require customer to select a department before submitting a ticket?'),
                'name' => 'require_select_department',
                'validate' => 'isInt',
                'values' => array(
                    array(
                        'id' => 'active_on',
                        'value' => 1,
                        'label' => $this->l('Yes')
                    ),
                    array(
                        'id' => 'active_off',
                        'value' => 0,
                        'label' => $this->l('No')
                    )
                ),
                'default' => 1,
                'form_group_class' => 'ticket general change_form',
            ),
            array(
                'type' => 'checkbox',
                'label' => $this->l('Associated departments'),
                'name' => 'departments',
                'values' => array(
                    'query' => $deparments,
                    'id' => 'id',
                    'name' => 'label',
                ),
                'default' => 'all',
                'validate' => 'isCleanHtml',
                'form_group_class' => 'ticket general change_form departments',
                'desc' => $this->l('Select the departments who can solve the tickets generated from this form together'),
            ),
            array(
                'type' => 'switch',
                'label' => $this->l('Enable CAPTCHA protection?'),
                'name' => 'allow_captcha',
                'validate' => 'isInt',
                'values' => array(
                    array(
                        'id' => 'active_on',
                        'value' => 1,
                        'label' => $this->l('Yes')
                    ),
                    array(
                        'id' => 'active_off',
                        'value' => 0,
                        'label' => $this->l('No')
                    )
                ),
                'form_group_class' => 'ticket general change_form',
            ),
            array(
                'type' => 'switch',
                'label' => $this->l('Do not require registered user to enter captcha code'),
                'name' => 'customer_no_captcha',
                'validate' => 'isInt',
                'values' => array(
                    array(
                        'id' => 'active_on',
                        'value' => 1,
                        'label' => $this->l('Yes')
                    ),
                    array(
                        'id' => 'active_off',
                        'value' => 0,
                        'label' => $this->l('No')
                    )
                ),
                'default' => 1,
                'form_group_class' => 'ticket general change_form customer_no_captcha',
            ),
            array(
                'type' => 'select',
                'label' => $this->l('Captcha type'),
                'name' => 'captcha_type',
                'options' => array(
                    'query' => array(
                        array(
                            'id_option' => 'image',
                            'name' => $this->l('Image captcha')
                        ),
                        array(
                            'id_option' => 'google-v2',
                            'name' => $this->l('Google reCAPTCHA v2')
                        ),
                        array(
                            'id_option' => 'google-v3',
                            'name' => $this->l('Google reCAPTCHA v3')
                        ),
                    ),
                    'id' => 'id_option',
                    'name' => 'name'
                ),
                'default' => 'image',
                'validate' => 'isCleanHtml',
                'form_group_class' => 'ticket general change_form customer_no_captcha',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Site key'),
                'name' => 'google2_site_key',
                'form_group_class' => 'ticket general change_form customer_no_captcha captcha google-v2',
                'validate' => 'isCleanHtml',
                'required2' => true,
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Secret key'),
                'name' => 'google2_secret_key',
                'form_group_class' => 'ticket general change_form customer_no_captcha captcha google-v2',
                'required2' => true,
                'validate' => 'isCleanHtml',
                'desc' => Module::getInstanceByName('ets_livechat')->displayText($this->l('Get Site key and Secret key for reCAPTCHA v2'), 'a', '', array('target' => '_blank', 'href' => 'https://www.google.com/recaptcha/admin/create','rel'=>'noreferrer noopener')),
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Site key'),
                'name' => 'google3_site_key',
                'form_group_class' => 'ticket general change_form customer_no_captcha captcha google-v3',
                'validate' => 'isCleanHtml',
                'required2' => true,
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Secret key'),
                'name' => 'google3_secret_key',
                'form_group_class' => 'ticket general change_form customer_no_captcha captcha google-v3',
                'required2' => true,
                'validate' => 'isCleanHtml',
                'desc' => Module::getInstanceByName('ets_livechat')->displayText($this->l('Get Site key and Secret key for reCAPTCHA v3'), 'a', '', array('target' => '_blank', 'href' => 'https://www.google.com/recaptcha/admin/create','rel'=>'noreferrer noopener')),
            ),
            array(
                'type' => 'select',
                'label' => $this->l('Default priority'),
                'name' => 'default_priority',
                'options' => array(
                    'query' => array(
                        array(
                            'id_option' => '1',
                            'name' => $this->l('Low')
                        ),
                        array(
                            'id_option' => '2',
                            'name' => $this->l('Medium')
                        ),
                        array(
                            'id_option' => '3',
                            'name' => $this->l('High')
                        ),
                        array(
                            'id_option' => '4',
                            'name' => $this->l('Urgent')
                        ),
                    ),
                    'id' => 'id_option',
                    'name' => 'name'
                ),
                'default' => '2',
                'validate' => 'isInt',
                'form_group_class' => 'ticket general change_form',
            ),
            array(
                'type' => 'switch',
                'label' => $this->l('Display related product on the support form'),
                'name' => 'display_input_product',
                'values' => array(
                    array(
                        'id' => 'display_input_product_on',
                        'value' => 1,
                        'label' => $this->l('Yes')
                    ),
                    array(
                        'id' => 'display_input_product_off',
                        'value' => 0,
                        'label' => $this->l('No')
                    )
                ),
                'default' => 0,
                'form_group_class' => 'ticket general change_form',
                'validate' => 'isInt',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Contact button on product page'),
                'name' => 'button_link_contact_label',
                'lang' => true,
                'form_group_class' => 'ticket general change_form',
                'validate' => 'isCleanHtml',
                'desc' => $this->l('Leave blank to use the default title'),
            ),
            array(
                'type' => 'switch',
                'label' => $this->l('Display order reference on support form'),
                'name' => 'display_input_order',
                'values' => array(
                    array(
                        'id' => 'display_input_order_on',
                        'value' => 1,
                        'label' => $this->l('Yes')
                    ),
                    array(
                        'id' => 'display_input_order_off',
                        'value' => 0,
                        'label' => $this->l('No')
                    )
                ),
                'default' => 0,
                'form_group_class' => 'ticket general change_form',
                'validate' => 'isInt',
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Contact button on order page'),
                'name' => 'button_link_contact_label_on_order_page',
                'lang' => true,
                'form_group_class' => 'ticket general change_form',
                'validate' => 'isCleanHtml',
                'desc' => $this->l('Leave blank to use the default title'),
            ),
            array(
                'type' => 'text',
                'label' => $this->l('Submit button label'),
                'name' => 'button_submit_label',
                'default' => $this->l('Submit'),
                'default_lang' => 'Submit',
                'lang' => 1,
                'validate' => 'isCleanHtml',
                'form_group_class' => 'ticket general change_form',
            ),
            array(
                'type' => 'hidden',
                'name' => 'id_form',
            )
        );
    }
}