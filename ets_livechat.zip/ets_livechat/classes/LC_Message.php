<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) { exit; }

class LC_Message extends ObjectModel
{
    public $id_conversation;
    public $id_employee;
    public $delivered;
    public $message;
    public $id_product;
    public $type_attachment;
    public $name_attachment;
    public $datetime_added;
    public $datetime_edited;
    public static $definition = array(
        'table' => 'ets_livechat_message',
        'primary' => 'id_message',
        'fields' => array(
            'id_conversation' => array('type' => self::TYPE_INT),
            'id_employee' => array('type' => self::TYPE_INT),
            'id_product' => array('type' => self::TYPE_INT),
            'delivered' => array('type' => self::TYPE_INT),
            'message' => array('type' => self::TYPE_HTML),
            'type_attachment' => array('type' => self::TYPE_STRING),
            'name_attachment' => array('type' => self::TYPE_STRING),
            'datetime_added' => array('type' => self::TYPE_DATE),
            'datetime_edited' => array('type' => self::TYPE_DATE),
        )
    );
    public static function getMessages($id_conversation, $latestID = 0, $limit = 0, $orderType = 'DESC', $extraID = 0)
    {
        $context = Context::getContext();
        $conversation = new LC_Conversation($id_conversation);
        $ets_livechat = Module::getInstanceByName('ets_livechat');
        if (isset($context->employee->id) && $context->employee->id && !LC_Conversation::checkConversationEmployee($conversation, $context->employee->id))
            return array();
        if (isset($context->employee) && $context->employee->id)
            $admin = true;
        else
            $admin = false;
        if ($latestID <= 0)
            $latestID = 0;
        else {
            if (Db::getInstance()->executeS('SELECT id_message FROM `' . _DB_PREFIX_ . 'ets_livechat_message` where id_message>' . (int)$latestID)) {
                $latestID--;
                if ($limit)
                    $limit++;
            }
        }
        $ets_livechat = new Ets_livechat();
        $messages = Db::getInstance()->executeS("
            SELECT s.name,m.*,CONCAT(e.firstname,' ',e.lastname) as employee_name,IF(c.id_customer,CONCAT(cu.firstname,' ',cu.lastname),c.customer_name) as customer_name,e.email as employee_email,IF(c.id_customer,cu.email,c.customer_email) as customer_email
            FROM `" . _DB_PREFIX_ . "ets_livechat_message` m
            LEFT JOIN `" . _DB_PREFIX_ . "employee` e ON m.id_employee=e.id_employee  
            LEFT JOIN `" . _DB_PREFIX_ . "ets_livechat_staff` s ON s.id_employee=m.id_employee
            JOIN `" . _DB_PREFIX_ . "ets_livechat_conversation` c ON m.id_conversation=c.id_conversation
            LEFT JOIN `" . _DB_PREFIX_ . "customer` cu ON c.id_customer=cu.id_customer
            WHERE c.id_conversation=" . (int)$id_conversation
            . ($latestID ? " AND m.id_message > " . (int)$latestID : "")
            . ($extraID ? " AND m.id_message !='" . (int)$extraID . "'" : "")
            . " ORDER BY m.id_message " . (in_array($orderType, array('ASC', 'DESC')) ? pSQL($orderType) : 'DESC') . "
            " . ($limit > 0 ? "LIMIT 0," . (int)$limit : ""));
        if ($messages) {
            foreach ($messages as $index => &$message) {
                if (version_compare(_PS_VERSION_, '1.6', '>=')) {
                    $message['message'] = Ets_livechat::replace_link($message['message']);
                }
                if ($ets_livechat->emotions) {
                    foreach ($ets_livechat->emotions as $key => $emotion) {
                        $img = Module::getInstanceByName('ets_livechat')->displayText(Module::getInstanceByName('ets_livechat')->displayText('', 'img', '', array('src' => ($admin ? _MODULE_DIR_ . 'ets_livechat/views/img/emotions/' . $emotion['img'] : Context::getContext()->link->getMediaLink(_MODULE_DIR_ . 'ets_livechat/views/img/emotions/' . $emotion['img'])))), 'span', '', array('title' => $emotion['title']));
                        $message['message'] = str_replace(array(Tools::strtolower($key), $key), array($img, $img), $message['message']);
                    }
                }
                if ($message['datetime_edited'] != $message['datetime_added'])
                    $message['edited'] = 1;
                else
                    $message['edited'] = 0;
                if (date('Y-m-d') == date('Y-m-d', strtotime($message['datetime_added']))) {
                    $message['datetime_added'] = date('h:i A', strtotime($message['datetime_added']));
                } else {
                    if (date('Y') == date('Y', strtotime($message['datetime_added']))) {
                        $message['datetime_added'] = date('d-m', strtotime($message['datetime_added'])) . Module::getInstanceByName('ets_livechat')->displayText('', 'br', '') . date('h:i A', strtotime($message['datetime_added']));
                    } else
                        $message['datetime_added'] = date('d-m-Y', strtotime($message['datetime_added'])) . Module::getInstanceByName('ets_livechat')->displayText('', 'br', '') . date('h:i A', strtotime($message['datetime_added']));
                }
                if (date('Y-m-d') == date('Y-m-d', strtotime($message['datetime_edited']))) {
                    $message['datetime_edited'] = date('h:i A', strtotime($message['datetime_edited']));
                } else {
                    if (date('Y') == date('Y', strtotime($message['datetime_edited']))) {
                        $message['datetime_edited'] = date('d-m h:i A', strtotime($message['datetime_edited']));
                    } else
                        $message['datetime_edited'] = date('d-m-Y h:i A', strtotime($message['datetime_edited']));
                }
                if (Configuration::get('ETS_LC_DISPLAY_COMPANY_INFO') == 'general' || $message['id_employee'] == -1) {
                    $message['employee_name'] = Configuration::get('ETS_LC_COMPANY_NAME');
                } elseif ($message['name'])
                    $message['employee_name'] = $message['name'];
                if (Configuration::get('ETS_LC_DISPLAY_AVATA')) {
                    if (!isset($messages[$index + 1]) || (isset($messages[$index + 1]) && $messages[$index + 1]['id_employee'])) {
                        $message['customer_avata'] = LC_Departments::getAvatarCustomer($conversation->id_customer);
                        if (isset($message['customer_name']) && $message['customer_name'])
                            $message['customer_name'] = $message['customer_name'];
                        else
                            $message['customer_name'] = 'Chat ID #' . $message['id_conversation'];
                    } else
                        $message['customer_avata'] = '';
                    if (!isset($messages[$index + 1]) || (isset($messages[$index + 1]) && !$messages[$index + 1]['id_employee'])) {
                        $message['employee_avata'] = LC_Departments::getAvatarEmployee($message['id_employee']);
                    } else
                        $message['employee_avata'] = '';
                } else {
                    $message['customer_avata'] = '';
                    $message['employee_avata'] = '';
                    if (!isset($messages[$index + 1]) || (isset($messages[$index + 1]) && $messages[$index + 1]['id_employee'])) {
                        if (isset($message['customer_name']) && $message['customer_name'])
                            $message['customer_name'] = $message['customer_name'];
                        else
                            $message['customer_name'] = 'Chat ID #' . $message['id_conversation'];
                    } else
                        $message['customer_name'] = '';
                    if (!isset($messages[$index + 1]) || (isset($messages[$index + 1]) && !$messages[$index + 1]['id_employee'])) {
                        $message['employee_name'] = $message['employee_name'];
                    } else
                        $message['employee_name'] = '';
                }
                unset($message['customer_email']);
                unset($message['employee_email']);
                unset($message['email']);


                if ($message['name_attachment'] && $attachment = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'ets_livechat_download` WHERE id_download="' . (int)$message['type_attachment'] . '" AND id_message="' . (int)$message['id_message'] . '"')) {
                    $context = Context::getContext();
                    if (isset($context->employee) && $context->employee->id)
                        $linkdownload = $ets_livechat->getBaseLink() . '/modules/ets_livechat/download.php?downloadfile=' . md5(_COOKIE_KEY_ . $message['type_attachment']);
                    else
                        $linkdownload = $context->link->getModuleLink('ets_livechat', 'download', array('downloadfile' => md5(_COOKIE_KEY_ . $message['type_attachment'])));

                    $message['message'] .= ($message['message'] ? Module::getInstanceByName('ets_livechat')->displayText('', 'br', '') : '')
                        . Module::getInstanceByName('ets_livechat')->displayText(Module::getInstanceByName('ets_livechat')->displayText($message['name_attachment'], 'a', 'file_sent', array('href' => $linkdownload, 'target' => '_blank')) . ($attachment['file_size'] ?
                                Module::getInstanceByName('ets_livechat')->displayText('(' . ($attachment['file_size'] >= 1024 ? Tools::ps_round($attachment['file_size'] / 1024, 2) : $attachment['file_size']) . ' ' . ($attachment['file_size'] >= 1024 ? 'MB' : 'KB') . ')', 'span', 'file_size') : ''), 'span', 'file_message');
                }
                if ($message['id_product']) {
                    $message['message'] .= $ets_livechat->getProductHtml($message['id_product']);
                }
                $message['message'] = Tools::nl2br($message['message']);
            }
        }
        return $messages;
    }

    public static function getOldMessages($id_conversation, $firstID = 0, $orderType = 'DESC')
    {
        $limit = (int)Configuration::get('ETS_LC_MSG_COUNT');
        $ets_livechat = new Ets_livechat();
        $conversation = new LC_Conversation($id_conversation);
        $messages = Db::getInstance()->executeS("
            SELECT m.*,CONCAT(e.firstname,' ',e.lastname) as employee_name,IF(c.id_customer,CONCAT(cu.firstname,' ',cu.lastname),c.customer_name) as customer_name,e.email as employee_email,IF(c.id_customer,cu.email,c.customer_email) as customer_email
            FROM `" . _DB_PREFIX_ . "ets_livechat_message` m
            LEFT JOIN `" . _DB_PREFIX_ . "employee` e ON m.id_employee=e.id_employee 
            JOIN `" . _DB_PREFIX_ . "ets_livechat_conversation` c ON m.id_conversation=c.id_conversation
            LEFT JOIN `" . _DB_PREFIX_ . "customer` cu ON c.id_customer=cu.id_customer
            WHERE c.id_conversation=" . (int)$id_conversation . ($firstID ? " AND m.id_message <" . (int)$firstID : "") . "
            ORDER BY m.id_message " . (in_array($orderType, array('ASC', 'DESC')) ? pSQL($orderType) : 'DESC') . "
            " . ($limit > 0 ? "LIMIT 0," . (int)$limit : "") . "
        ");
        if ($messages) {
            foreach ($messages as $index => &$message) {
                if (Tools::strpos($message['message'], 'http') !== false || Tools::strpos($message['message'], 'https') !== false) {
                    $pattern = "/(?i)\b((?:https?:\/\/|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}\/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:'\".,<>?«»“”‘’]))/";
                    $message['message'] = preg_replace($pattern, Module::getInstanceByName('ets_livechat')->displayText('$1', 'a', '', array('target' => '_blank', 'href' => '$1')), $message['message']);
                }
                if ($ets_livechat->emotions) {
                    foreach ($ets_livechat->emotions as $key => $emotion) {
                        $img = Module::getInstanceByName('ets_livechat')->displayText(Module::getInstanceByName('ets_livechat')->displayText('', 'img', '', array('src' => Context::getContext()->link->getMediaLink(_MODULE_DIR_ . 'ets_livechat/views/img/emotions/' . $emotion['img']))), 'span', '', array('title' => $emotion['title']));
                        $message['message'] = str_replace(array(Tools::strtolower($key), $key), array($img, $img), $message['message']);
                    }
                }
                if ($message['datetime_edited'] != $message['datetime_added'])
                    $message['edited'] = 1;
                else
                    $message['edited'] = 0;
                if (date('Y-m-d') == date('Y-m-d', strtotime($message['datetime_added']))) {
                    $message['datetime_added'] = date('h:i A', strtotime($message['datetime_added']));
                } else {
                    if (date('Y') == date('Y', strtotime($message['datetime_added']))) {
                        $message['datetime_added'] = date('d-m', strtotime($message['datetime_added'])) . Module::getInstanceByName('ets_livechat')->displayText('', 'br', '') . date('h:i A', strtotime($message['datetime_added']));
                    } else
                        $message['datetime_added'] = date('d-m-Y', strtotime($message['datetime_added'])) . Module::getInstanceByName('ets_livechat')->displayText('', 'br', '') . date('h:i A', strtotime($message['datetime_added']));
                }
                if (date('Y-m-d') == date('Y-m-d', strtotime($message['datetime_edited']))) {
                    $message['datetime_edited'] = date('h:i A', strtotime($message['datetime_edited']));
                } else {
                    if (date('Y') == date('Y', strtotime($message['datetime_edited']))) {
                        $message['datetime_edited'] = date('d-m h:i A', strtotime($message['datetime_edited']));
                    } else
                        $message['datetime_edited'] = date('d-m-Y h:i A', strtotime($message['datetime_edited']));
                }
                if (Configuration::get('ETS_LC_DISPLAY_COMPANY_INFO') == 'general' || $message['id_employee'] == -1) {
                    $message['employee_name'] = Configuration::get('ETS_LC_COMPANY_NAME');
                }
                if (COnfiguration::get('ETS_LC_DISPLAY_AVATA')) {
                    if (!isset($messages[$index + 1]) || (isset($messages[$index + 1]) && $messages[$index + 1]['id_employee'])) {
                        $message['customer_avata'] = LC_Departments::getAvatarCustomer($conversation->id_customer);
                        if (isset($message['customer_name']) && $message['customer_name'])
                            $message['customer_name'] = $message['customer_name'];
                        else
                            $message['customer_name'] = 'Chat ID #' . $message['id_conversation'];
                    } else
                        $message['customer_avata'] = '';
                    if (!isset($messages[$index + 1]) || (isset($messages[$index + 1]) && !$messages[$index + 1]['id_employee'])) {
                        $message['employee_avata'] = LC_Departments::getAvatarEmployee($message['id_employee']);
                    } else {
                        $message['employee_avata'] = '';
                        $message['employee_name'] = '';
                    }

                } else {

                    $message['customer_avata'] = '';
                    $message['employee_avata'] = '';
                    if (!isset($messages[$index + 1]) || (isset($messages[$index + 1]) && $messages[$index + 1]['id_employee'])) {
                        if (isset($message['customer_name']) && $message['customer_name'])
                            $message['customer_name'] = $message['customer_name'];
                        else
                            $message['customer_name'] = 'Chat ID #' . $message['id_conversation'];
                    } else
                        $message['customer_name'] = '';
                    if (!isset($messages[$index + 1]) || (isset($messages[$index + 1]) && !$messages[$index + 1]['id_employee'])) {
                        $message['employee_name'] = $message['employee_name'];
                    } else
                        $message['employee_name'] = '';
                }

                if ($message['name_attachment'] && $attachment = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'ets_livechat_download` WHERE id_download="' . (int)$message['type_attachment'] . '" AND id_message="' . (int)$message['id_message'] . '"')) {
                    $context = Context::getContext();
                    if (isset($context->employee) && $context->employee->id)
                        $linkdownload = $ets_livechat->getBaseLink() . '/modules/ets_livechat/download.php?downloadfile=' . md5(_COOKIE_KEY_ . $message['type_attachment']);
                    else
                        $linkdownload = $context->link->getModuleLink('ets_livechat', 'download', array('downloadfile' => md5(_COOKIE_KEY_ . $message['type_attachment'])));

                    $message['message'] .= ($message['message'] ? Module::getInstanceByName('ets_livechat')->displayText('', 'br', '') : '')
                        . Module::getInstanceByName('ets_livechat')->displayText(Module::getInstanceByName('ets_livechat')->displayText($message['name_attachment'], 'a' . 'file_sent', array('href' => $linkdownload, 'target' => '_blank')) . ($attachment['file_size'] ? Module::getInstanceByName('ets_livechat')->displayText('(' . ($attachment['file_size'] >= 1024 ? Tools::ps_round($attachment['file_size'] / 1024, 2) : $attachment['file_size']) . ' ' . ($attachment['file_size'] >= 1024 ? 'MB' : 'KB') . ')', 'span', 'file_size') : ''), 'span', 'file_message');
                }
                if ($message['id_product']) {
                    $message['message'] .= $ets_livechat->getProductHtml($message['id_product']);
                }
                $message['message'] = Tools::nl2br($message['message']);
            }
        }
        return $messages;
    }

    public static function getMessage($id_message = 0, $orderby = 'DESC')
    {

        $context = Context::getContext();
        /** @var Ets_livechat $ets_livechat */
        $ets_livechat = Module::getInstanceByName('ets_livechat');
        $declines = $ets_livechat->getDeclineConversation();
        if ($id_message)
            $message = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'ets_livechat_message` WHERE id_message="' . (int)$id_message . '"');
        else {
            $sql = 'SELECT m.* FROM `' . _DB_PREFIX_ . 'ets_livechat_message` m';
            if (isset($context->employee) && isset($context->employee->id_profile)) {
                $sql .= ' LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_conversation` c ON (c.id_conversation=m.id_conversation)
                LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_departments` d ON (d.id_departments=c.id_departments OR d.id_departments=c.id_departments_wait)
                LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_departments_employee` de ON (de.id_departments=c.id_departments)';
            }
            $sql .= ' WHERE m.id_employee=0';
            if (isset($context->employee) && isset($context->employee->id_profile) && $context->employee->id_profile != 1 && LC_Departments::checkDepartments())
                $sql .= ' AND (d.all_employees=1 OR c.id_departments=0 OR de.id_employee="' . (int)$context->employee->id . '" OR c.id_departments_wait=-1)';
            if (isset($context->employee) && $context->employee->id && $context->employee->id_profile != 1 && Configuration::get('ETS_LC_STAFF_ACCEPT'))
                $sql .= ' AND (c.id_employee=0 OR c.id_employee="' . (int)$context->employee->id . '" OR c.id_employee_wait="' . (int)$context->employee->id . '" OR c.id_employee_wait=-1)';
            if (isset($declines) && $declines)
                $sql .= ' AND m.id_conversation NOT IN (' . implode(',', array_map('intval', $declines)) . ')';
            $sql .= ' ORDER BY id_message ' . pSQL($orderby);
            $message = Db::getInstance()->getRow($sql);
            $message['count_message_not_seen'] = LC_Conversation::getMessagesEmployeeNotSeen($message['id_conversation']);

        }
        if (Tools::strpos($message['message'], 'http') !== false || Tools::strpos($message['message'], 'https') !== false) {
            $pattern = "/(?i)\b((?:https?:\/\/|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}\/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:'\".,<>?«»“”‘’]))/";
            $message['message'] = preg_replace($pattern, Module::getInstanceByName('ets_livechat')->displayText('$1', 'a', '', array('target' => '_blank', 'href' => '$1')), $message['message']);
        }
        if ($ets_livechat->emotions) {
            foreach ($ets_livechat->emotions as $key => $emotion) {
                $img = Module::getInstanceByName('ets_livechat')->displayText(Module::getInstanceByName('ets_livechat')->displayText('', 'img', '', array('src' => Context::getContext()->link->getMediaLink(_MODULE_DIR_ . 'ets_livechat/views/img/emotions/' . $emotion['img']))), 'span', '', array('title' => $emotion['title']));
                $message['message'] = str_replace(array(Tools::strtolower($key), $key), array($img, $img), $message['message']);
            }
        }
        if (date('Y-m-d') == date('Y-m-d', strtotime($message['datetime_added']))) {
            $message['datetime_added'] = date('h:i A', strtotime($message['datetime_added']));
        } else {
            if (date('Y') == date('Y', strtotime($message['datetime_added']))) {
                $message['datetime_added'] = date('d-m h:i A', strtotime($message['datetime_added']));
            } else
                $message['datetime_added'] = date('d-m-Y h:i A', strtotime($message['datetime_added']));
        }
        if (isset($message['customer_name']) && $message['customer_name'])
            $message['customer_name'] = $message['customer_name'];
        else
            $message['customer_name'] = 'Chat ID #' . $message['id_conversation'];

        if ($message['name_attachment'] && $attachment = Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'ets_livechat_download` WHERE id_download="' . (int)$message['type_attachment'] . '" AND id_message="' . (int)$message['id_message'] . '"')) {
            $context = Context::getContext();
            if (isset($context->employee) && $context->employee->id)
                $linkdownload = $ets_livechat->getBaseLink() . '/modules/ets_livechat/download.php?downloadfile=' . md5(_COOKIE_KEY_ . $message['type_attachment']);
            else
                $linkdownload = $context->link->getModuleLink('ets_livechat', 'download', array('downloadfile' => md5(_COOKIE_KEY_ . $message['type_attachment'])));

            $message['message'] .= ($message['message'] ? Module::getInstanceByName('ets_livechat')->displayText('', 'br', '') : '')
                . Module::getInstanceByName('ets_livechat')->displayText(Module::getInstanceByName('ets_livechat')->displayText($message['name_attachment'], 'a', 'file_sent', array('href' => $linkdownload, 'target' => '_blank')) . ($attachment['file_size'] ?
                        Module::getInstanceByName('ets_livechat')->displayText('(' . ($attachment['file_size'] >= 1024 ? Tools::ps_round($attachment['file_size'] / 1024, 2) : $attachment['file_size']) . ' ' . ($attachment['file_size'] >= 1024 ? 'MB' : 'KB') . ')', 'span', 'file_size') : ''), 'span', 'file_message');
        }
        $message['message'] = Tools::nl2br($message['message']);
        return $message;
    }

    public static function getMessageByListID($ids_message)
    {
        if ($ids_message) {
            $ids_message= explode(',',$ids_message);
            $messages = Db::getInstance()->executeS('SELECT * FROM `' . _DB_PREFIX_ . 'ets_livechat_message` WHERE id_message in (' . implode(',',array_map('intval',$ids_message)) . ')');
            $ets_livechat = new Ets_livechat();
            if ($messages) {
                foreach ($messages as &$message) {
                    if ($ets_livechat->emotions) {
                        foreach ($ets_livechat->emotions as $key => $emotion) {
                            $img = Module::getInstanceByName('ets_livechat')->displayText(Module::getInstanceByName('ets_livechat')->displayText('', 'img', '', array('src' => Context::getContext()->link->getMediaLink(_MODULE_DIR_ . 'ets_livechat/views/img/emotions/' . $emotion['img']))), 'span', array('title' => $emotion['title']));
                            $message['message'] = str_replace(array(Tools::strtolower($key), $key), array($img, $img), $message['message']);
                        }
                    }
                    if (date('Y-m-d') == date('Y-m-d', strtotime($message['datetime_edited']))) {
                        $message['datetime_edited'] = date('h:i A', strtotime($message['datetime_edited']));
                    } else {
                        if (date('Y') == date('Y', strtotime($message['datetime_edited']))) {
                            $message['datetime_edited'] = date('d-m h:i A', strtotime($message['datetime_edited']));
                        } else
                            $message['datetime_edited'] = date('d-m-Y h:i A', strtotime($message['datetime_edited']));
                    }
                }

            }
            return $messages;
        } else
            return '';
    }
    public function delete()
    {
        $id_conversation = $this->id_conversation;
        $id_download = Db::getInstance()->getValue('SELECT id_download FROM `' . _DB_PREFIX_ . 'ets_livechat_download` WHERE id_message =' . (int)$this->id);
        if ($id_download) {
            $download = new LC_Download($id_download);
            $download->delete();
        }
        if (parent::delete()) {
            if (!Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'ets_livechat_message` WHERE id_conversation=' . (int)$id_conversation)) {
                Db::getInstance()->execute('DELETE FROM `' . _DB_PREFIX_ . 'ets_livechat_conversation` WHERE id_conversation=' . (int)$id_conversation);
            }
            return true;
        }
        return false;
    }
    public static function checkNewMessage($lastID_Conversation,$lastID_message,$customer_all)
    {
        if ($customer_all) {
            $sql = 'SELECT m.* FROM `' . _DB_PREFIX_ . 'ets_livechat_message` m';
            if (Context::getContext()->employee->id_profile != 1 && LC_Departments::checkDepartments()) {
                $sql .= ' LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_conversation` c ON (c.id_conversation=m.id_conversation)
                LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_departments` d ON (d.id_departments=c.id_departments)
                LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_departments_employee` de ON (de.id_departments=c.id_departments)';
            };
            $sql .= ' WHERE m.id_message > "' . (int)$lastID_message . '" AND m.id_employee=0';
            if (Context::getContext()->employee->id_profile != 1 && LC_Departments::checkDepartments())
                $sql .= ' AND (d.all_employees=1 OR c.id_departments=0 OR de.id_employee="' . (int)Context::getContext()->employee->id . '")';
            $sql .= ' GROUP BY m.id_conversation';
        } else {
            $sql = 'SELECT m.* FROM `' . _DB_PREFIX_ . 'ets_livechat_message` m
            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_conversation` c ON (c.id_conversation=m.id_conversation)';
            if (Context::getContext()->employee->id_profile != 1 && LC_Departments::checkDepartments()) {
                $sql .= ' LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_departments` d ON (d.id_departments=c.id_departments)
                LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_departments_employee` de ON (de.id_departments=c.id_departments)';
            };
            $sql .= ' WHERE m.id_conversation=c.id_conversation AND  c.archive =0 AND m.id_message > "' . (int)$lastID_message . '" AND m.id_employee=0';
            if (Context::getContext()->employee->id_profile != 1 && LC_Departments::checkDepartments())
                $sql .= ' AND ( d.all_employees=1 OR c.id_departments=0 OR de.id_employee="' . (int)Context::getContext()->employee->id . '")';
            $sql .= ' GROUP BY m.id_conversation';
        }
        if ($messages = Db::getInstance()->executeS($sql)) {
            if (count($messages) == 1 && $messages[0]['id_conversation'] == $lastID_Conversation)
                return 1;
            return 2;
        }
        return 0;
    }
    public static function getCountMessage($filter,$all_shop=true)
    {
        $sql = 'SELECT COUNT(DISTINCT m.id_message) FROM `' . _DB_PREFIX_ . 'ets_livechat_message` m
            LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_conversation` c on (m.id_conversation= c.id_conversation)
            WHERE 1 ' . (!$all_shop ? ' AND c.id_shop="' . (int)Context::getContext()->shop->id . '"' : '') . ($filter ? (string)$filter : '');
        return Db::getInstance()->getValue($sql);
    }
    public static function getAttachmentsMessage($count = false, $filter = false)
    {
        $sql = 'SELECT id_message,message,name_attachment,type_attachment FROM `' . _DB_PREFIX_ . 'ets_livechat_message`
        WHERE name_attachment!="" ' . ($filter ? (string)$filter : '') . (!LC_Tools::allShop() ? ' AND id_conversation IN (SELECT id_conversation FROM `' . _DB_PREFIX_ . 'ets_livechat_conversation` WHERE id_shop ="' . (int)Context::getContext()->shop->id . '")' : '');
        $messages = Db::getInstance()->executeS($sql);
        if ($count) {
            $total = 0;
            if ($messages) {
                foreach ($messages as $message) {
                    $download = new LC_Download($message['type_attachment']);
                    $total += $download->file_size;
                }
            }
            return array(
                'count' => count($messages),
                'size' => $total
            );
        } else {
            if ($messages) {
                foreach ($messages as $message) {
                    $message_class = new LC_Message($message['id_message']);
                    if (!$message['message']) {
                        $message_class->delete();
                    } else {
                        $download = new LC_Download($message['type_attachment']);
                        $download->delete();
                        $message_class->name_attachment = '';
                        $message_class->type_attachment = 0;
                        $message_class->update();
                    }
                }
            }
            return true;
        }
    }
}
