<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) { exit; }

class LC_Note extends ObjectModel
{
    public $id_message;
    public $id_employee;
    public $id_customer;
    public $employee;
    public $id_download;
    public $note;
    public $note_origin;
    public $file_name;
    public $date_add;
    public $send_email_customer;
    public $send_email_admin;
    public static $definition = array(
        'table' => 'ets_livechat_ticket_form_message_note',
        'primary' => 'id_note',
        'fields' => array(
            'id_message' => array('type' => self::TYPE_INT),
            'id_employee' => array('type' => self::TYPE_INT),
            'id_customer' => array('type' => self::TYPE_INT),
            'employee' => array('type' => self::TYPE_BOOL),
            'id_download' => array('type' => self::TYPE_INT),
            'note' => array('type' => self::TYPE_HTML),
            'note_origin' => array('type' => self::TYPE_HTML),
            'file_name' => array('type' => self::TYPE_STRING),
            'send_email_customer' => array('type' => self::TYPE_STRING),
            'send_email_admin' => array('type' => self::TYPE_STRING),
            'date_add' => array('type' => self::TYPE_STRING),
        )
    );

    public function __construct($id_item = null, $id_lang = null, $id_shop = null)
    {
        parent::__construct($id_item, $id_lang, $id_shop);
    }

    public function delete()
    {
        $id_download = Db::getInstance()->getValue('SELECT id_download FROM `' . _DB_PREFIX_ . 'ets_livechat_download` WHERE id_note =' . (int)$this->id);
        if ($id_download) {
            $download = new LC_Download($id_download);
            $download->delete();
        }
        return parent::delete();
    }

    public static function getRowById($id_note)
    {
        if ($id_note <= 0 ||
            !Validate::isUnsignedInt($id_note)
        ) {
            return false;
        }
        return Db::getInstance()->getRow('
            SELECT note.note, note.file_name, note.id_download, d.file_size, note.send_email_admin, note.send_email_admin 
            FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note` note
                LEFT JOIN `' . _DB_PREFIX_ . 'ets_livechat_download` d ON (note.id_download = d.id_download)
            WHERE note.id_note =' . (int)$id_note
        );
    }

    public static function maxId($id_message)
    {
        if ($id_message <= 0 ||
            !Validate::isUnsignedInt($id_message)
        ) {
            return 0;
        }
        return (int)Db::getInstance()->getValue('SELECT MAX(id_note) FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note` WHERE id_message=' . (int)$id_message);
    }

    public static function getLastItem($id_message)
    {
        if ($id_message <= 0 ||
            !Validate::isUnsignedInt($id_message)
        ) {
            return 0;
        }
        return Db::getInstance()->getRow('SELECT * FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note` WHERE id_message=' . (int)$id_message . ' ORDER BY id_note DESC');
    }

    public static function makeReadNote($id_ticket, $condition = null)
    {
        if ($id_ticket <= 0 ||
            !Validate::isUnsignedInt($id_ticket)
        ) {
            return 0;
        }
        return Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note` SET readed=1 WHERE id_message=' . (int)$id_ticket . pSQL($condition));
    }

    /**
     * @param $id_ticket
     * @return array|false|string[]
     */
    public static function getEmailsManagerTicket($id_ticket)
    {
        if ($id_ticket <= 0 ||
            !Validate::isUnsignedInt($id_ticket)
        ) {
            return [];
        }
        $results = Db::getInstance()->executeS('
            SELECT c.`email`, CONCAT(c.firstname, " ", c.lastname) customer_name
            FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note` n
                LEFT JOIN `' . _DB_PREFIX_ . 'customer` c ON (c.id_customer = n.id_customer)
            WHERE c.id_customer > 0 AND n.employee > 0 AND n.id_message = ' . (int)$id_ticket . '
            GROUP BY c.`email`
        ');
        $mails_to = [];
        $names_to = [];
        if (is_array($results) && count($results) > 0) {
            foreach ($results as $item) {
                $mails_to[] = trim($item['email']);
                $names_to[] = trim($item['customer_name']);
            }
        }
        return array(
            'mails_to' => $mails_to,
            'names_to' => $names_to
        );
    }
    public static function getAttachmentsNote($count = false, $filter = false)
    {
        $sql = 'SELECT id_note,id_download,id_note,note FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message_note`
        WHERE id_download!=0 ' . ($filter ? (string)$filter : '') . (!LC_Tools::allShop() ? ' AND id_message IN (SELECT id_message FROM `' . _DB_PREFIX_ . 'ets_livechat_ticket_form_message` WHERE id_shop="' . (int)Context::getContext()->shop->id . '")' : '');
        $notes = Db::getInstance()->executeS($sql);
        if ($count) {
            $total = 0;
            if ($notes) {
                foreach ($notes as $note) {
                    $download = new LC_Download($note['id_download']);
                    $total += $download->file_size;
                }
            }
            return array(
                'count' => count($notes),
                'size' => $total
            );
        } else {
            if ($notes) {
                foreach ($notes as $note) {
                    $note_class = new LC_Note($note['id_note']);
                    if (!$note['note']) {
                        $note_class->delete();
                    } else {
                        $download = new LC_Download($note['id_download']);
                        $download->delete();
                        $note_class->id_download = 0;
                        $note_class->update();
                    }
                }
            }
            return true;
        }
    }
}