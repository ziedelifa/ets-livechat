<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

namespace Hybridauth\Provider;

use Hybridauth\Adapter\OAuth2;
use Hybridauth\Exception\UnexpectedApiResponseException;
use Hybridauth\Data;
use Hybridauth\User;

/**
 * Twitter OAuth2 provider adapter.
 *
 */

if (!defined('_PS_VERSION_')) { exit; }
class Twitter extends OAuth2
{
    public $scope = 'tweet.read users.read offline.access';
    /**
     * {@inheritdoc}
     */
    protected $apiBaseUrl = 'https://api.twitter.com/';

    /**
     * {@inheritdoc}
     */
    protected $authorizeUrl = 'https://twitter.com/i/oauth2/authorize';

    /**
     * {@inheritdoc}
     */
    protected $accessTokenUrl = 'https://api.twitter.com/2/oauth2/token';

    /**
     * {@inheritdoc}
     */
    protected $apiDocumentation = 'https://developer.twitter.com/en/docs/twitter-api';

    /**
     * {@inheritdoc}
     */
    protected function initialize()
    {
        parent::initialize();

        $this->AuthorizeUrlParameters += array(
            'code_challenge' => 'challenge',
            'code_challenge_method' => 'plain',
        );

        $this->tokenExchangeHeaders = [
            'Authorization' => 'Basic ' . call_user_func('base64_encode', $this->clientId . ':' . $this->clientSecret)
        ];

        $this->tokenRefreshHeaders = [
            'Authorization' => 'Basic ' . call_user_func('base64_encode', $this->clientId . ':' . $this->clientSecret)
        ];

        $this->tokenExchangeParameters['code_verifier'] = 'challenge';
    }

    /**
     * {@inheritdoc}
     */
    public function getUserProfile()
    {
        $response = $this->apiRequest('2/users/me?user.fields=created_at,description,id,location,name,profile_image_url,url,username');
        $data = new Data\Collection($response->data);
        if (!$data->exists('id')) {
            throw new UnexpectedApiResponseException('Provider API returned an unexpected response.');
        }

        $userProfile = new User\Profile();

        $userProfile->identifier = $data->get('id');
        $userProfile->displayName = $data->get('name');
        $userProfile->description = $data->get('description');
        $userProfile->firstName = $data->get('name');
        $userProfile->email = $data->get('email');
        $userProfile->emailVerified = $data->get('email');
        $userProfile->webSiteURL = $data->get('url');
        $userProfile->region = $data->get('location');

        $userProfile->profileURL = $data->exists('name')
            ? ('http://twitter.com/' . $data->get('name'))
            : '';

        $userProfile->photoURL = $data->exists('profile_image_url')
            ? str_replace('_normal', '', $data->get('profile_image_url'))
            : '';

        return $userProfile;
    }
}
