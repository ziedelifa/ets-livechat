<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) { exit; }

class LC_MadeMessage extends ObjectModel
{
    public $title_message;
    public $message_content;
    public $short_code;
    public $position;
    public static $definition = array(
        'table' => 'ets_livechat_pre_made_message',
        'primary' => 'id_pre_made_message',
        'fields' => array(
            'title_message' => array('type' => self::TYPE_STRING),
            'message_content' => array('type' => self::TYPE_STRING),
            'short_code' => array('type' => self::TYPE_STRING),
            'position' => array('type' => self::TYPE_INT),
        )
    );
    public static function updatePositionMadeMessages($pre_made_messages)
    {
        if ($pre_made_messages && LC_Tools::validateArray($pre_made_messages, 'isInt')) {
            foreach ($pre_made_messages as $key => $value) {
                Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . 'ets_livechat_pre_made_message` SET position="' . (int)$key . '" WHERE id_pre_made_message="' . (int)$value . '"');
            }
            die(
                json_encode(
                    array(
                        'ok' => true,
                    )
                )
            );
        }
    }
    public static function getMadeMessages()
    {
        return Db::getInstance()->executeS('SELECT * FROM `' . _DB_PREFIX_ . 'ets_livechat_pre_made_message` ORDER BY position');
    }

}