<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) { exit; }

class LC_Download extends ObjectModel
{
    public $id_message;
    public $id_ticket;
    public $id_field;
    public $id_note;
    public $id_conversation;
    public $filename;
    public $name;
    public $file_type;
    public $file_size;
    public static $definition = array(
        'table' => 'ets_livechat_download',
        'primary' => 'id_download',
        'fields' => array(
            'id_message' => array('type' => self::TYPE_INT),
            'id_ticket' => array('type' => self::TYPE_INT),
            'id_field' => array('type' => self::TYPE_INT),
            'id_note' => array('type' => self::TYPE_INT),
            'id_conversation' => array('type' => self::TYPE_INT),
            'filename' => array('type' => self::TYPE_STRING),
            'name' => array('type' => self::TYPE_STRING),
            'file_type' => array('type' => self::TYPE_STRING),
            'file_size' => array('type' => self::TYPE_FLOAT),
        )
    );

    public function __construct($id_item = null, $id_lang = null, $id_shop = null)
    {
        parent::__construct($id_item, $id_lang, $id_shop);
    }

    public function delete()
    {
        if(file_exists(_PS_ETS_LIVE_CHAT_UPLOAD_DIR_ . ($this->name ?: $this->filename)))
            @unlink(_PS_ETS_LIVE_CHAT_UPLOAD_DIR_ . ($this->name ?: $this->filename));
        return parent::delete();
    }

}