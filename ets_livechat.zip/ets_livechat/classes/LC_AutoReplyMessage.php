<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) { exit; }

class LC_AutoReplyMessage extends ObjectModel
{
    public $message_order;
    public $auto_content;
    public static $definition = array(
        'table' => 'ets_livechat_auto_msg',
        'primary' => 'id_auto_msg',
        'multilang' => true,
        'fields' => array(
            'message_order' => array('type' => self::TYPE_INT),
            'auto_content' => array('type' => self::TYPE_STRING,'lang'=>true),
        )
    );
    public static function getMessageByOrder($message_order)
    {
        return Db::getInstance()->getValue('SELECT id_auto_msg FROM `' . _DB_PREFIX_ . 'ets_livechat_auto_msg` WHERE message_order ="' . (int)$message_order . '"');
    }
    public static function getAllAutoMessages()
    {
        $sql ='SELECT am.*,aml.auto_content FROM `' . _DB_PREFIX_ . 'ets_livechat_auto_msg` am
        LEFT JOIN `'._DB_PREFIX_.'ets_livechat_auto_msg_lang` aml ON (am.id_auto_msg = aml.id_auto_msg AND aml.id_lang="'.(int)Context::getContext()->language->id.'")';
        return Db::getInstance()->executeS($sql);
    }
}