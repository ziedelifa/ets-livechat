<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) { exit; }
class Ets_livechatHistoryModuleFrontController extends ModuleFrontController
{
    public function __construct()
	{
		parent::__construct();
		$this->context = Context::getContext();
	}
	public function init()
	{
		parent::init();
	}
	public function initContent()
	{
	    parent::initContent();
        if(!LC_Base::getMetaByController('history'))
            $this->module->setMeta();
        if (!$this->context->customer->isLogged())   
            Tools::redirect('index.php?controller=authentication');
        $conversation = LC_Conversation::getCustomerConversation();
        $this->context->smarty->assign(
            array(
                'breadcrumb' => $this->module->is17 ? $this->module->getBreadCrumb() : false, 
                'path' => $this->module->getBreadCrumb(),
            )
        );
        if(Tools::isSubmit('viewchat') && ($id_conversation=(int)Tools::getValue('id')) )
        {
            $conversation_class= new LC_Conversation($id_conversation);
            if($conversation->chatref!=$conversation->chatref)
                die($this->module->l('You do not have access permission','history'));
            else
            {
                $this->context->smarty->assign(
                    array(
                        'conversation_messages' => $this->module->_displayConversationDetail($conversation_class),
                    )
                );
                if($this->module->is17)
                    $this->setTemplate('module:ets_livechat/views/templates/front/conversation_detail.tpl');      
                else         
                    $this->setTemplate('conversation_detail16.tpl');
            }
        }
        else
        {
            $this->context->smarty->assign(
                array(
                    'list_conversations' => $this->module->_displayHistoryChatCustomer($conversation ? $conversation->chatref :0),
                )
            );
            if($this->module->is17)
                $this->setTemplate('module:ets_livechat/views/templates/front/history.tpl');      
            else         
                $this->setTemplate('history16.tpl');
        }
          
    }
}