<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) { exit; }
if(!class_exists('LC_Conversation') && file_exists(dirname(__FILE__).'/../../classes/LC_Conversation.php'))
    require_once(dirname(__FILE__).'/../../classes/LC_Conversation.php');
if(!class_exists('LC_Message') && file_exists(dirname(__FILE__).'/../../classes/LC_Message.php'))
    require_once(dirname(__FILE__).'/../../classes/LC_Message.php');
if(!class_exists('LC_Download') && file_exists(dirname(__FILE__).'/../../classes/LC_Download.php'))
    require_once(dirname(__FILE__).'/../../classes/LC_Download.php');
if(!class_exists('LC_Departments') && file_exists(dirname(__FILE__).'/../../classes/LC_Departments.php'))
    require_once(dirname(__FILE__).'/../../classes/LC_Departments.php');
if(!class_exists('LC_Ticket_form') && file_exists(dirname(__FILE__).'/../../classes/LC_Ticket_form.php'))
    require_once(dirname(__FILE__).'/../../classes/LC_Ticket_form.php');
if(!class_exists('LC_Ticket_field') && file_exists(dirname(__FILE__).'/../../classes/LC_Ticket_field.php'))
    require_once(dirname(__FILE__).'/../../classes/LC_Ticket_field.php');
if(!class_exists('LC_Ticket') && file_exists(dirname(__FILE__).'/../../classes/LC_Ticket.php'))
    require_once(dirname(__FILE__).'/../../classes/LC_Ticket.php');
class Ets_livechatFormModuleFrontController extends ModuleFrontController
{
    public $_errors;
    public function __construct()
	{
		parent::__construct();
		$this->context = Context::getContext();
	}
	public function init()
	{
		parent::init();
	}
    public function postProcess()
    {
        if(Tools::isSubmit('submitLoginCustomerContact'))
        {
             $this->submitLoginCustomerContact();
        }
        if(Tools::isSubmit('submitCustomerContact'))
        {
            $this->submitCustomerContact();
        }
    }
    public function submitCustomerContact()
    {
        if( ($email = Tools::getValue('email')) && Validate::isEmail($email) && Customer::customerExists($email))
        {
            $this->_errors[] = $this->module->l('The email is already used, please choose another one or sign in','form');   
        }
        else
        {
            if(!($firstname =  Tools::getValue('firstname')))
                $this->_errors[] = $this->module->l('First name is required','form');
            elseif($firstname && !Validate::isName($firstname))
                $this->_errors[] = $this->module->l('First name is not valid','form');
            if(!($lastname= Tools::getValue('lastname')))
                $this->_errors[] = $this->module->l('Last name is required','form');
            elseif($lastname && !Validate::isName($lastname))
                $this->_errors[] = $this->module->l('Last name is not valid','form');
            if(!($email = Tools::getValue('email')))
                $this->_errors[] = $this->module->l('Email is required','form');
            elseif($email && !Validate::isEmail($email))
                $this->_errors[] = $this->module->l('Email is not valid','form');
            if(!($password = Tools::getValue('password')))
                $this->_errors[] = $this->module->l('Password is required','form');
            if($password && !Validate::isPasswd($password))
                $this->_errors[] = $this->module->l('Password is not valid','form');
            if(!$this->_errors)
            {
                $customer = new Customer();
    			$customer->id_shop = (int)$this->context->shop->id;
    			$customer->lastname = $lastname;
    			$customer->firstname = $firstname;
    			$customer->email = $email;
    			$passwdGen = $password;
    			$customer->passwd = md5(_COOKIE_KEY_.$passwdGen);
    			if ($customer->save())
    			{
    				if ($this->module->is17)
                    {
                        $this->context->updateCustomer($customer);
                        Hook::exec('actionAuthentication', array('customer' => $this->context->customer));
                        CartRule::autoRemoveFromCart($this->context);
                        CartRule::autoAddToCart($this->context);
                    }
                    else
    				    $this->module->updateContext($customer);
                    
    			}
                $id_form = (int)Tools::getValue('id_form');
                $form = new LC_Ticket_Form($id_form, $this->context->language->id);
                $post_fields = Tools::getValue('fields');
                if ($idCustomer = (int)Tools::getValue('id_customer')) {
                    $customerObj = new Customer($idCustomer);
                } else
                    $customerObj = false;
                $post_fields['id_customer'] = $idCustomer;
                $post_fields['search_customer'] = Tools::getValue('search_customer_ticket', $customerObj ? $customerObj->firstname . ' ' . $customerObj->lastname : '');
                $post_fields['id_customer_ticket'] = (int)Tools::getValue('id_customer_ticket', $customerObj ? $customerObj->id : '');
                $post_fields['order_ref'] = ($orderRef = Tools::getValue('order_ref')) && Validate::isReference($orderRef) ? $orderRef :'';
                $post_fields['id_product_ref'] = (int)Tools::getValue('id_product',(int)Tools::getValue('id_product_ref'));
                die(
                    json_encode(
                        array(
                            'success' => $this->module->l('Create customer successfully','form'),
                            'form' => $form ? $form->renderHtmlForm(0,false,$post_fields) :'',
                        )
                    )
                );
            }
        }
        if($this->_errors)
        {
            die(
                json_encode(
                    array(
                        'errors' => $this->module->displayError($this->_errors),
                    )
                )
            );
        }
    }
    public function submitLoginCustomerContact()
    {
        if(!Tools::getValue('email'))
            $this->_errors[] = $this->module->l('Email is required','form');
        elseif(Tools::getValue('email') && !Validate::isEmail(Tools::getValue('email')))
            $this->_errors[] = $this->module->l('Email is not valid','form');
        if(!Tools::getValue('password'))
            $this->_errors[] = $this->module->l('Password is required','form');
        if(Tools::getValue('password') && !Validate::isPasswd(Tools::getValue('password')))
            $this->_errors[] = $this->module->l('Password is not valid','form');
        if(!$this->_errors)
        {
            if($id_customer= Customer::customerExists(Tools::getValue('email')))
            {
                $customer = new Customer($id_customer);
                if($customer->getByEmail(Tools::getValue('email'),Tools::getValue('password')))
                {
                    if ($this->module->is17)
                        $this->context->updateCustomer($customer);
                    else
                        $this->module->updateContext($customer);
                    $id_form = (int)Tools::getValue('id_form');
                    $form = new LC_Ticket_Form($id_form, $this->context->language->id);
                    $post_fields = Tools::getValue('fields');
                    if ($idCustomer = (int)Tools::getValue('id_customer')) {
                        $customerObj = new Customer($idCustomer);
                    } else
                        $customerObj = false;
                    $post_fields['id_customer'] = $idCustomer;
                    $post_fields['search_customer'] = Tools::getValue('search_customer_ticket', $customerObj ? $customerObj->firstname . ' ' . $customerObj->lastname : '');
                    $post_fields['id_customer_ticket'] = (int)Tools::getValue('id_customer_ticket', $customerObj ? $customerObj->id : '');
                    $post_fields['order_ref'] = ($orderRef = Tools::getValue('order_ref')) && Validate::isReference($orderRef) ? $orderRef :'';
                    $post_fields['id_product_ref'] = (int)Tools::getValue('id_product',(int)Tools::getValue('id_product_ref'));
                    die(
                        json_encode(
                            array(
                                'success' => $this->module->l('Logged in successfully','form'),
                                'form' => $form ? $form->renderHtmlForm(0,false,$post_fields):'',
                            )
                        )
                    );
                }
                else
                    $this->_errors[] = $this->module->l('Authentication failed.','form');
            }
            else
                $this->_errors[] = $this->module->l('Authentication failed.','form');
            
        }
        if($this->_errors)
        {
            die(
                json_encode(
                    array(
                        'errors' => $this->module->displayError($this->_errors),
                    )
                )
            );
        }
    }
	public function initContent()
    {
        parent::initContent();
        $id_form = (int)Tools::getValue('id_form');
        $params = array();
        if(($id_product_ref = (int)Tools::getValue('id_product_ref')))
            $params['id_product_ref'] = $id_product_ref;
        if(($order_ref = Tools::getValue('order_ref')) && Validate::isReference($order_ref))
            $params['order_ref'] = $order_ref;
        if ($id_form && Configuration::get('ETS_LC_URL_REMOVE_ID') && Configuration::get('PS_REWRITING_SETTINGS'))
            Tools::redirect($this->module->getFormLink($id_form,$params));
        $url_alias = Tools::getValue('url_alias');
        
        if ($url_alias && !Validate::isLinkRewrite($url_alias))
            $this->_errors[] = $this->module->l('Ticket URL not found!', 'form');
        elseif (!$id_form) {
            $form = LC_Ticket_Form::getForm(null, $url_alias);
            if ($form && ($id_form = $form['id_form']))
            {
                if(!Configuration::get('ETS_LC_URL_REMOVE_ID') && Configuration::get('PS_REWRITING_SETTINGS'))
                    Tools::redirect($this->module->getFormLink($id_form,$params));
            }
            else
                $this->_errors[] = $this->module->l('Ticket form not found!', 'form');
        } else {
            if (!($form = LC_Ticket_Form::getForm($id_form, $url_alias)))
                Tools::redirect($this->module->getFormLink($id_form,$params));
        }
        if ($url_alias && Configuration::get('PS_REWRITING_SETTINGS') && isset($_SERVER['REQUEST_URI']) && Tools::strpos($_SERVER['REQUEST_URI'], 'module/ets_livechat')) {
            if (!$id_form && ($form = LC_Ticket_Form::getForm(false, $url_alias)))
                Tools::redirect($this->module->getFormLink($form->id,$params));
            elseif(!$id_form && ($idForm = LC_Ticket_form::getIdFormByFriendlyUrl($url_alias,true)))
                Tools::redirect($this->module->getFormLink($idForm,$params));
            elseif($id_form)
                Tools::redirect($this->module->getFormLink($id_form,$params));
            elseif(!$form)
                Tools::redirect($this->context->link->getPageLink('PageNotFound'));
        }
        if (!$this->_errors && $id_form && ($form = new LC_Ticket_Form($id_form, $this->context->language->id)) && Validate::isLoadedObject($form)) {
            if (!$this->context->customer->logged && !$form->allow_user_submit)
            {
                $this->context->smarty->assign(
                    array(
                        'render_html_form' => $this->renderHtmlFormLogin(),
                        'breadcrumb' => $this->module->is17 ? $this->module->getBreadCrumb() : false,
                        'path' => $this->module->getBreadCrumb(),
                        'ETS_LIVECHAT_ADMIN_TICKET' => Configuration::get('ETS_LIVECHAT_ADMIN_TICKET'),
                    )
                );
            }
            else{
                if ($this->module->is17) {
                    $body_classes = array(
                        'lang-' . $this->context->language->iso_code => true,
                        'lang-rtl' => (bool)$this->context->language->is_rtl,
                        'country-' . $this->context->country->iso_code => true,
                    );
                    $page = array(
                        'title' => '',
                        'canonical' => '',
                        'meta' => array(
                            'title' => $form->meta_title ? $form->meta_title : $form->title,
                            'description' => $form->meta_description,
                            'keywords' => $form->meta_keywords,
                            'robots' => 'index',
                        ),
                        'page_name' => 'lc_form_page',
                        'body_classes' => $body_classes,
                        'admin_notifications' => array(),
                    );
                    $this->context->smarty->assign(array('page' => $page));
                } else {
                    $this->context->smarty->assign(
                        array(
                            'meta_title' => $form->meta_title ? $form->meta_title : $form->title,
                            'meta_description' => $form->meta_description,
                            'meta_keywords' => $form->meta_keywords,
                        )
                    );
                }
                if (Tools::isSubmit('submit_send_ticket')) {
                    $fieldValues = Tools::getValue('fields');
                    $department = (int)Tools::getValue('id_departments')?: 0;
                    $orderRef = Tools::isSubmit('order_ref') ? Tools::getValue('order_ref') : false;
                    $id_product = (int)Tools::getValue('id_product')?: 0;
                    $fieldValues['field_captcha'] = ($field_captcha = Tools::getValue('field_captcha')) && Validate::isCleanHtml($field_captcha) ? $field_captcha:'';
                    $fieldValues['g_recaptcha_response'] = ($g_recaptcha_response = Tools::getValue('g-recaptcha-response')) && Validate::isCleanHtml($g_recaptcha_response) ? $g_recaptcha_response:'';
                    $res = LC_Ticket::getInstance()->addTicket(array(
                        'id_departments' => $department,
                        'order_ref' => $orderRef,
                        'id_product' => $id_product,
                        'fields' => LC_Tools::validateArray($fieldValues) ? $fieldValues :array(),
                    ),$form);
                    if($res['success'])
                    {
                        $this->context->cookie->lc_success = $res['success'];
                        $this->context->cookie->write();
                        $array = array();
                        if($id_product)
                            $array['id_product_ref'] =$id_product;
                        if($orderRef)
                            $array['order_ref'] =$orderRef;
                        if($res['ticket'])
                            $array['id_ticket'] = $res['ticket']->id;
                        Tools::redirect($this->module->getFormLink($form->id,$array));
                    }
                    $this->context->smarty->assign(
                        array(
                            'errors' => $res['errors'] ? $this->module->displayError($res['errors']) : '',
                            'success' => $res['success'],
                            'ticket_add_new' => $res['ticket'] ?: false,
                            'view_ticket' => $res['success'] && $this->context->customer->logged ? true : false,
                            'token_view_ticket' => $res['success'] && $res['ticket'] ? md5(_COOKIE_KEY_.$res['ticket']->id.$res['ticket']->date_add):'',
                            'isCustomer' => true,
                        )
                    );
                }
                if($this->context->cookie->lc_success)
                {
                    $id_ticket = (int)Tools::getValue('id_ticket');
                    $new_ticket = $id_ticket != 0 ? new LC_Ticket($id_ticket):false ;
                    $this->context->smarty->assign(
                        array(
                            'errors' => '',
                            'success' => $this->context->cookie->lc_success,
                            'view_ticket' => $this->context->customer->logged ? true : false,
                            'isCustomer' => true,
                            'ticket_add_new' => $new_ticket,
                            'token_view_ticket' => $new_ticket ? md5(_COOKIE_KEY_.$new_ticket->id.$new_ticket->date_add):'',
                        )
                    );
                    $this->context->cookie->lc_success = '';
                    $this->context->cookie->write();
                }
                $post_fields = Tools::getValue('fields');
                if ($idCustomer = (int)Tools::getValue('id_customer')) {
                    $customerObj = new Customer($idCustomer);
                } else
                    $customerObj = false;
                $post_fields['id_customer'] = $idCustomer;
                $post_fields['search_customer'] = Tools::getValue('search_customer_ticket', $customerObj ? $customerObj->firstname . ' ' . $customerObj->lastname : '');
                $post_fields['id_customer_ticket'] = (int)Tools::getValue('id_customer_ticket', $customerObj ? $customerObj->id : '');
                $post_fields['order_ref'] = ($orderRef = Tools::getValue('order_ref')) && Validate::isReference($orderRef) ? $orderRef :'';
                $post_fields['id_product_ref'] = (int)Tools::getValue('id_product',(int)Tools::getValue('id_product_ref'));
                $this->context->smarty->assign(
                    array(
                        'render_html_form' => $form->renderHtmlForm(0,false,$post_fields),
                        'breadcrumb' => $this->module->is17 ? $this->module->getBreadCrumb() : false,
                        'path' => $this->module->getBreadCrumb(),
                        'id_form' => $id_form,
                        'ETS_LIVECHAT_ADMIN_TICKET' => Configuration::get('ETS_LIVECHAT_ADMIN_TICKET'),
                        
                    )
                );
            }
            $this->context->smarty->assign(
                array(
                    'products_licenseBeforeExpried' =>Hook::exec('actionCheckLicenseBeforeExpried',array('id_customer'=>$this->context->customer->id,'list'=>true)),
                    'products_licenseExpried' =>Hook::exec('actionCheckLicenseExpried',array('id_customer'=>$this->context->customer->id,'list'=>true)),
                )
            );
            if ($this->module->is17)
                $this->setTemplate('module:ets_livechat/views/templates/front/form.tpl');
            else
                $this->setTemplate('form16.tpl');
        } else
        {
            Tools::redirect($this->context->link->getPageLink('PageNotFound'));
        }

    }
    public function renderHtmlFormLogin()
    {
        return $this->context->smarty->fetch(_PS_MODULE_DIR_.$this->module->name.'/views/templates/hook/login.tpl');
    }
    public function getAlternativeLangsUrl()
    {
        $alternativeLangs = array();
        $languages = Language::getLanguages(true, $this->context->shop->id);

        if ($languages < 2) {
            return $alternativeLangs;
        }

        foreach ($languages as $lang) {
            $id_form = (int)Tools::getValue('id_form');
            if (!$id_form && ($url_alias = Tools::getValue('url_alias')))
            {
                $form = LC_Ticket_Form::getForm(null, $url_alias);
                if ($form )
                {
                    $id_form = $form['id_form'];
                }
            }
            if($id_form)    
                $alternativeLangs[$lang['language_code']] = $this->module->getFormLink($id_form,array(),$lang['id_lang']);
        }
        return $alternativeLangs;
    }
}