<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) { exit; }
class Ets_livechatInfoModuleFrontController extends ModuleFrontController
{
    public $display_column_left = false;
    public $display_column_right = false;
    public $_errros= array();
    public $_sussecfull;
    public $process;
    public function __construct()
	{
		parent::__construct();
        $this->display_column_right=false;
        $this->display_column_left =false;
		$this->context = Context::getContext();
        $this->process = LC_Ticket_process::getInstance()->setContext(Context::getContext())->setModule($this->module);
	}
	public function initContent()
	{
	    parent::initContent();
        if (!$this->context->customer->isLogged())
            Tools::redirect('index.php?controller=authentication');
        if(Tools::isSubmit('deleteavatar'))
        {
            if(LC_Departments::deleteAvatarCustomer($this->context->customer->id))
            {
                die(
                    json_encode(
                        array(
                            'success' => $this->module->l('Deleted avatar successfully','info'),
                            'customer_avatar_default' => $this->context->link->getMediaLink(_PS_ETS_LIVE_CHAT_IMG_ . 'customeravata.jpg'),
                        )
                    )
                );
            }
        }
        if(Tools::isSubmit('submitCustomerInfo'))
        {
            $imageName='';
            if(isset($_FILES['customer_avata']['tmp_name']) && isset($_FILES['customer_avata']['name']) && $_FILES['customer_avata']['name'])
            {
                $type = Tools::strtolower(Tools::substr(strrchr($_FILES['customer_avata']['name'], '.'), 1));
                $imageName = str_replace(array(' ','(',')','!','@','#','+'),'_',$_FILES['customer_avata']['name']);
                if(!Validate::isFileName($imageName))
                    $this->_errros[] = $this->module->l('Avatar name is not valid','info');
                else
                {
                    $fileName = _PS_ETS_LIVE_CHAT_IMG_DIR_.$imageName;
                    while(file_exists($fileName))
                    {
                        $time=md5(time());
                        for($i=0; $i < 6; $i++)
                        {
                            $index =rand(0,Tools::strlen($time)-1);
                            $imageName =$time[$index].$imageName;
                        }
                        $fileName = _PS_ETS_LIVE_CHAT_IMG_DIR_.$imageName;
                    }
                    if(file_exists($fileName))
                    {
                        $this->_errros[] = $this->module->l('Avatar already exists. Try to rename the file then upload again','info');
                    }
                    else
                    {
            			$imagesize = @getimagesize($_FILES['customer_avata']['tmp_name']);
                        if (!$this->_errros && isset($_FILES['customer_avata']) &&
            				!empty($_FILES['customer_avata']['tmp_name']) &&
            				!empty($imagesize) &&
            				in_array($type, array('jpg', 'gif', 'jpeg', 'png','webp'))
            			)
            			{
            			    $max_size = Configuration::get('ETS_LC_MAX_FILE_MS');
                            $file_size = Tools::ps_round($_FILES['customer_avata']['size']/1048576,2);
                            if($file_size > $max_size && $max_size >0)
                            {
                                $this->_errros[] = $this->module->l('Attachment size exceeds the allowable limit.','info');
                            }
            				else
                            {
                                $temp_name = tempnam(_PS_TMP_IMG_DIR_, 'PS');
                                if($type=='webp')
                                {
                                    if (!move_uploaded_file($_FILES['customer_avata']['tmp_name'], $fileName))
                                        $this->_errros[] = $this->module->l('Cannot upload the file','info');
                                }
                                else
                                {
                                    if (!$temp_name || !move_uploaded_file($_FILES['customer_avata']['tmp_name'], $temp_name))
                                        $this->_errros[] = $this->module->l('Cannot upload the file','info');
                                    elseif (!ImageManager::resize($temp_name, $fileName, 120, 120, $type))
                                        $this->_errros[] = $this->module->l('An error occurred during the image upload process.','info');
                                    if ($temp_name && file_exists($temp_name))
                                        @unlink($temp_name);
                                }
                            }
                        }
                        else
                            $this->_errros[] = $this->module->l('Avatar is not valid','info');
                    }
                }
            }
            if($signature = Tools::getValue('lc_signature'))
            {
                if(!Validate::isCleanHtml($signature))
                    $this->_errros[] = $this->module->l('Signature is not valid','info');
            }
            if(!$this->_errros)
            {
                if(LC_Departments::updateCustomerInfo($this->context->customer->id,$imageName,$signature))
                {
                    die(
                        json_encode(
                            array(
                                'customer_avatar' => $imageName ? $this->context->link->getMediaLink(_PS_ETS_LIVE_CHAT_IMG_.$imageName):'',
                                'customer_avatar_default' => $this->context->link->getMediaLink(_PS_ETS_LIVE_CHAT_IMG_ . 'customeravata.jpg'),
                                'success' => $this->module->l('Updated successfully','info'),
                            )
                        )
                    );
                }
            }
            else
            {
                die(
                    json_encode(
                        array(
                            'errors' => $this->module->displayError($this->_errros),
                        )
                    )
                );
            }
        }
        Tools::redirect($this->context->link->getPageLink('identity'));
    }
}
