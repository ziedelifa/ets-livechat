<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) { exit; }

/**
 * Class AdminLiveChatTicketsController
 * @property \Ets_livechat $module;
 */
class AdminLiveChatTicketsController extends ModuleAdminController
{
    public $_errors = array();
    /*** @var LC_Ticket_process */
    public $process;
    public function __construct()
    {
        header('Referrer-Policy: no-referrer');
        parent::__construct();
        $this->bootstrap = true;
        $this->context->controller->_conf[444] = $this->l('Transfer successful');
    }

    public function init()
    {
        parent::init();
        $this->process = LC_Ticket_process::getInstance()
            ->setContext($this->context)
            ->setModule($this->module);
    }
    public function initContent()
    {
        $this->module->postAdminProcess();
        if(Tools::isSubmit('submitSearchProduct'))
        {
            $query = ($q = Tools::getValue('q')) && Validate::isCleanHtml($q) ? $q : false;
            if($query)
                LC_Ticket_process::ajaxProcessSearchProduct($query);
        }
        if(Tools::isSubmit('get_extra_form'))
        {
            die(
                json_encode(
                    array(
                        'formhtml' => $this->module->renderExtraForm(),
                    )
                )
            );
        }
        if(Tools::isSubmit('get_departments') && ($id_departments= (int)Tools::getValue('id_departments')))
        {
            $this->module->_getFromDepartments($id_departments);
        }
        if(Tools::isSubmit('downloadfile'))
        {
            $this->downloadfile();
        }
        $this->context->smarty->assign(array(
            'menu_top' => $this->module->displayMenuTop(),
            'link' => $this->context->link,
        ));
        if (Tools::isSubmit('getViewListOrder')
            && ($id_customer = (int)Tools::getValue('id_customer'))
            && Validate::isUnsignedInt($id_customer)
            && $id_customer > 0
        ) {
            $this->renderAjax([
                'list_orders' => $this->module->displayListOrder($id_customer, 1, 50),
            ]);
        }

        if (Tools::isSubmit('getMoreViewListOrder')
            && ($id_customer = (int)Tools::getValue('id_customer'))
            && Validate::isUnsignedInt($id_customer)
            && $id_customer > 0
        ) {
            $id_order = (int)Tools::getValue('id_order');
            $count_product = LC_Base::getCountProductOrder($id_customer,$id_order);
            $page = (int)Tools::getValue('page');
            $this->renderAjax([
                'list_orders' => $this->module->displayListOrder($id_customer, $page, 50),
                'load_more' => $count_product > 50 * $page,
                'page_next' => $page + 1,
            ]);
        }

        if ($this->content = $this->renderForm()) {
            $this->context->smarty->assign([
                'content' => $this->content,
            ]);
        } else {
            parent::initContent();
        }
    }
    public function renderForm()
    {
        // add Ticket:
        if (Tools::isSubmit('addticket')) {
            $id_form = (int)Tools::getValue('id_form');
            $errors = array();
            $ticket_add_new = false;
            if (($form = new LC_Ticket_Form($id_form, $this->context->language->id)) && !$form->id) {
                $errors[] = $this->l('Ticket form does not exist');
            }
            if (!$errors && Tools::isSubmit('submit_send_ticket')) {
                $id_customer = (int)Tools::getValue('id_customer_ticket');
                if (!$id_customer || ($customer = new Customer($id_customer)) && !$customer->id) {
                    $this->context->smarty->assign(
                        array(
                            'errors' => $this->module->displayError($this->l('Customer does not exist')),
                        )
                    );
                } else {
                    $fieldValues = Tools::getValue('fields');
                    $department = (int)Tools::getValue('id_departments') ?: 0;
                    $orderRef = Tools::isSubmit('order_ref') ? Tools::getValue('order_ref') : false;
                    $id_product = (int)Tools::getValue('id_product') ?: 0;
                    $id_employee = (int)Tools::getValue('ticket_id_employee') ?: 0;
                    $fieldValues['field_captcha'] = ($field_captcha = Tools::getValue('field_captcha')) && Validate::isCleanHtml($field_captcha) ? $field_captcha:'';
                    $fieldValues['g_recaptcha_response'] = ($g_recaptcha_response = Tools::getValue('g-recaptcha-response')) && Validate::isCleanHtml($g_recaptcha_response) ? $g_recaptcha_response:'';
                    $res = LC_Ticket::getInstance()->addTicket(array(
                        'id_departments' => $department,
                        'order_ref' => $orderRef,
                        'id_product' => $id_product,
                        'fields' => LC_Tools::validateArray($fieldValues) ? $fieldValues : array(),
                        'id_employee' => $id_employee,
                    ), $form, $id_customer);
                    $ticket_add_new = $res && isset($res['ticket']) &&  $res['ticket'] ? $res['ticket'] : false;
                    $this->context->smarty->assign(
                        array(
                            'errors' => $res && isset($res['errors']) && $res['errors'] ? $this->module->displayError($res['errors']) : '',
                            'success' => $res && isset($res['success']) ? $res['success'] :'',
                            'view_ticket' => false,
                        )
                    );
                }
            } elseif ($errors) {
                $this->context->smarty->assign([
                    'errors' => $this->module->displayError($errors),
                ]);
            }
            $this->context->smarty->assign(array(
                'ticket_add_new' =>$ticket_add_new,
            ));
            $post_fields = Tools::getValue('fields');
            if ($idCustomer = (int)Tools::getValue('id_customer')) {
                $customerObj = new Customer($idCustomer);
            } else
                $customerObj = false;
            $post_fields['id_customer'] = $idCustomer;
            $post_fields['search_customer'] = Tools::getValue('search_customer_ticket', $customerObj ? $customerObj->firstname . ' ' . $customerObj->lastname : '');
            $post_fields['id_customer_ticket'] = (int)Tools::getValue('id_customer_ticket', $customerObj ? $customerObj->id : '');
            $post_fields['order_ref'] = ($orderRef = Tools::getValue('order_ref')) && Validate::isReference($orderRef) ? $orderRef :'';
            $post_fields['id_product_ref'] = (int)Tools::getValue('id_product',(int)Tools::getValue('id_product_ref'));
            $this->context->smarty->assign([
                'form_html' => $form->id ? $form->renderHtmlForm(0, true,$post_fields) : '',
            ]);

            return $this->module->display($this->module->getLocalPath(), 'add_ticket.tpl');
        }

        // view Ticket:
        if (Tools::isSubmit('viewticket')
            && ($id_ticket = Tools::getValue('id_ticket'))
            && Validate::isUnsignedInt($id_ticket)
            && $id_ticket > 0
        ) {
            if ($ticket = $this->process->checkAccessTicket($id_ticket)) {
                // Make read ticket
                LC_Ticket::makeReadTicket($id_ticket, $this->process->isAdmin() || $this->process->isManagerTicket() && (int)$ticket['id_customer'] !== (int)$this->context->customer->id ? 1 : 0);
                $nbMessages = (int)Configuration::get('ETS_LC_NUMBER_TICKET_MESSAGES');
                $countMessages = $this->process->getMessagesTicket($ticket, false, false, false, true);
                if ($countMessages > $nbMessages) {
                    $start = $countMessages - $nbMessages;
                } else {
                    $start = 0;
                }
                $messages = $this->process->getMessagesTicket($ticket, false, $nbMessages ?: false, $start, false);
                if ($fields = LC_Ticket_field::getTicketFields($id_ticket)) {
                    foreach ($fields as &$field) {
                        if ($field['type'] == 'file' && $field['value']) {
                            if ($field['id_download'] > 0) {
                                $download = new LC_Download($field['id_download']);
                                $field['file_size'] = $download->file_size;
                            }
                            $field['link_download'] = $this->context->link->getAdminLink('AdminLiveChatTickets').'&downloadfile=' . md5(_COOKIE_KEY_ . $field['id_download']);
                        }
                    }
                }
                if ($this->process->isManagerTicket()
                    && ($employees = LC_Departments::getEmployeeDepartments())
                    && is_array($employees)
                    && count($employees) > 0
                ) {
                    foreach ($employees as &$employee) {
                        $employee_departments = LC_Departments::getDepartmentByEmployee((int)$employee['id_employee']);
                        $employee['departments'] = $employee_departments;
                    }
                }
                $link_customer = $this->context->link->getAdminLink('AdminCustomers', true, ['route' => 'admin_customers_view', 'customerId' => $ticket['id_customer']], ['id_customer' => (int)$ticket['id_customer'], 'viewcustomer' => '']);
                if ($ticket['id_product']) {
                    $this->context->smarty->assign(array(
                        'product_ref' => new Product($ticket['id_product'], false, $this->context->language->id)
                    ));
                }
                // get country:
                if (isset($ticket['id_customer'])
                    && $ticket['id_customer'] > 0
                    && ($id_address = Address::getFirstCustomerAddressId($ticket['id_customer']))
                    && ($address = new Address($id_address))
                    && Validate::isLoadedObject($address)
                ) {
                    $country = new Country($address->id_country, $this->context->language->id);
                }
                // Order
                if (isset($ticket['id_order'])
                    && $ticket['id_order'] > 0
                ) {
                    $order = new Order($ticket['id_order']);
                    $ticket['reference'] = $order->reference;
                }
                $form_class = new LC_Ticket_form($ticket['id_form']);
                if ($this->process->isManagerTicket()) {

                    $allow_staff_upload_file = $form_class->allow_staff_upload_file;
                } else {
                    $allow_staff_upload_file = 1;
                }
                if(isset($ticket['id_lang']) && $ticket['id_lang'])
                    $language = new Language($ticket['id_lang'],$this->context->language->id);
                $tpl_vars = [
                    'ticket' => $ticket,
                    'has_order' => LC_Ticket::getCountOrder((int)$ticket['id_customer']),
                    'has_product_expried' => Hook::exec('actionCheckLicenseExpried',array('id_customer'=>$ticket['id_customer'])),
                    'is_verified' => LC_Base::checkCustomerISVerified($ticket['id_customer']),
                    'messages' => $messages,
                    'fields' => $fields,
                    'employees' => isset($employees) ? $employees :false,
                    'success' => $this->context->cookie->_success,
                    'warning' => $this->context->cookie->_warning,
                    'link_customer' => $link_customer,
                    'departments' => LC_Departments::getAllDepartments(),
                    'form_class' => $form_class,
                    'reply_customer' => LC_Ticket::getEmailCustomer($ticket) || $form_class->send_mail_reply_customer,
                    'ETS_LC_AVATAR_IMAGE_TYPE' => Configuration::get('ETS_LC_AVATAR_IMAGE_TYPE'),
                    'link_basic' => $this->module->getBaseLink(),
                    'allow_staff_upload_file' => $allow_staff_upload_file,
                    'country_name' => isset($country) && $country ? $country->name : '',
                    'lang_name' => isset($language) && $language ? $language->name : '',
                    'load_more' => $nbMessages && $countMessages > $nbMessages ? true : false,
                ];
                $this->context->smarty->assign($tpl_vars);
                $this->context->cookie->_success = '';
                $this->context->cookie->_warning = '';
                return $this->module->display($this->module->getLocalPath(), 'ticket.tpl');
            } else {
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminLiveChatTickets'));
            }
        }

        return '';
    }

    public function renderList()
    {
        if(!$this->module->active)
            return $this->module->displayWarning(sprintf($this->l('You must enable "%s" module to configure its features'),$this->module->displayName));
        // render List:
        $filter = '';
        $post_value = array();
        if (!$this->context->controller->errors) {
            if (($id_ticket = Tools::getValue('id_ticket')) || $id_ticket != '') {
                if (Validate::isInt($id_ticket)) {
                    $filter .= ' AND fm.id_message=' . (int)$id_ticket;
                }
                $post_value['id_ticket'] = $id_ticket;
            }
        }
        if (($customer_name = Tools::getValue('customer_name')) || $customer_name != '') {
            if (Validate::isCleanHtml($customer_name)) {
                $filter .= ' AND (CONCAT(c.firstname," ",c.lastname) LIKE "' . pSQL($customer_name) . '%" OR fmf2.value LIKE "' . pSQL($customer_name) . '%" OR c.email LIKE "' . pSQl($customer_name) . '%" OR fmf1.value LIKE "' . pSQl($customer_name) . '%") ';
            }
            $post_value['customer_name'] = $customer_name;
        }
        if (($form_title = Tools::getValue('form_title')) && $form_title != '') {
            if (Validate::isCleanHtml($form_title)) {
                $filter .= ' AND fl.title LIKE "%' . pSQL($form_title) . '%"';
            }
            $post_value['form_title'] = $form_title;
        }
        if (($priority = Tools::getValue('priority')) || $priority != '') {
            if (Validate::isInt($priority)) {
                $filter .= ' AND fm.priority="' . (int)$priority . '" ';
            }
            $post_value['priority'] = (int)$priority;
        }
        if (($status = Tools::getValue('status')) || $status != '') {
            if (Validate::isCleanHtml($status)) {
                $filter .= ' AND fm.status="' . pSQL($status) . '"';
            }
            $post_value['status'] = $status;
        }
        if (($date_add_from = Tools::getValue('date_add_from')) || $date_add_from != '') {
            if (Validate::isDate($date_add_from)) {
                $filter .= ' AND fm.date_customer_update >= "' . pSQL($date_add_from) . ' 00:00:00"';
            }
            $post_value['date_add_from'] = $date_add_from;
        }
        if (($date_add_to = Tools::getValue('date_add_to')) || $date_add_to != '') {
            if (Validate::isDate($date_add_to)) {
                $filter .= ' AND fm.date_customer_update <= "' . pSQL($date_add_to) . ' 23:59:59"';
            }
            $post_value['date_add_to'] = $date_add_to;
        }
        if (($subject = Tools::getValue('subject')) || $subject != '') {
            if (Validate::isCleanHtml($subject))
                $filter .= ' AND fm.subject LIKE "' . pSQL($subject) . '%"';
            $post_value['subject'] = $subject;
        }
        if (($replied = Tools::getValue('replied')) || $replied != '') {
            if (Validate::isInt($replied)) {
                $filter .= ' AND fm.replied =' . (int)$replied;
            }
            $post_value['replied'] = $replied;
        }
        $sort = Tools::getValue('sort', 'date_customer_update');
        if (!in_array($sort, array('date_customer_update', 'status', 'priority', 'form_title', 'customer_name', 'id_message')))
            $sort = 'date_customer_update';
        $sort_type = Tools::getValue('sort_type', 'desc');
        if (!in_array($sort_type, array('desc', 'asc')))
            $sort_type = 'desc';
        $page = (int)Tools::getValue('page');
        if ($page < 1)
            $page = 1;

        $totalRecords = (int)LC_Ticket::getListTickets(true, $filter, false, false, false, 0, $this->context);

        $paggination = new LC_paggination_class();
        $paggination->total = $totalRecords;
        $paggination->url = $this->context->link->getAdminLink('AdminLiveChatTickets') . '&page=_page_' . $this->getUrlExtra($post_value);
        $paggination->limit = 20;
        $totalPages = ceil($totalRecords / $paggination->limit);
        if ($page > $totalPages)
            $page = $totalPages;
        $paggination->page = $page;
        $start = $paggination->limit * ($page - 1);
        if ($start < 0)
            $start = 0;
        $paggination->text = $this->l('Showing {start} to {end} of {total} ({pages} Pages)');
        $paggination->style_links = $this->l('links');
        $paggination->style_results = 'results';

        $tickets = LC_Ticket::getListTickets(false, $filter, $sort, $sort_type, $paggination->limit, $start, $this->context);
        $forms = LC_Ticket_form::getForms();
        if ($forms) {
            foreach ($forms as &$form) {
                $form['link'] = $this->context->link->getAdminLink('AdminLiveChatTickets') . '&addticket&id_form=' . $form['id_form'];
            }
        }

        $display_col_order = false;
        $display_col_product = false;
        $display_col_staff = false;
        $ETS_LC_DISPLAY_PRODUCTS_IN_LIST_TICKET = (int)Configuration::get('ETS_LC_DISPLAY_PRODUCTS_IN_LIST_TICKET');
        $ETS_LC_DISPLAY_STAFF_IN_LIST_TICKET = (int)Configuration::get('ETS_LC_DISPLAY_STAFF_IN_LIST_TICKET');
        $ETS_LC_DISPLAY_ORDER_IN_LIST_TICKET = (int)Configuration::get('ETS_LC_DISPLAY_ORDER_IN_LIST_TICKET');
        if ($tickets) {
            $countries = array();
            foreach ($tickets as &$ticket) {
                $id_note_max = LC_Note::maxId((int)$ticket['id_message']);
                if ($id_note_max > 0) {
                    $ticket['note'] = LC_Note::getRowById($id_note_max);
                    $ticket['note']['link_download'] = $this->context->link->getAdminLink('AdminLiveChatTickets').'&downloadfile=' . md5(_COOKIE_KEY_ . $ticket['note']['id_download']);
                }
                $ticket['content'] = LC_Ticket::getContentTicket($ticket);
                if (isset($ticket['id_customer'])
                    && $ticket['id_customer'] > 0
                ) {
                    $ticket['link_customer'] = $this->context->link->getAdminLink('AdminCustomers', true, ['route' => 'admin_customers_view', 'customerId' => $ticket['id_customer']], ['id_customer' => (int)$ticket['id_customer'], 'viewcustomer' => '']);
                    $id_address = Address::getFirstCustomerAddressId($ticket['id_customer'], true);
                    if ($id_address
                        && ($address = new Address($id_address))
                        && $address->id_country
                    ) {
                        if (!isset($countries[$address->id_country])) {
                            $countries[$address->id_country] = new Country($address->id_country, $this->context->language->id);
                        }
                        $ticket['country_name'] = $countries[$address->id_country]->name;
                    }
                }
                if(isset($ticket['id_lang']) && $ticket['id_lang'])
                {
                    $language = new Language($ticket['id_lang'],$this->context->language->id);
                    $ticket['lang_name'] = $language->iso_code;
                }
                if ($ETS_LC_DISPLAY_PRODUCTS_IN_LIST_TICKET) {
                    if ($ticket['id_product']) {
                        $display_col_product = true;
                    }
                    $ticket['products'] = $this->module->getProductTicket($ticket['id_product']);
                }
                if ($ETS_LC_DISPLAY_STAFF_IN_LIST_TICKET) {
                    $ticket['staff'] = LC_Ticket::getLastStaff($ticket['id_message']);
                    if(!$ticket['staff'])
                    {
                        if($ticket['id_employee'] > 0 && ($employee = new Employee($ticket['id_employee'])) && Validate::isLoadedObject($employee) && $employee->active)
                        {
                            $id_employee = $ticket['id_employee'];
                            $ticket['staff'] = LC_Departments::getStaffByEmployee($id_employee);
                        }
                    }
                    $display_col_staff = true;
                }
                if (isset($ticket['reference']) && $ticket['reference'] && $ETS_LC_DISPLAY_ORDER_IN_LIST_TICKET) {
                    $display_col_order = true;
                    $ticket['reference'] = $this->module->displayText($ticket['reference'],'a','',array('href' => $this->module->getLinkOrderAdmin($ticket['id_order'])));
                }
                $ticket['has_order'] = LC_Ticket::getCountOrder((int)$ticket['id_customer']);
                $ticket['has_product_expried'] = Hook::exec('actionCheckLicenseExpried',array('id_customer'=>$ticket['id_customer']));
            }
        }
        $this->context->smarty->assign(
            array(
                'ETS_LC_DISPLAY_PRODUCTS_IN_LIST_TICKET' => $ETS_LC_DISPLAY_PRODUCTS_IN_LIST_TICKET,
                'ETS_LC_DISPLAY_ORDER_IN_LIST_TICKET' => $ETS_LC_DISPLAY_ORDER_IN_LIST_TICKET,
                'display_col_product' => $display_col_product,
                'display_col_order' => $display_col_order,
                'display_col_staff' => $display_col_staff,
                'tickets' => $tickets,
                'post_value' => $post_value,
                'sort' => $sort,
                'sort_type' => $sort_type,
                'pagination_text' => $paggination->render(),
                'forms' => $forms,
                'new_ticket_link' => count($forms) == 1 ? $forms[0]['link'] : false,
                'ps16' => version_compare(_PS_VERSION_, '1.6', '>='),
                'totalRecords' => $totalRecords,
            )
        );
        return $this->module->display(_PS_MODULE_DIR_ . $this->module->name . DIRECTORY_SEPARATOR . $this->module->name . '.php', 'tickets.tpl');
    }

    public function getUrlExtra($post_value)
    {
        if ($post_value) {
            $url = '';
            foreach ($post_value as $key => $value) {
                $url .= '&' . $key . '=' . $value;
            }
            return $url;
        }
        return '';
    }
    public function renderAjax($data)
    {
        die(json_encode($data));
    }
    public function downloadfile()
    {
        $process = LC_Ticket_process::getInstance()->setModule($this->module)->setContext($this->context);
        if (Tools::isSubmit('downloadfile')
            && ($downloadfile = Tools::getValue('downloadfile'))
            && Validate::isCleanHtml($downloadfile)
        ) {
            return $process->downloadFile($downloadfile);
        }
    }
}