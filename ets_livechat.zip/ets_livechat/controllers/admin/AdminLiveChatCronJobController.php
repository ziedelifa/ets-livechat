<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) { exit; }
class AdminLiveChatCronJobController extends ModuleAdminController
{
    public $errors= array();
    public function __construct()
    {
       parent::__construct();
       $this->bootstrap = true;
       $this->context = Context::getContext();
       if($this->context->employee->id_profile!=1)
            Tools::redirectAdmin($this->context->link->getAdminLink('AdminLiveChatTickets'));
    }
    public function initContent()
    {
        parent::initContent();
        if(Tools::isSubmit('ETS_LC_SAVE_CRONJOB_LOG'))
        {
            $ETS_LC_SAVE_CRONJOB_LOG = (int)Tools::getValue('ETS_LC_SAVE_CRONJOB_LOG');
            Configuration::updateGlobalValue('ETS_LC_SAVE_CRONJOB_LOG',$ETS_LC_SAVE_CRONJOB_LOG);
            die(
                json_encode(
                    array(
                        'success' => $this->l('Updated successfully'),
                    )
                )
            );
        }
        if(Tools::isSubmit('etslcSubmitClearLog'))
        {
            if(file_exists(_PS_CACHE_DIR_.'ets_livechat_cronjob_log.txt'))
                @unlink(_PS_CACHE_DIR_.'ets_livechat_cronjob_log.txt');
            die(
                json_encode(
                    array(
                        'success' => $this->l('Clear log successfully'),
                    )
                )
            );
        }
        if(Tools::isSubmit('etslcSubmitUpdateToken'))
        {
            $ETS_LC_CRONJOB_TOKEN = Tools::getValue('ETS_LC_CRONJOB_TOKEN');
            if(!$ETS_LC_CRONJOB_TOKEN)
                $error = $this->l('Token is required');
            elseif(!Validate::isCleanHtml($ETS_LC_CRONJOB_TOKEN))
                $error = $this->l('Token is not valid');
            else
            {
                Configuration::updateGlobalValue('ETS_LC_CRONJOB_TOKEN',$ETS_LC_CRONJOB_TOKEN);
                die(
                    json_encode(
                        array(
                            'success' => $this->l('Updated successfully'),
                        )
                    )
                );
            }
            if(isset($error) && $error)
            {
                die(
                    json_encode(
                        array(
                            'errors' => $error,
                        )
                    )
                );
            }   
        }
    }
    public function renderList() 
    {
        if(!$this->module->active)
            return $this->module->displayWarning(sprintf($this->l('You must enable "%s" module to configure its features'),$this->module->displayName));
        if(!Configuration::getGlobalValue('ETS_LC_CRONJOB_TOKEN'))
            Configuration::updateGlobalValue('ETS_LC_CRONJOB_TOKEN',Tools::passwdGen(12));
        $cronjob_last= '';
        $run_cronjob = false;
        if($cronjob_time = Configuration::getGlobalValue('ETS_LC_CRONJOB_TIME'))
        {
            $last_time = strtotime($cronjob_time);
            $time = strtotime(date('Y-m-d H:i:s'))-$last_time;
            if($time <= 43200 && $time)
                $run_cronjob = true;
            else
                $run_cronjob = false;
            if($time > 86400)
                $cronjob_last = Tools::displayDate($cronjob_time,null,true);
            elseif($time)
            {
                if($hours =floor($time/3600))
                {
                    $cronjob_last .= $hours.' '.$this->l('hours').' ';
                    $time = $time%3600;
                }
                if($minutes = floor($time/60))
                {
                    $cronjob_last .= $minutes.' '.$this->l('minutes').' ';
                    $time = $time%60;
                }
                if($time)
                    $cronjob_last .= $time.' '.$this->l('seconds').' ';
                $cronjob_last .= $this->l('ago');
            }    
        }
        $this->context->smarty->assign(
            array(
                'menu_top' => $this->module->displayMenuTop(),
                'ETS_LC_MODULE_URL' => $this->module->url_module,
                'dir_cronjob' => _PS_MODULE_DIR_.'ets_livechat/cronjob.php',
                'link_conjob' => $this->module->getBaseLink().'/modules/'.$this->module->name.'/cronjob.php',
                'ETS_LC_CRONJOB_TOKEN' => Tools::getValue('ETS_LC_CRONJOB_TOKEN',Configuration::getGlobalValue('ETS_LC_CRONJOB_TOKEN')),
                'cronjob_log' => file_exists(_PS_CACHE_DIR_.'ets_livechat_cronjob_log.txt') ? Tools::file_get_contents(_PS_CACHE_DIR_.'ets_livechat_cronjob_log.txt'):'',
                'ETS_LC_SAVE_CRONJOB_LOG' => Configuration::getGlobalValue('ETS_LC_SAVE_CRONJOB_LOG'),
                'run_cronjob' => $run_cronjob,
                'cronjob_last' => $cronjob_last,
                'php_path' => (defined('PHP_BINDIR') && PHP_BINDIR && is_string(PHP_BINDIR) ? PHP_BINDIR.'/' : '').'php ',
            )
        );
        return $this->module->display(_PS_MODULE_DIR_.$this->module->name.DIRECTORY_SEPARATOR.$this->module->name.'.php', 'cronjob.tpl');
    }
}