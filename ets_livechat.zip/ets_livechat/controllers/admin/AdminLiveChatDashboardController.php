<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) { exit; }
class AdminLiveChatDashboardController extends ModuleAdminController
{
    public $errors= array();
    public function __construct()
    {
       header('Referrer-Policy: no-referrer');
       parent::__construct();
       $this->bootstrap = true;
       $this->context = Context::getContext();
       if($this->context->employee->id_profile!=1)
            Tools::redirectAdmin($this->context->link->getAdminLink('AdminLiveChatTickets'));
    }
    public function initContent()
    {
        $data_conversations=array();
        $data_receive_messages=array();
        $data_replied_messages=array();
        $data_tickets=array();
        $label_datas=array();
        $data_open_tickets=array();
        $data_close_tickets=array();
        $submit=false;
        $recently_customers= array();
        $count_recently_customers=0;
        $year_min_conversation = LC_Conversation::getMinYear();
        $year_min_ticket= LC_Ticket::getMinYear();
        if(!$year_min_conversation)
            $year_min = $year_min_ticket;
        elseif(!$year_min_ticket)
            $year_min = $year_min_conversation;
        elseif($year_min_conversation < $year_min_ticket)
            $year_min = $year_min_conversation;
        else
            $year_min = $year_min_ticket;
        if(!$year_min)
            $year_min = date('Y');
        $actionSubmitChart = Tools::getValue('actionSubmitChart');
        if(Tools::isSubmit('submitDateWeek') || $actionSubmitChart=='submitDateWeek')
        {
            $date =date('Y-m-d');
            $dayofweek = date('w', strtotime($date));
            if($dayofweek==0)
               $dayofweek=6;
            else
                $dayofweek--; 
            $days = array($this->l('Mon'), $this->l('Tue'), $this->l('Wed'),$this->l('Thu'),$this->l('Fri'), $this->l('Sat'),$this->l('Sun'));        
            for($day=0; $day < 7; $day++)
            {
                $label_datas[]=$days[$day];
                $datetime = date('Y-m-d', strtotime(($day - $dayofweek).' day', strtotime($date)));
                $data_tickets[]= LC_Ticket::getCountTicket(' AND date_add <= "'.pSQL($datetime).' 23:59:59" AND date_add >="'.pSQL($datetime).' 00:00:00"');
                $data_open_tickets[]= LC_Ticket::getCountTicket(' AND date_add <= "'.pSQL($datetime).' 23:59:59" AND date_add >="'.pSQL($datetime).' 00:00:00" AND status="open"');
                $data_close_tickets[]=LC_Ticket::getCountTicket(' AND date_add <= "'.pSQL($datetime).' 23:59:59" AND date_add >="'.pSQL($datetime).' 00:00:00" AND status="close"');
                $data_conversations[]= $this->module->getCountConversation(' AND datetime_added <="'.pSQL($datetime).' 23:59:59" AND datetime_added >="'.pSQL($datetime).' 00:00:00"');
                $data_receive_messages[] = $this->module->getCountMessage(' AND m.id_employee=0 AND m.datetime_added <="'.pSQL($datetime).' 23:59:59" AND m.datetime_added >="'.pSQL($datetime).' 00:00:00"');
                $data_replied_messages[]= $this->module->getCountMessage(' AND m.id_employee!=0 AND m.datetime_added <="'.pSQL($datetime).' 23:59:59" AND m.datetime_added >="'.pSQL($datetime).' 00:00:00"');
            }
            $recently_customers = LC_Base::getCustomerLoginSocial(false,' AND s.date_login <="'.pSQL(date('Y-m-d', strtotime((6 - (int)$dayofweek).' day', strtotime($date)))).' 23:59:59" AND s.date_login >="'.pSQL(date('Y-m-d', strtotime((0 - (int)$dayofweek).' day', strtotime($date)))).' 00:00:00"',0,5);
            $count_recently_customers = LC_Base::getCustomerLoginSocial(true,' AND s.date_login <="'.pSQL(date('Y-m-d', strtotime((6 - (int)$dayofweek).' day', strtotime($date)))).' 23:59:59" AND s.date_login >="'.pSQL(date('Y-m-d', strtotime((0 - (int)$dayofweek).' day', strtotime($date)))).' 00:00:00"');
            $submit=true;
        }
        elseif(Tools::isSubmit('submitDateMonth') || $actionSubmitChart=='submitDateMonth')
        {
            $month = date('m');
            $year= date('Y');
            $days =(int)date('t', mktime(0, 0, 0, (int)$month, 1, (int)$year));
            if($days)
            {
                for($day=1; $day<=$days;$day++)
                {
                    $label_datas[]=$day;
                    $data_conversations[]=$this->module->getCountConversation(' AND YEAR(datetime_added)="'.(int)$year.'" AND MONTH(datetime_added)="'.(int)$month.'" AND DAY(datetime_added)="'.(int)$day.'"');
                    $data_receive_messages[]= $this->module->getCountMessage(' AND m.id_employee=0 AND YEAR(m.datetime_added)="'.(int)$year.'" AND MONTH(m.datetime_added)="'.(int)$month.'" AND DAY(m.datetime_added)="'.(int)$day.'"');
                    $data_replied_messages[]= $this->module->getCountMessage(' AND m.id_employee!=0 AND YEAR(m.datetime_added)="'.(int)$year.'" AND MONTH(m.datetime_added)="'.(int)$month.'" AND DAY(m.datetime_added)="'.(int)$day.'"');
                    $data_tickets[]=LC_Ticket::getCountTicket(' AND YEAR(date_add)="'.(int)$year.'" AND MONTH(date_add)="'.(int)$month.'" AND DAY(date_add)="'.(int)$day.'"');
                    $data_open_tickets[]=LC_Ticket::getCountTicket(' AND YEAR(date_add)="'.(int)$year.'" AND MONTH(date_add)="'.(int)$month.'" AND DAY(date_add)="'.(int)$day.'" AND status="open"');
                    $data_close_tickets[]=LC_Ticket::getCountTicket(' AND YEAR(date_add)="'.(int)$year.'" AND MONTH(date_add)="'.(int)$month.'" AND DAY(date_add)="'.(int)$day.'" AND status="close"');
                }
            }
            $recently_customers = LC_Base::getCustomerLoginSocial(false,' AND YEAR(s.date_login)="'.(int)$year.'" AND MONTH(s.date_login) = "'.(int)$month.'"',0,5);
            $count_recently_customers = LC_Base::getCustomerLoginSocial(true,' AND YEAR(s.date_login)="'.(int)$year.'" AND MONTH(s.date_login) = "'.(int)$month.'"');
            $submit=true;
        }
        elseif(Tools::isSubmit('submitDateYear') || $actionSubmitChart=='submitDateYear' || ((Tools::isSubmit('submitDateAll') || $actionSubmitChart=='submitDateAll') && $year_min == date('Y')) )
        {
            $year= date('Y');
            $months=Tools::dateMonths();
            foreach($months as $key=>$month)
            {
                $label_datas[]=$key;
                $data_conversations[]=$this->module->getCountConversation(' AND YEAR(datetime_added)="'.(int)$year.'" AND MONTH(datetime_added)="'.(int)$key.'"');
                $data_receive_messages[] =$this->module->getCountMessage(' AND m.id_employee=0 AND YEAR(m.datetime_added)="'.(int)$year.'" AND MONTH(m.datetime_added)="'.(int)$key.'"');
                $data_replied_messages[] =$this->module->getCountMessage(' AND m.id_employee!=0 AND YEAR(m.datetime_added)="'.(int)$year.'" AND MONTH(m.datetime_added)="'.(int)$key.'"');
                $data_tickets[]=LC_Ticket::getCountTicket(' AND YEAR(date_add)="'.(int)$year.'" AND MONTH(date_add)="'.(int)$key.'"');
                $data_open_tickets= LC_Ticket::getCountTicket(' AND YEAR(date_add)="'.(int)$year.'" AND MONTH(date_add)="'.(int)$key.'" AND status="open"');
                $data_close_tickets = LC_Ticket::getCountTicket(' AND YEAR(date_add)="'.(int)$year.'" AND MONTH(date_add)="'.(int)$key.'" AND status="close"');
            }
            $recently_customers = LC_Base::getCustomerLoginSocial(false,' AND YEAR(s.date_login)="'.(int)$year.'"',0,5);
            $count_recently_customers = LC_Base::getCustomerLoginSocial(true,' AND YEAR(s.date_login)="'.(int)$year.'"');
            $submit=true;
        }
        elseif(Tools::isSubmit('submitDateAll') || $actionSubmitChart=='submitDateAll')
        {
            for($year = $year_min; $year<=date('Y');$year++)
            {
                $label_datas[]=$year;
                $data_conversations[]=$this->module->getCountConversation(' AND YEAR(datetime_added)="'.(int)$year.'"');
                $data_receive_messages[] =$this->module->getCountMessage(' AND m.id_employee=0 AND YEAR(m.datetime_added)="'.(int)$year.'"');
                $data_replied_messages[] =$this->module->getCountMessage(' AND m.id_employee!=0 AND YEAR(m.datetime_added)="'.(int)$year.'"');
                $data_tickets[]=LC_Ticket::getCountTicket(' AND YEAR(date_add)="'.(int)$year.'"');
                $data_open_tickets= LC_Ticket::getCountTicket(' AND YEAR(date_add)="'.(int)$year.'" AND status="open"');
                $data_close_tickets = LC_Ticket::getCountTicket(' AND YEAR(date_add)="'.(int)$year.'" AND status="close"');
            }
            $recently_customers = LC_Base::getCustomerLoginSocial(false,false,0,5);
            $count_recently_customers = LC_Base::getCustomerLoginSocial(true,false);
            $submit=true;
        }
        if($submit && Tools::isSubmit('ajax'))
        {
            die(
                json_encode(
                    array(
                        'data_conversations' =>array($data_conversations,$data_receive_messages,$data_replied_messages),
                        'data_tickets'=>array($data_tickets,$data_open_tickets,$data_close_tickets),
                        'label_datas' => $label_datas,
                        'recently_customer' => $this->module->displayRecentlyCustomer($count_recently_customers,$recently_customers),
                    )
                )
            );
        }
        $this->module->setAdminForder();
        parent::initContent();
    }
    public function renderList() 
    {
        if(!$this->module->active)
            return $this->module->displayWarning(sprintf($this->l('You must enable "%s" module to configure its features'),$this->module->displayName));
        $data_conversations=array();
        $data_receive_messages=array();
        $data_replied_messages=array();
        $data_tickets=array();
        $data_open_tickets=array();
        $data_close_tickets=array();
        $chart_labels = array();
        $date =date('Y-m-d');
        $dayofweek = date('w', strtotime($date));
        if($dayofweek==0)
           $dayofweek=6;
        else
            $dayofweek--; 
        $days = array($this->l('Mon'), $this->l('Tue'), $this->l('Wed'),$this->l('Thu'),$this->l('Fri'), $this->l('Sat'),$this->l('Sun'));        
        for($day=0; $day<7; $day++)
        {
            $chart_labels[]= $days[$day];
            $datetime = date('Y-m-d', strtotime(($day - $dayofweek).' day', strtotime($date)));
            $data_tickets[]=LC_Ticket::getCountTicket(' AND date_add <= "'.pSQL($datetime).' 23:59:59" AND date_add >="'.pSQL($datetime).' 00:00:00"');
            $data_open_tickets[]=LC_Ticket::getCountTicket(' AND date_add <= "'.pSQL($datetime).' 23:59:59" AND date_add >="'.pSQL($datetime).' 00:00:00" AND status="open"');
            $data_close_tickets[] = LC_Ticket::getCountTicket(' AND date_add <= "'.pSQL($datetime).' 23:59:59" AND date_add >="'.pSQL($datetime).' 00:00:00" AND status="close"');
            $data_conversations[]= $this->module->getCountConversation(' AND datetime_added <="'.pSQL($datetime).' 23:59:59" AND datetime_added >="'.pSQL($datetime).' 00:00:00"');
            $data_receive_messages[]=  $this->module->getCountMessage(' AND m.id_employee=0 AND m.datetime_added <= "'.pSQL($datetime).' 23:59:59" AND m.datetime_added >= "'.pSQL($datetime).' 00:00:00"');
            $data_replied_messages[]= $this->module->getCountMessage(' AND m.id_employee!=0 AND m.datetime_added <= "'.pSQL($datetime).' 23:59:59" AND m.datetime_added >= "'.pSQL($datetime).' 00:00:00"');
        }
        $login_customers= LC_Base::getCustomerLoginSocial(false,' AND s.date_login <="'.pSQL(date('Y-m-d', strtotime((6 - (int)$dayofweek).' day', strtotime($date)))).' 23:59:59" AND s.date_login >="'.pSQL(date('Y-m-d', strtotime((0 - (int)$dayofweek).' day', strtotime($date)))).' 00:00:00"',0,5);
        $conversation_datasets=array(
            array(
                'label'=> $this->l('Conversations'),
                'data' =>$data_conversations,
                'backgroundColor'=>'rgba(163,225,212,0.3)',
                'borderColor'=>'rgba(163,225,212,1)',
                'borderWidth'=>1,
                'pointRadius' => 2,
            ),
            array(
                'label'=> $this->l('Received messages'),
                'data' =>$data_receive_messages,
                'backgroundColor'=>'rgba(253,193,7,0.3)',
                'borderColor'=>'rgba(253,193,7,1)',
                'borderWidth'=>1,
                'pointRadius' => 2,
            ),
            array(
                'label'=> $this->l('Replied messages'),
                'data' =>$data_replied_messages,
                'backgroundColor'=>'rgba(139,195,72,0.3)',
                'borderColor'=>'rgba(139,195,72,1)',
                'borderWidth'=>1,
                'pointRadius' => 2,
            )
        );
        $ticket_datasets =array(
            array(
                'label'=> $this->l('Received tickets'),
                'data' =>$data_tickets,
                'backgroundColor'=>'rgba(163,225,212,0.3)',
                'borderColor'=>'rgba(163,225,212,1)',
                'fill'=>true,
                'borderWidth'=>1,
                'pointRadius' => 2,
            ),
            array(
                'label'=> $this->l('Open tickets'),
                'data' =>$data_open_tickets,
                'backgroundColor'=>'rgba(253,193,7,0.3)',
                'borderColor'=>'rgba(253,193,7,1)',
                'borderWidth'=>1,
                'pointRadius' => 2,
                'fill'=>true,
            ),
            array(
                'label'=> $this->l('Solved tickets'),
                'data' =>$data_close_tickets,
                'backgroundColor'=>'rgba(139,195,72,0.3)',
                'borderColor'=>'rgba(139,195,72,1)',
                'borderWidth'=>1,
                'pointRadius' => 2,
                'fill'=>true,
            )
        );  
        $count_login_customers = LC_Base::getCustomerLoginSocial(true,' AND s.date_login <="'.pSQL(date('Y-m-d', strtotime((6 - (int)$dayofweek).' day', strtotime($date)))).' 23:59:59" AND s.date_login >="'.pSQL(date('Y-m-d', strtotime((0 - (int)$dayofweek).' day', strtotime($date)))).' 00:00:00"');
        $this->context->smarty->assign(
            array(
                'menu_top' => $this->module->displayMenuTop(),
                'ETS_LC_MODULE_URL' => $this->module->url_module,
                'countConversation'=> $this->module->getCountConversation(),
                'countConversationInMonth' => $this->module->getCountConversation(' AND datetime_added >="'.pSQL(date('Y-m-01')).' 00:00:00" AND datetime_added <= "'.pSQL(date('Y-m-d')).' 23:59:59"'),
                'countReceivedTicket' => LC_Ticket::getCountTicket(),
                'countMessages'=>  $this->module->getCountMessage(false),
                'countMessagesInMonth'=>$this->module->getCountMessage(' AND m.datetime_added >= "'.pSQL(date('Y-m-01')).' 00:00:00" AND m.datetime_added <= "'.pSQL(date('Y-m-d')).' 23:59:59"'),
                'countReceivedTicketInMonth' => LC_Ticket::getCountTicket(' AND date_add >="'.pSQL(date('Y-m-01')).' 00:00:00" AND date_add <= "'.pSQL(date('Y-m-d')).' 23:59:59"'),
                'countOpenTicket' => LC_Ticket::getCountTicket(' AND t.status="open"'),
                'countOpenTicketInMonth' => LC_Ticket::getCountTicket(' AND t.status="open" AND date_add >="'.pSQL(date('Y-m-01')).' 00:00:00" AND date_add <= "'.pSQL(date('Y-m-d')).' 23:59:59"'),
                'countSolvedTicket' => LC_Ticket::getCountTicket(' AND t.status="close"'),
                'countSolvedTicketInMouth' => LC_Ticket::getCountTicket(' AND t.status="close" AND date_add >="'.pSQL(date('Y-m-01')).' 00:00:00" AND date_add <= "'.pSQL(date('Y-m-d')).' 23:59:59"'),
                'action' => $this->context->link->getAdminLink('AdminLiveChatDashboard'),
                'conversation_datasets'=>$conversation_datasets,  
                'ticket_datasets' => $ticket_datasets,
                'recentlyConversations' => $this->getRecentlyConversation(),
                'recentlyTickets' => $this->getRecentlyTicket(),
                'active_staffs' => LC_Departments::getStaff(),
                'chart_labels' => $chart_labels, 
                'recently_customer' => $this->module->displayRecentlyCustomer($count_login_customers,$login_customers),   
                'ETS_DISPLAY_DASHBOARD_ONLY' => Configuration::get('ETS_DISPLAY_DASHBOARD_ONLY'),                
            )
        );
        return $this->module->display(_PS_MODULE_DIR_.$this->module->name.DIRECTORY_SEPARATOR.$this->module->name.'.php', 'dashboard.tpl');
    }
    public function getRecentlyConversation()
    {
        $conversations= LC_Conversation::getRecentlyConversation();
        if($conversations)
        {
            foreach($conversations as &$conversation)
            {
                $conversation['last_message'] = LC_Conversation::getLastMessage($conversation['id_conversation']);
                if($conversation['last_message'])
                {
                    $conversation['last_message']['datetime_added'] = LC_Base::convertDate($conversation['last_message']['datetime_added']);
                    if($this->module->emotions)
                    {
                        foreach($this->module->emotions as $key=> $emotion)
                        {
                            $img = Module::getInstanceByName('ets_livechat')->displayText(Module::getInstanceByName('ets_livechat')->displayText('','img','',array('src'=>Context::getContext()->link->getMediaLink(_MODULE_DIR_.'ets_livechat/views/img/emotions/'.$emotion['img']))),'span','',array('title'=>$emotion['title']));
                            $conversation['last_message']['message'] = str_replace(array(Tools::strtolower($key),$key),array($img,$img),$conversation['last_message']['message']);
                        }
                    }
                }
                $conversation['avatar'] = LC_Departments::getAvatarCustomer($conversation['id_customer']);
            }
        }
        return $conversations;
    }
    public function getRecentlyTicket()
    {
        if($tickets = LC_ticket::getRecentlyTicket())
        {
            foreach($tickets as &$ticket)
            {
                $ticket['customer'] = LC_Ticket::getEmailCustomer($ticket['id_message']);
                $ticket['date_add']= LC_Base::convertDate($ticket['date_add']);
                $ticket['avatar'] = LC_Departments::getAvatarCustomer($ticket['id_customer']);
            }
        }
        return $tickets;
    }
}