<?php
/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_2_1_2($object)
{
    $sqls = array();
    if(!LC_Tools::checkCreatedColumn('ets_livechat_ticket_form','captcha_type'))
        $sqls[]='ALTER TABLE `'._DB_PREFIX_.'ets_livechat_ticket_form` ADD `captcha_type` VARCHAR(222) NOT NULL AFTER `allow_captcha`';
    if(!LC_Tools::checkCreatedColumn('ets_livechat_ticket_form','google2_site_key'))
        $sqls[]='ALTER TABLE `'._DB_PREFIX_.'ets_livechat_ticket_form` ADD `google2_site_key` VARCHAR(222) NOT NULL AFTER `allow_captcha`';
    if(!LC_Tools::checkCreatedColumn('ets_livechat_ticket_form','google2_secret_key'))
        $sqls[]='ALTER TABLE `'._DB_PREFIX_.'ets_livechat_ticket_form` ADD `google2_secret_key` VARCHAR(222) NOT NULL AFTER `allow_captcha`';
    if(!LC_Tools::checkCreatedColumn('ets_livechat_ticket_form','google3_site_key'))
        $sqls[]='ALTER TABLE `'._DB_PREFIX_.'ets_livechat_ticket_form` ADD `google3_site_key` VARCHAR(222) NOT NULL AFTER `allow_captcha`';
    if(!LC_Tools::checkCreatedColumn('ets_livechat_ticket_form','google3_secret_key'))
        $sqls[]='ALTER TABLE `'._DB_PREFIX_.'ets_livechat_ticket_form` ADD `google3_secret_key` VARCHAR(222) NOT NULL AFTER `allow_captcha`';
    if($sqls)
    {
        foreach($sqls as $sql)
        {
            Db::getInstance()->execute($sql);
        }
    }
    return true;
}