/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */
$(document).ready(function () {
    $(document).on('click', 'button[name="submitCustomerContact"],button[name="submitLoginCustomerContact"]', function (e) {
        e.preventDefault();
        var $this = $(this);
        if (!$this.hasClass('loading')) {
            $('.module_error.alert').parent().remove();
            $this.addClass('loading');
            var formData = new FormData($(this).parents('form').get(0));
            formData.append('ajax', 1);
            $.ajax({
                url: '',
                data: formData,
                type: 'post',
                dataType: 'json',
                processData: false,
                contentType: false,
                success: function (json) {
                    $this.removeClass('loading');
                    if (json.success) {
                        if (json.form) {
                            $('.lc_contact_popup').before(json.form);
                            $('form#customer-form-register').remove();
                            $('form#customer-form-login').remove();
                            $('.lc_contact_popup').remove();
                        } else
                            location.reload();

                    }
                    if (json.errors) {
                        $('form#customer-form-register').before(json.errors);
                    }
                },
                error: function (xhr, status, error) {
                    $this.removeClass('loading');
                }
            });
        }
    });
    $(document).on('click', '.lc_bt_cretate_account', function () {
        $('.lc_contact_popup').hide();
        $('form#form-contact-seller').hide();
        $('form#customer-form-register').show();
        return false;
    });
    $(document).on('click', '.lc_bt_login_account', function () {
        $('.lc_contact_popup').hide();
        $('form#form-contact-seller').hide();
        $('form#customer-form-login').show();
        return false;
    });
    $(document).on('click', '.cancel_contact_login', function () {
        $('.lc_contact_popup').show();
        $('form#customer-form-login').hide();
        $('form#customer-form-register').hide();
        $('.module_error.alert').parent().remove();
        return false;
    });
    if ($('input.star').length) {
        $('input.star').ets_rating();
        $('.lc_rate_ticket .star_content .star a').each(function(){
            if ($(this).next('span').length==0)
            {
                $(this).after('<span><svg class="star_full" width="12" height="12" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1728 647q0 22-26 48l-363 354 86 500q1 7 1 20 0 21-10.5 35.5t-30.5 14.5q-19 0-40-12l-449-236-449 236q-22 12-40 12-21 0-31.5-14.5t-10.5-35.5q0-6 2-20l86-500-364-354q-25-27-25-48 0-37 56-46l502-73 225-455q19-41 49-41t49 41l225 455 502 73q56 9 56 46z"/></svg><svg class="star_o" width="12" height="12" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1201 1004l306-297-422-62-189-382-189 382-422 62 306 297-73 421 378-199 377 199zm527-357q0 22-26 48l-363 354 86 500q1 7 1 20 0 50-41 50-19 0-40-12l-449-236-449 236q-22 12-40 12-21 0-31.5-14.5t-10.5-35.5q0-6 2-20l86-500-364-354q-25-27-25-48 0-37 56-46l502-73 225-455q19-41 49-41t49 41l225 455 502 73q56 9 56 46z"/></svg></span>');
                $(this).attr('title','');
            }

        });
    }
    if ($('#ticket-g-recaptcha-response-3').length > 0) {
        grecaptcha.ready(function () {
            grecaptcha.execute(ticket_google3_site_key, {action: 'homepage'}).then(function (token) {
                $('#ticket-g-recaptcha-response-3').val(token);
            });
        });
    }
    $('#ticket_note').focus();
    $('input.star').ets_rating();
    $(document).on('click', '.lc_form_submit_close', function () {
        $('.lc_form_submit_new_ticket').hide();
    });
    if ($("table .datepicker").length > 0) {
        $("table .datepicker").datepicker({
            prevText: '',
            nextText: '',
            dateFormat: 'yy-mm-dd'
        });
    }
    $(document).keyup(function (e) {
        if (e.keyCode == 27) {
            if ($('.lc_form_submit_new_ticket').length)
                $('.lc_form_submit_new_ticket').hide();
        }
    });
    $(document).on('click', '.lc_rate_ticket .star', function () {
        $.ajax({
            url: '',
            type: 'post',
            dataType: 'json',
            data: {
                set_rating_ticket: 1,
                rating: $('input[name="criterion_ticket"]').val(),
                id_ticket: $('input[name="id_ticket"]').val(),
            },
            success: function (json) {
                if (json.success)
                    $.growl.notice({message: json.success});
                if (json.errors)
                    $.growl.error({message: json.errors});
            }
        });
    });
    $(document).on('change', 'input[name="ticket_file"],.ets_livechat_form input[type="file"]', function () {
        var filename = $(this).val().split('\\').pop();
        filesize = this.files[0].size / 1048576;
        if (ETS_LC_MAX_FILE_MS > 0 && filesize > ETS_LC_MAX_FILE_MS) {
            $(this).val('');
            alert(invalid_file_max_size);
        } else {
            if ($(this).parent().hasClass('lc_upload_file')) {
                if ($(this).parents('.lc_upload_file').eq(0).next('.form_upfile_val').length) {
                    $(this).parents('.lc_upload_file').eq(0).next('.form_upfile_val').addClass('show').find('.file_name').html($(this).val().split('\\').pop());
                } else {
                    $(this).parents('.lc_upload_file').eq(0).after('<div class="form_upfile_val show"><div class="file_name">' + $(this).val().split('\\').pop() + '</div><button class="delete_file_note" title="Delete">' + delete_text + '</button></div>');
                }
            } else {
                if ($(this).parents('.form_upfile').eq(0).next('.form_upfile_val').length) {
                    $(this).parents('.form_upfile').eq(0).next('.form_upfile_val').addClass('show').find('.file_name').html($(this).val().split('\\').pop());
                } else {
                    $(this).parents('.form_upfile').eq(0).after('<div class="form_upfile_val show"><div class="file_name">' + $(this).val().split('\\').pop() + '</div><button class="delete_file_note" title="Delete">' + delete_text + '</button></div>');
                }
            }
        }
        if ($(this).val() == '') {
            $(this).parent().next('.form_upfile_val').remove();
        }
        $('#ticket_note').focus();
    });
    $(document).on('click', '.delete_file_note', function () {
        $(this).parents('.form_upfile_val').eq(0).removeClass('show').prev().find('input').val('');
        $(this).parents('.form_upfile_val').eq(0).removeClass('show').remove();
    });
    $(document).on('click', '.lc_send_message_ticket', function () {
        if ((!$('#ticket_file').length || $('#ticket_file').val() == '') && (!$('#ticket_note').length || $('#ticket_note').val().trim() == '') && !$('body').hasClass('lc_loading')) {
            alert(message_required);
            return false;
        }
        if($('body').hasClass('lc_loading'))
            return false;
        $('body').addClass('lc_loading');
        $('.lc_ticket_message').prev('.bootstrap').remove();
        var formData = new FormData($(this).parents('form').get(0));
        formData.append('lc_send_message_ticket', 1);
        
        $('.module_error').parent().remove();
        $.ajax({
            url: $(this).parents('form').eq(0).attr('action'),
            data: formData,
            type: 'post',
            dataType: 'json',
            processData: false,
            contentType: false,
            success: function (json) {
                if (json.messages) {
                    $('.lc_note_message').removeClass('nocomment');
                    var changeAvatrLink = $('.ticket-list-messages').attr('data-chatinfo');
                    $.each(json.messages, function (i, msg) {
                        var msgHtml = '<li class="lc_msg ' + (msg.id_employee != 0 ? 'is_employee' : 'is_customer') + (msg.your_ticket ? ' your_ticket' : '') + '" data-id-message="' + msg.id_note + '">'
                            + '<div class="lc_sender">' + (msg.id_employee != 0 ? (msg.employee_avata ? '<div class="avata' + (ETS_LC_AVATAR_IMAGE_TYPE == 'square' ? ' lc_avatar_square' : '') + '"><img src="' + msg.employee_avata + '" title="' + msg.employee_name + '">' + (msg.employee_name ? '<span title="' + msg.employee_name + '">' + msg.employee_name_hide + '</span>' : '') + '</div>' : '') : (msg.customer_avata ? '<div class="avata' + (ETS_LC_AVATAR_IMAGE_TYPE == 'square' ? ' lc_avatar_square' : '') + '"><a id="chat-info-link" href="' + changeAvatrLink + '"><img style="max-width: 120px;" src="' + msg.customer_avata + '" title="' + msg.customer_name + '">' + (msg.customer_name ? '<span title="' + msg.customer_name + '">' + msg.customer_name_hide + '</span>' : '') + '</a></div>' : '')) + '</div>'
                            + '<div class="lc_msg_content">' + msg.note + '</div>'
                            + '<div class="lc_msg_time">' + msg.date_add + '</div>'
                            + '</li>';
                        if ($('.ticket-list-messages > .lc_msg[data-id-message="' + msg.id_note + '"]').length <= 0) {
                            var msgAdded = false;
                            $($('.ticket-list-messages > .lc_msg').get().reverse()).each(function () {
                                if (parseInt($(this).attr('data-id-message')) < parseInt(msg.id_note)) {
                                    $(this).after(msgHtml);
                                    msgAdded = true;
                                    return false;
                                }
                            });
                            if (!msgAdded) {
                                $('.ticket-list-messages').prepend(msgHtml);
                            }

                        }
                    });
                }
                if (json.success) {
                    if (json.warning)
                        $.growl($.extend({title: "", style: "warning", duration: 6200}, {message: json.success}))
                    else {
                        $.growl($.extend({title: "", style: "notice", duration: 6200}, {message: json.success}));
                    }
                }
                if (json.error) {
                    $('.lc_note_message').after(json.error);
                } else {
                    $('#ticket_file').val('');
                    $('#ticket_note').val('');
                    $('.form_upfile_val').remove();
                }
                $('body').removeClass('lc_loading');
            },
            error: function (xhr, status, error) {
                $('body').removeClass('lc_loading');
            }
        });
        return false;
    });
    $(document).on('click', '.lc_ticket_captcha_refesh', function () {
        if ($('.lc_ticket_captcha_img').length > 0)
            $('.lc_ticket_captcha_img').attr('src', $(this).attr('data-captcha-img') + '&rand=' + Math.random());
    });
    $(document).on('click', '.submit_new_ticket_bt', function () {
        $('.lc_form_submit_new_ticket').show();
    });
    $(document).mouseup(function (e) {
        var container = $('.lc_form_submit_new_ticket_content');
        if (!container.is(e.target) && container.has(e.target).length === 0) {
            $('.lc_form_submit_new_ticket').hide();
        }
    });
    $(document).on('click', '#new_ticket_bt', function () {
        if ($('#form_ticket').val() != '--')
            window.location.href = $('#form_ticket').val();
        return false;
    });
    $(document).on('click','.submit_send_ticket',function(){
        setTimeout(function(){
            $('.submit_send_ticket').attr('disabled','disabled')
        },100
        )
    });
    $(document).on('click', '.btn-load-more-message-ticket', function () {
        var id_ticket = $(this).data('id_ticket');
        var page = $(this).attr('data-page');
        var $this = $(this);
        if (!$this.hasClass('loading')) {
            $this.addClass('loading');
            $.ajax({
                url: '',
                type: 'post',
                dataType: 'json',
                data: {
                    load_more_message_ticket: 1,
                    page: page,
                    id_ticket: id_ticket,
                },
                success: function (json) {
                    $this.removeClass('loading');
                    if (!json.loadmore)
                        $('.btn-load-more-message-ticket').remove();
                    else
                        $('.btn-load-more-message-ticket').attr('data-page', json.next_page);
                    if (json.list_messages) {
                        $('.ticket-list-messages li:first').before(json.list_messages);
                    }
                }
            });
        }
    });
    $(document).on('click','.view-list-order',function(){
        var id_customer = $(this).data('id_customer');
        var id_order = $(this).data('id_order');
        if(!$(this).hasClass('loading'))
        {
            $(this).addClass('loading');
            $.ajax({
                url: '',
                data: 'getViewListOrder&id_customer='+id_customer+'&id_order='+id_order,
                type: 'post',
                dataType: 'json',
                success: function(json){
                    $('.view-list-order').removeClass('loading');
                    if(!$('.lc_ticket_header .list-products-all-order').length)
                    {
                        $('.lc_ticket_header').append('<div class="list-products-all-order"><div class="ets_table"><div class="ets_table_cell"></div></div></div>');
                    }
                    else
                        $('.lc_ticket_header .list-products-all-order').show();
                    $('.lc_ticket_header .list-products-all-order .ets_table_cell').html(json.list_orders);
                },
                error: function(xhr, status, error)
                {
                    $('.view-list-order').removeClass('loading');
                    alert('error');
                }
            });
        }
        return false;
    });
    $(document).on('click','.lc_close',function(){
        $('.list-products-all-order').hide();
    });
    $(document).keyup(function(e) {
        if(e.keyCode == 27) {
            $('.list-products-all-order').hide();
        }
    });
    $(document).mouseup(function (e){
        var container_products = $('.list-products-all-order .list-products');
        if (!container_products.is(e.target)&& container_products.has(e.target).length === 0)
        {
            $('.list-products-all-order').hide();
        }

    });
    $(document).on('click','.link-load-more-ticket-product',function(){
        var id_customer = $(this).data('id_customer');
        var id_order = $(this).data('id_order');
        var page = $(this).attr('data-page');
        if(!$(this).hasClass('loading'))
        {
            $(this).addClass('loading');
            $.ajax({
                url: '',
                data: 'getMoreViewListOrder&id_customer='+id_customer+'&id_order='+id_order+'&page='+page,
                type: 'post',
                dataType: 'json',
                success: function(json){
                    $('.link-load-more-ticket-product').removeClass('loading');
                    $('.lc_ticket_header .list-products-all-order tbody').append(json.list_orders);
                    if(!json.load_more)
                        $('.link-load-more-ticket-product').remove();
                    else
                        $('.link-load-more-ticket-product').attr('data-page',json.page_next);
                },
                error: function(xhr, status, error)
                {
                    $('.link-load-more-ticket-product').removeClass('loading');
                    var err = eval("(" + xhr.responseText + ")");
                    $.growl.error({ message: err.Message });
                }
            });
        }
        return false;
    });
});