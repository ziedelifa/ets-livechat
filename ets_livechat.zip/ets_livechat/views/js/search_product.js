/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */

$(document).ready(function(){
    ets_lc_search_fn.searchProduct();
    $(document).on('click', '.ets_lc_product_search:not(.product_ref) .ets_lc_product_item .remove_ctm', function () {
        $(this).closest('.ets_livechat_form').find('#lc_id_product').val('');
        $(this).parents('.ets_lc_product_search').removeClass('active').find('.ets_lc_product_item').remove();
        $(this).parents('.ets_lc_group_max').removeClass('has_choosed_product');
    });
});
var ets_lc_search_fn = {
    closeSearch: function (dom, destroy) {
        if (dom.length > 0) {
            var _destroy = destroy || false;
            if (dom.length > 0)
                dom.val('');
            if (_destroy)
                dom.unautocomplete();
        }

        return this;
    },
    searchProduct: function () {
        if ($.fn.autocomplete) {
            var dom =  $('input[name=lc_search_product]');
            if (dom.length > 0 && ets_lc_link_search_product !== '') {
                dom.autocomplete(ets_lc_link_search_product, {
                    resultsClass: "ets_lc_product_results",
                    appendTo: '.ets_lc_product_search',
                    delay: 100,
                    minChars: 1,
                    autoFill: true,
                    max: 20,
                    matchContains: true,
                    mustMatch: true,
                    scroll: false,
                    cacheLength: 0,
                    multipleSeparator: '||',
                    formatItem: function (item) {
                        if(typeof item[1] !== typeof undefined)
                            return '<span data-id="' + item[0] + '"><img src="' + item[3] + '" title="' + item[1] +'" width="64"/>' + item[1]  + '</span>';
                        else
                        {
                            if(dom.val()!= '' && ($('.ets_lc_product_results li').length==0 || $('.ets_lc_product_results li:first').html().trim()=='') )
                                return '<span class="search-not-found">'+lc_text_no_product_found+'</span>';
                            else
                                return '';
                        }
                    }
                }).result(function (event, item) {
                    if (item == null || typeof item[1] === typeof undefined)
                    {
                        dom.val('');
                        return false;
                    }
                    $('input[name=id_product]').val(item[0]);
                    $('.ets_lc_product_search')
                        .addClass('active')
                        .html('<div class="ets_lc_product_item" data-id="' + item[0] + '"><img src="' + item[3] + '" title="' + item[1] + (item[2] ? ' (' + item[2] + ')':'')+'" width="64"/>' + item[1] +(item[2] ? ' (' + item[2] + ')':'') +'<span class="remove_ctm lh_16"><svg class="w_14 h_14" width="14" height="14" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M704 736v576q0 14-9 23t-23 9h-64q-14 0-23-9t-9-23v-576q0-14 9-23t23-9h64q14 0 23 9t9 23zm256 0v576q0 14-9 23t-23 9h-64q-14 0-23-9t-9-23v-576q0-14 9-23t23-9h64q14 0 23 9t9 23zm256 0v576q0 14-9 23t-23 9h-64q-14 0-23-9t-9-23v-576q0-14 9-23t23-9h64q14 0 23 9t9 23zm128 724v-948h-896v948q0 22 7 40.5t14.5 27 10.5 8.5h832q3 0 10.5-8.5t14.5-27 7-40.5zm-672-1076h448l-48-117q-7-9-17-11h-317q-10 2-17 11zm928 32v64q0 14-9 23t-23 9h-96v948q0 83-47 143.5t-113 60.5h-832q-66 0-113-58.5t-47-141.5v-952h-96q-14 0-23-9t-9-23v-64q0-14 9-23t23-9h309l70-167q15-37 54-63t79-26h320q40 0 79 26t54 63l70 167h309q14 0 23 9t9 23z"/></svg></span></div>').parents('.ets_lc_group_max').addClass('has_choosed_product');

                    ets_lc_search_fn.closeSearch(dom);
                });
            }
        }
        return false;
    },

}