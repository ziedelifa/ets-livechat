/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */
$(document).ready(function(){
    $('.confi_tab').click(function(){
        $('.confi_tab').each(function(){
            var current_tabactive = $(this).attr("data-tab-id");
            $('body').removeClass('ets_lv_tab-'+current_tabactive);
        });
        var current_tabactive = $('.confi_tab').attr("data-tab-id");
        $('body').removeClass('ets_lv_tab-'+current_tabactive);
        $('.ybc-form-group').removeClass('active');
        $('.ybc-blog-tab-'+$(this).attr('data-tab-id')).addClass('active');  
        $('body').addClass('ets_lv_tab-'+$(this).attr("data-tab-id") );
        $('#ETS_TAB_CURENT_ACTIVE').val($(this).attr('data-tab-id'));
        $(this).parent().find('.confi_tab').removeClass('active');
        $(this).addClass('active');    
        if($(this).attr('data-tab-id')=='statistics')
        {
            $('button[name="saveConfig"]').hide();
        }
        else
            $('button[name="saveConfig"]').show();  
    });
    $(document).on('click','input[name="etslcSubmitUpdateToken"]',function(){
        $(this).addClass('loading');
        $.ajax({
			type: 'POST',
			headers: { "cache-control": "no-cache" },
			url: '',
			async: true,
			cache: false,
			dataType : "json",
			data:'etslcSubmitUpdateToken=1&ETS_LC_CRONJOB_TOKEN='+$('#ETS_LC_CRONJOB_TOKEN').val(),
			success: function(json)
			{
                if(json.success)
                {
                    $.growl.notice({ message: json.success });
                    $('.js-emp-test-cronjob').attr('data-secure',$('#ETS_LC_CRONJOB_TOKEN').val());
                    $('.emp-cronjob-secure-value').html($('#ETS_LC_CRONJOB_TOKEN').val());
                }
                if(json.errors)
                {
                    $.growl.error({message:json.errors});
                }
                $('input[name="etslcSubmitUpdateToken"]').removeClass('loading');
            }
		});
    });
    $(document).on('click','.js-emp-test-cronjob',function(e){
        e.preventDefault();
        if(!$(this).hasClass('loading'))
        {   $(this).addClass('loading');
            var url_ajax= $(this).attr('href');
            var secure = $(this).attr('data-secure');
            $.ajax({
    			type: 'POST',
    			headers: { "cache-control": "no-cache" },
    			url: url_ajax,
    			async: true,
    			cache: false,
    			dataType : "json",
    			data:'ajax=1&secure='+secure,
    			success: function(json)
    			{
                    if(json.success)
                    {
                        $.growl.notice({ message: json.success });
                        $('.cronjob_log').val(json.cronjob_log);
                    }
                    if(json.errors)
                    {
                        $.growl.error({message:json.errors});
                    }
                    $('.js-emp-test-cronjob').removeClass('loading');
                }
    		});
        }
        
    });
    $(document).on('click','button[name="etslcSubmitClearLog"]',function(e){
        e.preventDefault();
        $(this).addClass('loading');
        $.ajax({
			type: 'POST',
			headers: { "cache-control": "no-cache" },
			url: '',
			async: true,
			cache: false,
			dataType : "json",
			data:'ajax=1&etslcSubmitClearLog=1',
			success: function(json)
			{
                if(json.success)
                {
                    $.growl.notice({ message: json.success });
                    $('.cronjob_log').val('');
                }
                if(json.errors)
                {
                    $.growl.error({message:json.errors});
                }
                $('button[name="etslcSubmitClearLog"]').removeClass('loading');
            }
		});
    });
    $(document).on('click','input[name="ETS_LC_SAVE_CRONJOB_LOG"]',function(){
        $.ajax({
			type: 'POST',
			headers: { "cache-control": "no-cache" },
			url: '',
			async: true,
			cache: false,
			dataType : "json",
			data:'ETS_LC_SAVE_CRONJOB_LOG='+$('input[name="ETS_LC_SAVE_CRONJOB_LOG"]:checked').val(),
			success: function(json)
			{
                if(json.success)
                {
                    $.growl.notice({ message: json.success });
                }
                if(json.errors)
                {
                    $.growl.error({message:json.errors});
                }
            }
		});
    });
})