/**
 * Copyright ETS Software Technology Co., Ltd
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 website only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future.
 *
 * @author ETS Software Technology Co., Ltd
 * @copyright  ETS Software Technology Co., Ltd
 * @license    Valid for 1 website (or project) for each purchase of license
 */
$(document).ready(function(){
   if ($('body[id=identity]').length > 0  && $('.lc-managament-information').length > 0) {
      if ($('#customer-form input[name=birthday], #identity input[name=confirmation]').length > 0) {
         var form_field = $('.lc-managament-information').html();
         $('#customer-form input[name=birthday], #identity input[name=confirmation]').parents('.form-group').after(form_field);
         $('.lc-managament-information').remove();
      } else
      {
         if($('#customer-form input[name=new_password]').length)
         {
            var form_field = $('.lc-managament-information').html();
            $('#customer-form input[name=new_password]').parents('.form-group').after(form_field);
            $('.lc-managament-information').remove();
         }
      }
   }
   $(document).on('click','.customer_avata .delete_url',function(e){
      e.preventDefault();
      $.ajax({
         url: lc_link_info_customer,
         type: 'POST',
         data: 'deleteavatar=1',
         dataType: 'json',
         success: function (json) {
            if(json.success)
            {
               $.growl.notice({title: "", message: json.success});
               $('.customer_avata img').attr('src',json.customer_avatar_default);
               $('.customer_avata .delete_url').hide();
            }
         },
         error: function () {
         }
      });
   });
   $(document).on('change','input[name="customer_avata"],#lc_signature',function(){
      var fileExtension = ['png', 'jpg', 'jpeg', 'gif','webp'];
      if ($.inArray($(this).val().split('.').pop().toLowerCase(), fileExtension) == -1) {
         alert(ets_livechat_invalid_file);
      } else {
         if ($(this).closest('.upload_form_custom').find('.file_name').length) {
            $(this).closest('.upload_form_custom').find('.file_name').html($(this).val().split('\\').pop());
         } else
            $(this).closest('.upload_form_custom').append('<span class="file_name">' + $(this).val().split('\\').pop() + '</span>');
         lc_readURL(this);
         var formData = new FormData($(this).parents('form')[0]);
         formData.append('ajax', 1);
         formData.append('submitCustomerInfo', 1);
         $.ajax({
            url: lc_link_info_customer,
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            dataType: 'json',
            success: function (json) {
               if(json.success)
               {
                  $.growl.notice({title: "", message: json.success});
                  $('.customer_avata img').attr('src',json.customer_avatar);
                  $('.customer_avata .delete_url').show();
               }
               if(json.errors)
                  $.growl.error({message:json.errors});
            },
            error: function () {
            }
         });
      }
   });
   function lc_readURL(input) {
      if (input.files && input.files[0]) {
         var reader = new FileReader();
         reader.onload = function (e) {
            if ($(input).closest('.col-md-9').find('.customer_avata').length <= 0) {
               $(input).closest('.col-md-9').append('<div class="customer_avata"><img src="' + e.target.result + '" style="max-width: 120px;"/> </div>');
            } else {
               $(input).closest('.col-md-9').find('.customer_avata img').eq(0).attr('src', e.target.result);
            }
         }
         reader.readAsDataURL(input.files[0]);
      }
   }
});